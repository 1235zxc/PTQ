﻿using Hangfire.States;
using Hangfire.Storage;

namespace ProTraQ.HandHeld.Server.Tasks
{
    public class ProlongJobLifetimeFilter : IApplyStateFilter
    {
        public void OnStateUnapplied(ApplyStateContext context, IWriteOnlyTransaction transaction)
        {
            context.JobExpirationTimeout = TimeSpan.FromDays(10);
        }

        public void OnStateApplied(ApplyStateContext context, IWriteOnlyTransaction transaction)
        {
            context.JobExpirationTimeout = TimeSpan.FromDays(10);
        }
    }
}
