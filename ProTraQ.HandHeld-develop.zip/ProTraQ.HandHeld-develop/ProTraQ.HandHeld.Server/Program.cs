using Hangfire;
using Hangfire.Console;
using Microsoft.Extensions.DependencyInjection.Extensions;
using ProTraQ.HandHeld.Common.Api.Services;
using ProTraQ.HandHeld.Server.Security;
using ProTraQ.HandHeld.Server.Tasks;

namespace ProTraQ.HandHeld.Server;

public class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);


        var config = new ConfigurationBuilder()
        .AddJsonFile("appsettings.json", optional: false)
        .Build();

        // Add services to the container.
        var isNextGenerationSite = Convert.ToBoolean(config.GetSection("IsNextGenerationSite").Value); // TODO: Determine environment ??? builder.Environment.EnvironmentName.Contains("NextGeneration")
        if (isNextGenerationSite)
        {
            builder.Services.AddNextGenerationServices();
        }
        else
        {
            builder.Services.AddClassicServices();
        }
        builder.Services.AddCommonServices();
        //this.Configuration = configuration;
        //builder.Services.AddCommonServices();


        builder.Services.AddControllers();
        // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
        builder.Services.AddEndpointsApiExplorer();
        builder.Services.AddSwaggerDocument();
        //builder.Services.AddSwaggerDocument(settings =>
        //{
        //    settings.PostProcess = document =>
        //    {
        //        document.Info.Version = "v1";
        //        document.Info.Title = "Example API";
        //        document.Info.Description = "REST API for example.";
        //    };
        //});
        var httpContextAccessor = new HttpContextAccessor();

        builder.Services.AddSingleton<IHttpContextAccessor>(httpContextAccessor);
        builder.Services.AddHangfire(hf =>
        {
            hf.UseSqlServerStorage(config.GetConnectionString("HangfireConnection"));
            hf.UseFilter<ProlongJobLifetimeFilter>(new ProlongJobLifetimeFilter());  // keeps HF (successful/deleted) jobs for 10 days instead of 1 day

            var co = new ConsoleOptions();
            co.BackgroundColor = "#0d3163";
            co.TimestampColor = "#ffffff";
            co.TextColor = "#ffffff";
            hf.UseConsole(co);
        });

        builder.Services.TryAddSingleton<BackgroundJobClient>();
        builder.Services.TryAddSingleton<RecurringJobManager>();
        builder.Services.TryAddScoped<PtqAutomation.Automation.Client.ILocationInfoService, LocationInfoService>();
        builder.Services.TryAddScoped<PtqAutomation.Automation.Client.INonAutomationStorageService, NonAutomationStorageService>();
        builder.Services.TryAddScoped<PtqAutomation.Automation.Client.IStatusChangeService, StatusChangeService>();
        var AutomationRepository = new PtqAutomation.Automation.Data.Repository(
            config.GetConnectionString("AutomationQueueConnection").ToString(),
            config.GetConnectionString("AutomationSharedDbConnection").ToString(),
            false,  // Configuration.GetValue<bool>("ProtraQMockRunnerApi:miniprofilerEnabled"),
            500,    // Configuration.GetValue<double>("ProtraQMockRunnerApi:miniprofilerSQLThreshold"),
            true    // Configuration.GetValue<bool>("ProtraQMockRunnerApi:canConnect")
        );
        builder.Services.AddSingleton<PtqAutomation.Automation.Data.IRepository>(AutomationRepository);
        builder.Services.AddTransient<PtqAutomation.Automation.Factories.Interfaces.IStorageServiceFactory, PtqAutomation.Automation.Factories.StorageServiceFactory>();
        builder.Services.AddTransient<PtqAutomation.Automation.Factories.Interfaces.IRetrievalServiceFactory, PtqAutomation.Automation.Factories.RetrievalServiceFactory>();
        builder.Services.AddTransient<PtqAutomation.Automation.Factories.Interfaces.ICancelServiceFactory, PtqAutomation.Automation.Factories.CancelServiceFactory>();
        builder.Services.AddTransient<PtqAutomation.Automation.Factories.Interfaces.IBlockageServiceFactory, PtqAutomation.Automation.Factories.BlockageServiceFactory>();
        //builder.Services.TryAddSingleton<PtqAutomation.Automation.Factories.QueueViewerServiceFactory>();
        //builder.Services.TryAddSingleton<RecurringJobManager>();
        //builder.Servicesz.AddConfiguredAgvSystem(applicationVariables.FacilityAgvSystem);
        var app = builder.Build();
        // Create automation respository



        // Configure the HTTP request pipeline.
        //if (app.Environment.IsDevelopment())
        //{
        app.UseOpenApi();
        app.UseSwaggerUi3();
        //}

        app.UseHttpsRedirection();
        app.UseHangfireServer();
        app.UseHangfireDashboard("/hangfire", new DashboardOptions()
        {
            Authorization = new[] { new HangFireAuthorizationFilter(httpContextAccessor) }
        });
        app.UseAuthorization();


        app.MapControllers();

        app.Run();
    }
}
