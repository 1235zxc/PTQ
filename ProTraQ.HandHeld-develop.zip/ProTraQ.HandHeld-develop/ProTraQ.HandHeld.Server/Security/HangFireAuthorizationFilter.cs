﻿using Hangfire.Dashboard;
using Hangfire.Annotations;
namespace ProTraQ.HandHeld.Server.Security
{
    public class HangFireAuthorizationFilter : IDashboardAuthorizationFilter
    {
        protected IHttpContextAccessor _httpContextAccessor { get; set; }

        public HangFireAuthorizationFilter(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }

        public bool Authorize([NotNull] DashboardContext context)
        {
            //can add some more logic here...i.e. we can restrict it to certain user accounts or something (or admin only)
            return _httpContextAccessor.HttpContext.User.Identity.IsAuthenticated;
        }
    }
}
