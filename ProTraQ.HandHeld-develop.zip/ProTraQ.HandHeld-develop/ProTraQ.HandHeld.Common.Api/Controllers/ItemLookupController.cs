﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ProTraQ.HandHeld.Common.Api.Repository;

namespace ProTraQ.HandHeld.Common.Api.Controller
{
    [ApiController]
    [Route("api/[controller]")]
    public class ItemLookupController : ControllerBase
    {
        private readonly IItemLookupRepository _repository;

        public ItemLookupController(IItemLookupRepository repository)
        {
            _repository = repository;
        }
    }
}
