﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.Common.Api.Controllers;

[ApiController]
[Route("api/common")]
public class CommonController : ControllerBase
{
    private static IConfiguration _config;
    private readonly ILogger<CommonController> _logger;
    private readonly ICommonRepository _repository;
    public CommonController(ILogger<CommonController> logger,
                            ICommonRepository repository, IConfiguration config)
    {
        _logger = logger;
        _repository = repository;
        _config = config;
    }

    [HttpGet(nameof(GetAboutInformation))]
    public async Task<ActionResult<AboutInformationResponse>> GetAboutInformation()
    {
        AboutInformationResponse resp = new AboutInformationResponse();
        System.Reflection.Assembly a1 = System.Reflection.Assembly.GetCallingAssembly();
        resp.AppVersion = a1.GetName().Version.ToString();
        resp.aboutInformation = await _repository.GetAboutInformationAsync();

        return Ok(resp);
    }

}
