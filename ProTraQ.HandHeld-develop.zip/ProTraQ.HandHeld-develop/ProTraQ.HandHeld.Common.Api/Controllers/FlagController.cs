﻿using Microsoft.AspNetCore.Mvc;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Common.Api.Services;
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.Common.Api.Controllers
{
    [ApiController]
    [Route("api/flag")]
    public class FlagController : ControllerBase
    {
        private readonly IFlagRepository _flagRepository;
        public FlagController(IFlagRepository flagRepository)
        {
            _flagRepository = flagRepository;
        }

        [HttpGet("GetFlagValue")]
        public FlagResult GetFlagValue(ProTraQFlagEnum eFlag)
        {
            var flagName = FlagInfoService.GetFlagString(eFlag);

            string v = string.Empty;
            _flagRepository.usp_FLAGS_GetFlagValue(flagName, out v);

            var result = new FlagResult();
            result.FlagValue = v;

            return result;
        }

        /// <summary>
        /// It's an addition to expose available flag list can be used by Front End
        /// TODO: Can be removed later on
        /// </summary>
        /// <returns></returns>
        [HttpGet(nameof(GetFlagList))]
        public Dictionary<int, string> GetFlagList()
        {
            var flags = Enum.GetValues(typeof(ProTraQFlagEnum)).Cast<int>().ToDictionary(e => e, e => Enum.GetName(typeof(ProTraQFlagEnum), e));
            return flags;
        }
    }
}
