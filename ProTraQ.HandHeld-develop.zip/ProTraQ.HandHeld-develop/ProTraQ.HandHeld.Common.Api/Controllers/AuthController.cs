﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;
using static ProTraQ.HandHeld.Shared.Enumerations;

namespace ProTraQ.HandHeld.Common.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private static IConfiguration _config;
    private readonly IAuthRepository _repository;
    public AuthController(IAuthRepository repository, IConfiguration config)
    {
        _repository = repository;
        _config = config;
    }

    [HttpGet(nameof(GetConnectionType))]
    public string GetConnectionType()
    {
        try
        {
            var isNextGenerationSite = Convert.ToBoolean(_config.GetSection("IsNextGenerationSite").Value);
            return isNextGenerationSite ? ConnectionType.NG.ToString() : ConnectionType.Legacy.ToString();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    [HttpGet(nameof(GetFacilityInformation))]
    public async Task<Facility> GetFacilityInformation()
    {
        try
        {
            var facility = await _repository.GetFacilityInfo();
            if (facility != null)
            {
                var operatingMode = _config.GetSection("OperatingMode").Value;
                if (operatingMode != null)
                {
                    OperatingMode operationMode = (OperatingMode)Enum.Parse(typeof(OperatingMode), operatingMode);
                    if (facility.IsProduction == null)
                    {
                        facility.IsProduction = OperatingMode.Production == operationMode ? true : false;
                    }
                    if (facility.OperatingMode == null)
                    {
                        facility.OperatingMode = operationMode.ToString();
                    }
                }
            }
            return facility;
        }
        catch (Exception e)
        {
            throw (e);
        }
    }
}
