﻿using Microsoft.AspNetCore.Mvc;
using ProTraQ.HandHeld.Common.Api.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProTraQ.HandHeld.Common.Api.Controllers
{
    public class SystemInfoController
    {
        private readonly ISystemInfoRepository _systemInfoRepository;
        public SystemInfoController(ISystemInfoRepository systemInfoRepository)
        {
            _systemInfoRepository = systemInfoRepository;
        }
        [HttpGet(nameof(GetMinSNLengthForFacility))]
        public int GetMinSNLengthForFacility()
        {
            try
            {
                return _systemInfoRepository.GetMinSNLengthForFacility();
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        [HttpGet(nameof(GetLocalServerTime))]
        public DateTime GetLocalServerTime()
        {
            return System.DateTime.Now;
        }
    }
}
