﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data.SqlClient;

namespace ProTraQ.HandHeld.Common.Api.Controllers;
[ApiController]
[Route("api/[controller]")]
public class PutAwayController : ControllerBase
{
    private readonly ILogger<PutAwayController> _logger;
    private readonly IPutAwayRepository _repository;
    public PutAwayController(ILogger<PutAwayController> logger,
                             IPutAwayRepository repository)
    {
        _logger = logger;
        _repository = repository;
        //_CancelService = CancelService;
    }

    [HttpGet(nameof(GetItemInformation))]
    public async Task<ActionResult<GetItemInformationResponse>> GetItemInformation([FromQuery] GetItemInformationRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.ItemId))
        {
            var message = "A InventoryId or SerialNumber is required.";
            _logger.LogError(message);
            return BadRequest(message);
        }

        var itemInformation = await _repository.GetItemInformationAsync(request);
        if (itemInformation == null)
        {
            _logger.LogInformation("The InventoryId or SerialNumber provided '{InventoryIdOrSerialNumber}' could not be found.",
                                   request.ItemId);
            return NotFound($"The InventoryId or SerialNumber provided: '{request.ItemId}', could not be found.");
        }

        CleanUpItemInformation(itemInformation);

        _logger.LogDebug("Found Item: '{@ItemInformation}'", itemInformation);
        return new GetItemInformationResponse { ItemInformation = itemInformation };
    }

    [HttpGet(nameof(GetLocationOldestItemInformation))]
    public async Task<ActionResult<GetLocationOldestItemInformationResponse>> GetLocationOldestItemInformation([FromQuery] GetLocationOldestItemInformationRequest request)
    {
        ItemInformation itemInformation;
        try
        {
            itemInformation = await _repository.GetLocationOldestItemInformationAsync(request);
        }
        catch (SqlException)
        {
            _logger.LogInformation("Location '{LocationId}' is not valid or is not a take away location.",
                                   request.LocationId);
            return BadRequest($"Location '{request.LocationId}' is not valid or is not a take away location.");
        }

        if (itemInformation is null)
        {
            _logger.LogInformation("No item was found to take away from Location '{LocationId}'.",
                                   request.LocationId);
            return NotFound($"No item was found to take away from Location '{request.LocationId}'.");
        }

        CleanUpItemInformation(itemInformation);

        _logger.LogDebug("Oldest item at location '{LocationId}' found: '{@ItemInformation}'", request.LocationId, itemInformation);
        return new GetLocationOldestItemInformationResponse { ItemInformation = itemInformation };
    }

    [HttpGet(nameof(GetDisplayLocationOldestItemInformation))]
    public async Task<ActionResult<GetDisplayLocationOldestItemInformationResponse>> GetDisplayLocationOldestItemInformation(GetDisplayLocationOldestItemInformationRequest request)
    {
        ItemInformation itemInformation;
        try
        {
            itemInformation = await _repository.GetDisplayLocationOldestItemInformationAsync(request);
        }
        catch (SqlException)
        {
            _logger.LogInformation("Location '{DisplayLocationId}' is not valid or is not a take away location.",
                                   request.DisplayLocationId);
            return BadRequest($"Location '{request.DisplayLocationId}' is not valid or is not a take away location.");
        }

        if (itemInformation == null)
        {
            _logger.LogInformation("No item was found to take away from Location '{DisplayLocationId}'.",
                                   request.DisplayLocationId);
            return NotFound($"No item was found to take away from Location '{request.DisplayLocationId}'.");
        }

        CleanUpItemInformation(itemInformation);

        _logger.LogDebug("Oldest item at location '{LocationId}' found: '{@ItemInformation}'", request.DisplayLocationId, itemInformation);
        return new GetDisplayLocationOldestItemInformationResponse { ItemInformation = itemInformation };
    }

    [HttpGet(nameof(GetCartonInformationForItem))]
    public async Task<ActionResult<GetCartonInformationForItemResponse>> GetCartonInformationForItem(GetCartonInformationForItemRequest request)
    {
        var results = await _repository.GetCartonInformationForItemAsync(request);
        var procedureResult = results.Set3.First();

        if (procedureResult.ReturnValue != 1)
        {
            _logger.LogInformation(procedureResult.ReturnMessage);
            return BadRequest(procedureResult.ReturnMessage);
        }

        var cartonInformation = results.Set1.First();
        _logger.LogDebug("Carton information for item '{ItemId}' found: '{@CartonInformation}'", request.ItemId, cartonInformation);
        return new GetCartonInformationForItemResponse { CartonInformation = cartonInformation };
    }

    private void CleanUpItemInformation(ItemInformation itemInformation)
    {
        // Clean up DB inconsistencies
        // Clean up the fields in the object that get forced to an empty string when it's null in the DB
        // most come through as nulls, so just being consistent
        itemInformation.DisplayLocationId = ChangeToNullIfEmpty(itemInformation.DisplayLocationId);
        itemInformation.PrintDesignName = ChangeToNullIfEmpty(itemInformation.PrintDesignName);
    }

    private string? ChangeToNullIfEmpty(string value)
    {
        return string.IsNullOrEmpty(value) ? null : value;
    }

    [HttpGet(nameof(AutomationGetInventoryLocationForAutomation))]
    public async Task<ActionResult<AutomationInventoryInformation>> AutomationGetInventoryLocationForAutomation([FromQuery] long itemId)
    {
        return await _repository.getAutomationInventoryInfo_SELECT_ITEM_INVID(itemId);
    }
}
