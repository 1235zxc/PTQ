﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.Common.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ManageRowController : ControllerBase
    {
        private readonly ILogger<ManageRowController> _logger;
        private readonly IManageRowRepository _repository;
        public ManageRowController(ILogger<ManageRowController> logger, IManageRowRepository repository)
        {
            _logger = logger;
            _repository = repository;
        }

        [HttpGet(nameof(GetFacilityWarehouseCodes))]
        public async Task<ActionResult<GetFacilityInfoResponse>> GetFacilityWarehouseCodes()
        {
            List<Facility> facilityInfo;
            try
            {
                facilityInfo = await _repository.GetFacilityWarehouseCodes();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return new GetFacilityInfoResponse { FacilityInformation = facilityInfo };
        }

        [HttpGet(nameof(GetInventoryTypeList))]
        public async Task<ActionResult<GetInventoryResponse>> GetInventoryTypeList()
        {
            List<Inventory> inventoryList;
            try
            {
                inventoryList = await _repository.GetInventoryTypeList();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return new GetInventoryResponse { InventoryTypes = inventoryList };
        }


        [HttpGet(nameof(GetRowContents_ALPHA))]
        public async Task<ActionResult<object>> GetRowContents_ALPHA([FromQuery] GetRowContentRequest request)
        {
            object results;
            try
            {
                results = await _repository.GetRowContents_ALPHA(request);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return results;
        }

        //[HttpGet(nameof(GetRowContents))]
        //public async Task<ActionResult<object>> GetRowContents([FromQuery] GetRowContentRequest request)
        //{
        //    object results;
        //    try
        //    {
        //        results = await _repository.GetRowContents(request);
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //    return results;
        //}

        [HttpGet(nameof(GetSpecContents))]
        public async Task<ActionResult<object>> GetSpecContents([FromQuery] GetRowContentRequest request)
        {
            object results;
            try
            {
                results = await _repository.GetSpecContents(request);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return results;
        }

        [HttpGet(nameof(GetSpecProdDateContents))]
        public async Task<ActionResult<object>> GetSpecProdDateContents([FromQuery] GetRowContentRequest request)
        {
            object results;
            try
            {
                results = await _repository.GetSpecProdDateContents(request);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return results;
        }

        [HttpGet(nameof(GetInvIDLocationLIKE))]
        public async Task<ActionResult<object>> GetInvIDLocationLIKE([FromQuery] GetRowContentRequest request)
        {
            object results;
            try
            {
                results = await _repository.GetInvIDLocationLIKE(request);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return results;
        }

        [HttpGet(nameof(PutAwayItemAsLost))]
        public async Task<int> PutAwayItemAsLost([FromQuery] PutAwayItemAsLostRequest request)
        {
            int iReturn = 0;
            try
            {
                // Add parameters
                await _repository.PutAwayItemAsLost(request);

                if (request.Return != null)
                {
                    int.TryParse(request.Return.ToString(), out iReturn);
                }
                if (request.ReturnMsg != null)
                {
                    request.ReturnMsg = request.ReturnMsg.ToString();
                }
            }
            catch (Exception e) { throw (e); }
            return iReturn;
        }
       
        [HttpGet(nameof(MoveSpecProductionDateContents))]
        public async Task<ActionResult<object>> MoveSpecProductionDateContents([FromQuery] MoveSpecProductionDateContentsRequest request)
        {

            try
            {
                var response = await _repository.MoveSpecProductionDateContents(request);

                string sReturn = string.Empty;

                if (request.Return != null)
                    sReturn += request.Return.ToString();
                if (request.ReturnMsg != null)
                    sReturn += "|" + request.Return.ToString();

                return response;
            }
            catch (Exception e)
            {
                throw (e);
            }

        }
        [HttpGet(nameof(MoveSpecContents))]
        public async Task<ActionResult<object>> MoveSpecContents([FromQuery] MoveSpecProductionDateContentsRequest request)
        {
            try
            {
                var response = await _repository.MoveSpecContents(request);
                return response;
            }
            catch (Exception e)
            {
                throw (e);
            }
        }
        [HttpGet(nameof(MoveRowContents))]
        public async Task<ActionResult<object>> MoveRowContents([FromQuery] MoveSpecProductionDateContentsRequest request)
        {
            try
            {
                var response = await _repository.MoveRowContents(request);
                return response;
            }
            catch (Exception e)
            {
                throw (e);
            }
        }
       
    }
}
