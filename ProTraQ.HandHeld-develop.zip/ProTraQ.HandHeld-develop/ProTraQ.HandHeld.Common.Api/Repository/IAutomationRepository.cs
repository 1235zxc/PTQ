﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.Common.Api.Repository
{
    public interface IAutomationRepository
    {
        /// <summary>
        /// Calls the Stored Procedure [AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_LocationID]
        /// </summary>
        /// <param name="LocationID"></param>
        /// <returns></returns>
        [Sql("[AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_LocationID]", CommandType.StoredProcedure)]
        AutomationLocationInformation GetAutomationLocationInfo(long LocationID);
        
        /// <summary>
        /// Calls the Stored Procedure [Automation].[usp_AutomationInventoryInfo_SELECT_ITEM_INVSN]
        /// </summary>
        /// <param name="palletID"></param>
        /// <returns></returns>
        [Sql("[Automation].[usp_AutomationInventoryInfo_SELECT_ITEM_INVSN]", CommandType.StoredProcedure)]
        AutomationInventoryInformation GetAutomationInventoryInfoByINVSN(string palletID);
        
        /// <summary>
        /// Calls the Stored Procedure [Automation].[usp_AutomationLocationInfo_SELECT_ITEM_AutomationSystemLocationCode]
        /// </summary>
        /// <param name="AutomationSystemLocationCode"></param>
        /// <returns></returns>
        [Sql("[Automation].[usp_AutomationLocationInfo_SELECT_ITEM_AutomationSystemLocationCode]", CommandType.StoredProcedure)]
        AutomationInventoryInformation GetAutomationLocationInfoByAutomationSystemLocationCode(string AutomationSystemLocationCode);

        /// <summary>
        /// Calls the Stored Procedure [Automation].[usp_AutomationInventoryInfo_UpdateLastRequest]
        /// </summary>
        /// <param name="ExchangePointDisplayLocationID"></param>
        /// <param name="LastRequestDetail"></param>
        /// <param name="LastRequestLocalDT"></param>
        /// <returns></returns>
        [Sql("[Automation].[usp_AutomationInventoryInfo_UpdateLastRequest]", CommandType.StoredProcedure)]
        AutomationInventoryInformation AutomationInventoryInfoUpdateLastRequest(string ExchangePointDisplayLocationID, string LastRequestDetail, DateTime LastRequestLocalDT);
    }
}
