﻿using Insight.Database;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProTraQ.HandHeld.Common.Api.Repository
{
    public interface IFlagRepository
    {
        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_FLAGS_SetFlagValue_MINIMAL]
        /// This sets one of the global tracking flags.
        /// (SilganMfg.ProTraQ.Constants.FLAG_[something])
        /// </summary>
        /// <param name="FlagName"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_FLAGS_SetFlagValue_MINIMAL]")]
        void usp_FLAGS_SetFlagValue_MINIMAL(string FlagName, string FlagSetting, string ModifiedBy);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_FLAGS_GetFlagValue]
        /// This gets one of the global tracking flags. See Constants project for more information.
        /// (SilganMfg.ProTraQ.Constants.FLAG_[something])
        /// </summary>
        /// <param name="FlagName"></param>
        /// <returns>Value</returns>
        [Sql("[dbo].[usp_FLAGS_GetFlagValue]")]
        void usp_FLAGS_GetFlagValue(string FlagName, out string Value);

    }
}
