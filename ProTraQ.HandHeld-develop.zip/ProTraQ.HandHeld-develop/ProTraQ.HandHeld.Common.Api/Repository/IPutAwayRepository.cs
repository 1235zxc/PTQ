﻿using Insight.Database;
using ProTraQ.Handheld.Shared;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.Common.Api.Repository;

public interface IPutAwayRepository
{
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ITEM_ForPutAway]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ITEM_ForPutAway]", CommandType.StoredProcedure)]
    Task<ItemInformation> GetItemInformationAsync(GetItemInformationRequest getItemInformation);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_LineLocationContents_OLDEST_ITEM_UPDATED]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_SELECT_LineLocationContents_OLDEST_ITEM_UPDATED]", CommandType.StoredProcedure)]
    Task<ItemInformation> GetLocationOldestItemInformationAsync(GetLocationOldestItemInformationRequest getItemInformation);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_LineLocationContents_OLDEST_ITEM_ALPHA_UPDATED]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_SELECT_LineLocationContents_OLDEST_ITEM_ALPHA_UPDATED]", CommandType.StoredProcedure)]
    Task<ItemInformation> GetDisplayLocationOldestItemInformationAsync(GetDisplayLocationOldestItemInformationRequest getItemInformation);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_CARTONS_Qty_SELECT_CartonQtyInfoForInvID]
    /// </summary>
    [Recordset(0, typeof(CartonInformation))]
    [Recordset(1, typeof(NotUsed))]
    [Recordset(2, typeof(ProcedureResult))]
    [Sql("[dbo].[usp_CARTONS_Qty_SELECT_CartonQtyInfoForInvID]", CommandType.StoredProcedure)]
    Task<Results<CartonInformation, NotUsed, ProcedureResult>> GetCartonInformationForItemAsync(GetCartonInformationForItemRequest getItemInformation);

    /// <summary>
    /// Calls the stored procedure: [AUTOMATION].[usp_AutomationInventoryInfo_SELECT_ITEM_INVID]
    /// </summary>
    [Sql("[AUTOMATION].[usp_AutomationInventoryInfo_SELECT_ITEM_INVID]", CommandType.StoredProcedure)]
    Task<AutomationInventoryInformation> getAutomationInventoryInfo_SELECT_ITEM_INVID(long InviD);
}
