﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using System.Data;

namespace ProTraQ.HandHeld.Common.Api.Repository;

public interface IManageRowRepository
{
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ITEM_ForPutAway]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_SELECT_FacilityContextList]", CommandType.StoredProcedure)]
    Task<List<Facility>> GetFacilityWarehouseCodes();
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_InventoryTypeList]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_SELECT_InventoryTypeList]", CommandType.StoredProcedure)]
    Task<List<Inventory>> GetInventoryTypeList();
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ContentsForRow_ALPHA]
    /// </summary>
    [Recordset(0, typeof(ItemInfo))]
    [Recordset(1, typeof(InventoryInfo))]
    [Recordset(2, typeof(ItemInfo))]
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForRow_ALPHA]", CommandType.StoredProcedure)]
    Task<Results<ItemInfo, InventoryInfo, ItemInfo>> GetRowContents_ALPHA(GetRowContentRequest request);
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ContentsForRow]
    /// </summary>
    [Recordset(0, typeof(ItemInfo))]
    [Recordset(1, typeof(InventoryInfo))]
    [Recordset(2, typeof(ItemInfo))]
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForRow]", CommandType.StoredProcedure)]
    Task<Results<ItemInfo, InventoryInfo, ItemInfo>> GetRowContents(GetRowContentRequest request);
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpec]
    /// </summary>
    [Recordset(0, typeof(ItemInfo))]
    [Recordset(1, typeof(InventoryInfo))]
    [Recordset(2, typeof(ItemInfo))]
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpec]", CommandType.StoredProcedure)]
    Task<Results<ItemInfo, InventoryInfo, ItemInfo>> GetSpecContents(GetRowContentRequest request);
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpecProdDate]
    /// </summary>
    [Recordset(0, typeof(ItemInfo))]
    [Recordset(1, typeof(InventoryInfo))]
    [Recordset(2, typeof(ItemInfo))]
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpecProdDate]", CommandType.StoredProcedure)]
    Task<Results<ItemInfo, InventoryInfo, ItemInfo>> GetSpecProdDateContents(GetRowContentRequest request);
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ContentsForIDorSn_LIKE]
    /// </summary>
    [Recordset(0, typeof(ItemInfo))]
    [Recordset(1, typeof(InventoryInfo))]
    [Recordset(2, typeof(ItemInfo))]
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForIDorSn_LIKE]", CommandType.StoredProcedure)]
    Task<Results<ItemInfo, InventoryInfo, ItemInfo>> GetInvIDLocationLIKE(GetRowContentRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_PutAwayItem_AsLost]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_PutAwayItem_AsLost]", CommandType.StoredProcedure)]
    Task<int?> PutAwayItemAsLost(PutAwayItemAsLostRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRow]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRow]", CommandType.StoredProcedure)]
    Task<Results<object>> MoveSpecProductionDateContents(MoveSpecProductionDateContentsRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_MoveSpecContents_ForRow]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_MoveSpecContents_ForRow]", CommandType.StoredProcedure)]
    Task<Results<object>> MoveSpecContents(MoveSpecProductionDateContentsRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_MoveRowContents_ForSpec]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_MoveRowContents_ForSpec]", CommandType.StoredProcedure)]
    Task<Results<object, object, object>> MoveRowContents(MoveSpecProductionDateContentsRequest request);

}
