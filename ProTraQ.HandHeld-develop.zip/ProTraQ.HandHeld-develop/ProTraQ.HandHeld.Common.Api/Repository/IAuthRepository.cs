﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using System.Data;

namespace ProTraQ.HandHeld.Common.Api.Repository;

public interface IAuthRepository
{
    /// <summary>
    /// Calls the Stored Procedure [dbo].[usp_SYSTEM_INFO_SELECT_FacilityInformation_ForFacility]
    /// </summary>
    /// <returns></returns>
    [Sql("[dbo].[usp_SYSTEM_INFO_SELECT_FacilityInformation_ForFacility]", CommandType.StoredProcedure)]
    Task<Facility> GetFacilityInfo();

}
