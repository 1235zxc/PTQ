﻿using Insight.Database;

namespace ProTraQ.HandHeld.Common.Api.Repository
{
    public interface IWarehouseRepository
    {
        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_PutAwayItem_ALPHA]
        /// </summary>
        /// <param name="InvID"></param>
        /// <param name="InvSN"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="UserName"></param>
        /// <param name="iReturn"></param>
        /// <param name="strConfirmMsg"></param>
        [Sql("[dbo].[usp_PUTAWAY_PutAwayItem_ALPHA]")]
        void usp_PUTAWAY_PutAwayItem_ALPHA(decimal InvID, string InvSN, string DisplayTargetLocationID, string UserName, out int iReturn, out string strConfirmMsg);
        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_PutAwayItem]
        /// </summary>
        /// <param name="InvID"></param>
        /// <param name="InvSN"></param>
        /// <param name="RowLocation"></param>
        /// <param name="UserName"></param>
        /// <param name="iReturn"></param>
        /// <param name="strConfirmMsg"></param>
        [Sql("[dbo].[usp_PUTAWAY_PutAwayItem]")]
        void usp_PUTAWAY_PutAwayItem(decimal InvID, string InvSN, long RowLocation, string UserName, out int iReturn, out string strConfirmMsg);

        //[Sql("[dbo].[usp_PUTAWAY_SELECT_FacilityContextList]")]
        //IList<Facilities> usp_PUTAWAY_SELECT_FacilityContextList(); TODO: Resolve model references 

        //[Sql("[dbo].[usp_PUTAWAY_SELECT_FacilityWarehousesNotOnProTraQ]")]
        //IList<Facilities> usp_PUTAWAY_SELECT_FacilityWarehousesNotOnProTraQ(); TODO: Resolve model references

        // Get data when searching
        // Row
        //[Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForRow_ALPHA]")]
        //Results<RowManagerGrpBySpec, RowManagerByItem, RowManagerGrpByDate> usp_PUTAWAY_SELECT_ContentsForRow_ALPHA(string DisplayLocationID, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return); TODO: Resolve model references

        // ItemSpec
        //[Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpec]")]
        //Results<RowManagerGrpBySpec, RowManagerByItem, RowManagerGrpByDate> usp_PUTAWAY_SELECT_ContentsForItemSpec(string ItemSpec, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return); TODO: Resolve model references

        // Item Spec & Production Date
        //[Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpecProdDate]")]
        //Results<RowManagerGrpBySpec, RowManagerByItem, RowManagerGrpByDate> usp_PUTAWAY_SELECT_ContentsForItemSpecProdDate(string ItemSpec, string ProductionDate, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return); TODO: Resolve model references

        // Item Spec & Production Date Range
        //[Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForItemSpecProdDateRange]")]
        //Results<RowManagerGrpBySpec, RowManagerByItem, RowManagerGrpByDate> usp_PUTAWAY_SELECT_ContentsForItemSpecProdDateRange(string ItemSpec, string ProductionDateStart, string ProductionDateEnd, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return); TODO: Resolve model references

        // Inv ID or SN EXACT
        //[Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForIDorSn_EXACT]")]
        //Results<RowManagerGrpBySpec, RowManagerByItem, RowManagerGrpByDate> usp_PUTAWAY_SELECT_ContentsForIDorSn_EXACT(string INV_OR_SN, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return); TODO: Resolve model references

        // Inv ID or SN LIKE
        //[Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForIDorSn_LIKE]")]
        //Results<RowManagerGrpBySpec, RowManagerByItem, RowManagerGrpByDate> usp_PUTAWAY_SELECT_ContentsForIDorSn_LIKE(string INV_OR_SN, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return); TODO: Resolve model references


        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveRowContents_ALPHA]
        /// Move and Clear Starts
        /// Move or Clear All When Searched by Row
        /// </summary>
        /// <param name="DisplaySourceLocationID"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveRowContents_ALPHA]")]
        string usp_PUTAWAY_MoveRowContents_ALPHA(string DisplaySourceLocationID, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecContents_ALPHA]
        /// ItemSpec
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecContents_ALPHA]")]
        string usp_PUTAWAY_MoveSpecContents_ALPHA(string ItemSpec, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveItemContents_EXACT_ALPHA]
        /// InvID or SN Exact - this is used when moving or clearing by for a row in the 2nd Grid (see below)
        /// </summary>
        /// <param name="INV_OR_SN"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveItemContents_EXACT_ALPHA]")]
        string usp_PUTAWAY_MoveItemContents_EXACT_ALPHA(string INV_OR_SN, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveItemContents_LIKE_ALPHA]
        /// InvID or SN Like
        /// </summary>
        /// <param name="INV_OR_SN"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveItemContents_LIKE_ALPHA]")]
        string usp_PUTAWAY_MoveItemContents_LIKE_ALPHA(string INV_OR_SN, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ALPHA]
        /// ItemSpec & Production Date
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="ProductionDate"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ALPHA]")]
        string usp_PUTAWAY_MoveSpecProdDateContents_ALPHA(string ItemSpec, string ProductionDate, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecProdDateRangeContents_ALPHA]
        /// ItemSpec & Production Date Range
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="ProductionDateStart"></param>
        /// <param name="ProductionDateEnd"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateRangeContents_ALPHA]")]
        string usp_PUTAWAY_MoveSpecProdDateRangeContents_ALPHA(string ItemSpec, string ProductionDateStart, string ProductionDateEnd, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);


        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecContents_ForRow_ALPHA]
        /// Move or Clear by Item in a Grid Row  
        /// Grid One - Row/ItemSpec.
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="SourceLocationID"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecContents_ForRow_ALPHA]")]
        string usp_PUTAWAY_MoveSpecContents_ForRow_ALPHA(string ItemSpec, long SourceLocationID, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);


        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRow_ALPHA]
        /// Grid Two Inv ID or SN
        /// this uses the same Stored Procedure as Inv ID or SN Exact from above
        /// Grid Three Prodution Date
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="SourceLocationID"></param>
        /// <param name="ProductionDate"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRow_ALPHA]")]
        string usp_PUTAWAY_MoveSpecProdDateContents_ForRow_ALPHA(string ItemSpec, long SourceLocationID, string ProductionDate, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveRowContents_ForSpec_ALPHA]
        /// </summary>
        /// <param name="SourceLocationID"></param>
        /// <param name="ItemSpec"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveRowContents_ForSpec_ALPHA]")]
        dynamic usp_PUTAWAY_MoveRowContents_ForSpec_ALPHA(long SourceLocationID, string ItemSpec, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRowWithinRange_ALPHA]
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="SourceLocationID"></param>
        /// <param name="ProductionDate"></param>
        /// <param name="ProductionDateStart"></param>
        /// <param name="ProductionDateEnd"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRowWithinRange_ALPHA]")]
        dynamic usp_PUTAWAY_MoveSpecProdDateContents_ForRowWithinRange_ALPHA(string ItemSpec, long SourceLocationID, string ProductionDate, string ProductionDateStart, string ProductionDateEnd, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_PUTAWAY_MoveSpecProdDateRangeContents_ForRow_ALPHA]
        /// Date Range - All - only clear or move all in this mode 
        /// </summary>
        /// <param name="ItemSpec"></param>
        /// <param name="SourceLocationID"></param>
        /// <param name="ProductionDateStart"></param>
        /// <param name="ProductionDateEnd"></param>
        /// <param name="DisplayTargetLocationID"></param>
        /// <param name="MarkAsLost"></param>
        /// <param name="FacilityContext"></param>
        /// <param name="InventoryTypeID"></param>
        /// <param name="IncludeLost"></param>
        /// <param name="IncludeResale"></param>
        /// <param name="IncludePR"></param>
        /// <param name="Return"></param>
        /// <param name="ReturnMsg"></param>
        /// <param name="Reget"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateRangeContents_ForRow_ALPHA]")]
        dynamic usp_PUTAWAY_MoveSpecProdDateRangeContents_ForRow_ALPHA(string ItemSpec, long SourceLocationID, string ProductionDateStart, string ProductionDateEnd, string DisplayTargetLocationID, bool MarkAsLost, long FacilityContext, int InventoryTypeID, int IncludeLost, int IncludeResale, int IncludePR, out int Return, out string ReturnMsg, bool Reget);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_INV_JDE_PT_Inventory_Comparison]
        /// </summary>
        /// <param name="thisGLCproduct"></param>
        /// <param name="thisCOC"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_INV_JDE_PT_Inventory_Comparison]")]
        dynamic usp_INV_JDE_PT_Inventory_Comparison(string thisGLCproduct, string thisCOC);

        /// <summary>
        /// Calls the Stored Procedure [dbo].[usp_INV_JDE_PT_Inventory_Selection]
        /// </summary>
        /// <param name="thisGLCproduct"></param>
        /// <param name="thisCOC"></param>
        /// <param name="location"></param>
        /// <returns></returns>
        [Sql("[dbo].[usp_INV_JDE_PT_Inventory_Selection]")]
        dynamic usp_INV_JDE_PT_Inventory_Selection(string thisGLCproduct, string thisCOC, string location);
    }
}
