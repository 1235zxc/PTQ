﻿
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.Common.Api.Services
{
    public class FlagInfoService
    {

        #region SYSTEM INFORMATION
        public const string FLAG_FacilityNumber = "FacilityNumber";
        public const string FLAG_CURRENT_FACILITY = "FacilityID";   // Find the Facility ID.
        public const string PROTRAQ_VERSION_NUMBER = "ProTraQVersionNumber";
        public const string AIS_BYPASS_TRANSFORMIDS = "AIS_BYPASS_TRANSFORMIDS";
        #endregion

        #region COATER
        public const string COATER_COMPLETION_PERCENTAGE = "COATER_COMPLETION_PERCENTAGE";
        public const string COATER_FINALIZE_PERCENTAGE = "COATER_FINALIZE_PERCENTAGE";
        public const string COATER_SHOW_RETURN_TO_STORAGE = "COATER_SHOW_RETURN_TO_STORAGE";
        public const string COATER_ALLOW_AUTOLOADING_ON_FINALIZE = "COATER_ALLOW_AUTOLOADING_ON_FINALIZE";
        public const string COATER_SHOW_STACKED_ITEMS = "COATER_SHOW_STACKED_ITEMS";
        public const string COATER_RESET_UNTAGGED_BUNDLE_FLAG_ON_JOB_CLOSE = "COATER_RESET_UNTAGGED_BUNDLE_FLAG_ON_JOB_CLOSE";

        public const string COATER_SPLIT_PRIME_PLATE_BEHAVIOR_DEFAULT = "COATER_SPLIT_PRIME_PLATE_BEHAVIOR_DEFAULT";
        public const string COATER_SPLIT_COATED_PLATE_BEHAVIOR_DEFAULT = "COATER_SPLIT_COATED_PLATE_BEHAVIOR_DEFAULT";
        public const string COATER_SPLIT_ALLOW_REMOVE_AND_HOLD = "COATER_SPLIT_ALLOW_REMOVE_AND_HOLD";
        public const string COATER_SPLIT_ALLOW_REMOVE_ONLY = "COATER_SPLIT_ALLOW_REMOVE_ONLY";
        public const string COATER_SPLIT_ALLOW_CONTINUE = "COATER_SPLIT_ALLOW_CONTINUE";


        #endregion

        #region TRACKING
        public const string TRACKING_ACTIVITY_BUNDLEOPS = "TRACKING_ACTIVITY_BUNDLEOPS";
        public const string TRACKING_ACTIVITY_COIL = "TRACKING_ACTIVITY_COIL";
        public const string TRACKING_ACTIVITY_ENDMAKING = "TRACKING_ACTIVITY_ENDMAKING";
        public const string TRACKING_ACTIVITY_FINISHEDGOOD = "TRACKING_ACTIVITY_FINISHEDGOOD";
        public const string TRACKING_ACTIVITY_MATERIALSRECEIVING = "TRACKING_ACTIVITY_MATERIALSRECEIVING";
        public const string TRACKING_ACTIVITY_PLATECOATING = "TRACKING_ACTIVITY_PLATECOATING";
        public const string TRACKING_ACTIVITY_SCHEDULE = "TRACKING_ACTIVITY_SCHEDULE";
        public const string TRACKING_ACTIVITY_SYSCONFIG = "TRACKING_ACTIVITY_SYSCONFIG";
        #endregion

        #region COIL
        public const string COIL_DISPLAY_SCRAP = "COIL_DISPLAY_SCRAP";// Added by FWL:
        public const string COIL_DISPLAY_WELD_COUNT = "COIL_DISPLAY_WELD_COUNT";// Added by FWL:
        public const string COIL_FLOOR_HISTORY_REPORTID = "COIL_FLOOR_HISTORY_REPORTID";// Added by RPC:
        public const string COIL_COMPLETION_PERCENTAGE = "COIL_COMPLETION_PERCENTAGE"; // Added by FWL

        public const string COIL_SCHEDULE_HIDE_COATLINES = "COIL_SCHEDULE_HIDE_COATLINES"; // Added by FWL
        #endregion

        #region BUNDLE_TAG_COUNTS
        public const string BUNDLE_TAG_FINAL_COPIES = "BUNDLE_TAG_FINAL_COPIES";
        public const string BUNDLE_TAG_PRIME_COPIES = "BUNDLE_TAG_PRIME_COPIES";
        public const string BUNDLE_TAG_REJECT_COPIES = "BUNDLE_TAG_REJECT_COPIES";
        public const string BUNDLE_TAG_WIP_COPIES = "BUNDLE_TAG_WIP_COPIES";


        public const string BUNDLE_TAG_HOLD_COIL_COPIES = "BUNDLE_TAG_HOLD_COIL_COPIES";
        public const string BUNDLE_TAG_HOLD_PLATE_COPIES = "BUNDLE_TAG_HOLD_PLATE_COPIES";
        public const string BUNDLE_TAG_HOLD_CANS_COPIES = "BUNDLE_TAG_HOLD_CANS_COPIES";
        public const string BUNDLE_TAG_HOLD_ENDS_COPIES = "BUNDLE_TAG_HOLD_ENDS_COPIES";

        #endregion

        #region SUPPORT
        public const string SUPPORT_NAME = "SUPPORT_NAME";
        public const string SUPPORT_PHONE_NUMBER = "SUPPORT_PHONE_NUMBER";
        public const string SUPPORT_EMAIL_ADDRESS = "SUPPORT_EMAIL_ADDRESS";
        #endregion

        #region COIL UPLOADS
        public const string COIL_UPLOAD_START_DATE = "COIL_UPLOAD_START_DATE";
        public const string COIL_CENTER = "COIL_CENTER";
        public const string TABSTOCK_CENTER = "TABSTOCK_CENTER";
        #endregion

        #region PHYSICAL INVENTORY FlagInfoService.
        public const string PHYSICAL_INVENTORY_DEFAULT_NUMBER_OF_TEAMS = "PHYSICAL_INVENTORY_DEFAULT_NUMBER_OF_TEAMS";
        public const string PHYSICAL_INVENTORY_DEFAULT_NUMBER_OF_SCANS = "PHYSICAL_INVENTORY_DEFAULT_NUMBER_OF_SCANS";
        public const string PHYSICAL_INVENTORY_USER_TIMEOUT_VALUE = "PHYSICAL_INVENTORY_USER_TIMEOUT_VALUE";
        public const string PHYSICAL_INVENTORY_ALLOW_BUNDLE_MARKING = "PHYSICAL_INVENTORY_ALLOW_BUNDLE_MARKING";
        public const string PHYSICAL_INVENTORY_SHOW_UNSCANNED_ITEM_VERIFY = "PHYSICAL_INVENTORY_SHOW_UNSCANNED_ITEM_VERIFY";
        public const string PHYSICAL_INVENTORY_SHOW_UNEXPECTED_ITEM_VERIFY = "PHYSICAL_INVENTORY_SHOW_UNEXPECTED_ITEM_VERIFY";
        #endregion

        #region "Sort station"
        public const string SORT_STATION_COUNT = "SORT_STATION_COUNT";
        #endregion

        #region SHIPPING
        public const string SHIPPING_ALLOW_ORDER_EDITING = "SHIPPING_ALLOW_ORDER_EDITING";
        public const string SHIPPING_DOCK_SCHEDULING_ENABLED = "SHIPPING_DOCK_SCHEDULING_ENABLED";
        public const string SHIPPING_TRAILER_SCHEDULING_ENABLED = "SHIPPING_TRAILER_SCHEDULING_ENABLED";
        public const string SHIPPING_VALIDATION_REQUIRE_CURE_TIME = "SHIPPING_VALIDATION_REQUIRE_CURE_TIME";
        public const string SHIPPING_QUANTITY_VALIDATION = "SHIPPING_QUANTITY_VALIDATION";
        public const string SHIPPING_SHIP_HFI_FOR_SW_ORDERS = "SHIPPING_SHIP_HFI_FOR_SW_ORDERS";
        public const string SHIPPING_REQUIRE_USER_IDENTIFICATION = "SHIPPING_REQUIRE_USER_IDENTIFICATION";
        public const string SHIPPING_SHIP_TO_ALLOW_UNKNOWN = "SHIPPING_SHIP_TO_ALLOW_UNKNOWN";
        public const string SHIPPING_VALIDATION_REQUIRE_SHIP_TO = "SHIPPING_VALIDATION_REQUIRE_SHIP_TO";
        public const string SHIPPING_DOCK_VERIFICATION_REQUIRED = "SHIPPING_DOCK_VERIFICATION_REQUIRED";
        public const string SHIPPING_WEIGHT_MAXIMUM = "SHIPPING_WEIGHT_MAXIMUM";
        public const string SHIPPING_ALLOW_OVERWEIGHT_ORDERS_TO_CLOSE = "SHIPPING_ALLOW_OVERWEIGHT_ORDERS_TO_CLOSE";
        public const string SHIPPING_SUPPORTS_REMOTE_POSITIVE_RELEASE = "SHIPPING_SUPPORTS_REMOTE_POSITIVE_RELEASE";
        //2016 02 jp removed the D
        //public const string SHIPPING_REQUIRE_VAN_NUMBER = "SHIPPING_REQUIRED_VAN_NUMBER";
        public const string SHIPPING_REQUIRE_VAN_NUMBER = "SHIPPING_REQUIRE_VAN_NUMBER";
        public const string SHIPPING_REQUIRE_SEAL_NUMBER = "SHIPPING_REQUIRE_SEAL_NUMBER";

        //2015 04 JP
        #region BOL
        public const string BOL_PRINT_SHIPPING = "BOL_PRINT_SHIPPING";
        //2015 08 JP
        public const string BOL_PRINT_SHIPPING_NBR_OF_COPIES = "BOL_PRINT_SHIPPING_NBR_OF_COPIES";
        public const string BOL_PRINT_FORMAT = "BOL_PRINT_FORMAT";
        //2016 01 JP
        public const string RFSMART_SHIPREC_NOTICE = "RFSMART_SHIPREC_NOTICE";
        //2016 05 JP
        public const string SHIPPING_VIT_DEFAULT = "SHIPPING_VIT_DEFAULT";
        //2020 08 JP
        public const string FG_SCHEDULE_ALLOW_OVERPRODUCTION = "FG_SCHEDULE_ALLOW_OVERPRODUCTION";
        public const string RECEIVING_INSPECTION_REQUIRED = "RECEIVING_INSPECTION_REQUIRED";
        //2021 08 jp
        public const string FG_SCHEDULE_WOPARTSLIST_shopfloor_behavior = "FG_SCHEDULE_WOPARTSLIST_shopfloor_behavior";
        #endregion

        #endregion

        #region FINISHED_GOODS

        public const string FG_WORKSTATION_MAX_TIME_ADJUSTMENT = "FG_WORKSTATION_MAX_TIME_ADJUSTMENT";
        public const string FG_WORKSTATION_REQUIRE_TIMESELECT = "FG_WORKSTATION_REQUIRE_TIMESELECT";
        public const string FG_SCHEDULE_SUBWHITELIST = "FG_SCHEDULE_SUBWHITELIST";
        public const string FG_SCHEDULE_CHANGEOVER_HOURS_DEFAULT = "FG_SCHEDULE_CHANGEOVER_HOURS_DEFAULT";
        public const string FG_SCHEDULE_DEFAULT_TO_AUTOCLOSE = "FG_SCHEDULE_DEFAULT_TO_AUTOCLOSE";
        public const string FG_SCHEDULE_DEFAULT_FOR_PRIORITY = "FG_SCHEDULE_DEFAULT_FOR_PRIORITY";
        public const string FG_VALIDATION_ALLOW_PACKCODE_SUBS = "FG_VALIDATION_ALLOW_PACKCODE_SUBS";
        public const string FG_TAG_FINAL_COPIES = "FG_TAG_FINAL_COPIES";
        public const string FG_TAG_SHELL_COPIES = "FG_TAG_SHELL_COPIES";
        public const string FG_TAG_NYPE_COPIES = "FG_TAG_NYPE_COPIES";
        public const string FG_UNCURED_BEHAVIOR = "FG_UNCURED_BEHAVIOR";

        public const string FG_SCHEDULE_CARTONS_PER_PALLET_REQUIREMENT = "FG_SCHEDULE_CARTONS_PER_PALLET_REQUIREMENT";// SWA 2014.11.10
        public const string FG_SCHEDULE_MOLD_REQUIREMENT = "FG_SCHEDULE_MOLD_REQUIREMENT";// SWA 2014.11.10
        public const string FG_SCHEDULE_DEFAULT_VIEW = "FG_SCHEDULE_DEFAULT_VIEW";

        public const string FG_WORKSTATION_ONLYSUP_CHANGEPRINTER = "FG_WORKSTATION_ONLYSUP_CHANGEPRINTER";
        public const string FG_WORKSTATION_DISABLE_HOLDS = "FG_WORKSTATION_DISABLE_HOLDS";
        public const string FG_SORT_STATIONS = "FG_SORT_STATIONS";
        public const string FG_HANDHELD_ALLOW_FLOOR_CHANGEOVER = "FG_HANDHELD_ALLOW_FLOOR_CHANGEOVER";
        public const string FG_HANDHELD_ALLOW_FLOOR_LOAD = "FG_HANDHELD_ALLOW_FLOOR_LOAD";
        public const string FG_SORT_LINEID = "FG_SORT_LINEID";

        //2015 09 jp
        public const string FG_SPLITCAP_HIDE_EACHES = "FG_SPLITCAP_HIDE_EACHES";

        public const string FG_COUNTERS_RESET_BEHAVIOR = "FG_COUNTERS_RESET_BEHAVIOR";
        public const string FG_SCHEDULE_SHOW_SPEC_WARNINGS = "FG_SCHEDULE_SHOW_SPEC_WARNINGS";
        public const string FG_LOS_SHOW_WORK_ORDERS = "FG_LOS_SHOW_WORK_ORDERS";
        public const string FG_COILCOAT_ROUND_BB = "FG_COILCOAT_ROUND_BB";

        public const string TAG_NESTLE_END_CODE = "TAG_NESTLE_END_CODE";
        public const string TAG_NESTLE_CAN_CODE = "TAG_NESTLE_CAN_CODE";


        #endregion

        #region PUTAWAY
        //  NO OPTIONS AT PRESENT - SEE TABLE tblRowLocations to CONFIGURE PUT AWAY RESTRICTIONS
        public const string PUTAWAY_ALLOW_CHANGE_STATUS_ON_HANDHELD = "PUTAWAY_ALLOW_CHANGE_STATUS";
        public const string PUTAWAY_SHOW_PUTAWAY_IN_RECEIVING = "PUTAWAY_SHOW_PUTAWAY_IN_RECEIVING";
        public const string PUTAWAY_LOCATION_LENGTH_VALUE = "PUTAWAY_LOCATION_LENGTH_VALUE"; // valid values NORMAL or MAX
        #endregion

        #region "QA"
        public const string QA_ClaimSystem = "QA_ClaimSystem";
        #endregion

        //2015 04 JP
        #region WorkOrder
        public const string WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_FG = "WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_FG";
        public const string WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_COAT_COILS = "WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_COAT_COILS";
        public const string WORKORDERS_ENABLE_CREATION_FROM_E1_BY_USER = "WORKORDERS_ENABLE_CREATION_FROM_E1_BY_USER";
        #endregion

        #region PI-to-ERP Upload
        public const string PI_TO_ERP_COIL_LOCATION_MODE = "PI_TO_ERP_COIL_LOCATION_MODE";
        public const string PI_TO_ERP_CLAIM_COIL_MODE = "PI_TO_ERP_CLAIM_COIL_MODE";
        public const string PI_TO_ERP_CLAIM_PLATE_MODE = "PI_TO_ERP_CLAIM_PLATE_MODE";
        public const string PI_TO_ERP_CLAIM_FG_MODE = "PI_TO_ERP_CLAIM_FG_MODE";
        #endregion

        #region Handheld Display Tuning
        public const string HH_EXT_DISPLAY_SHIPPING_PRINT_DESIGN = "HH_EXT_DISPLAY_SHIPPING_PRINT_DESIGN";
        #endregion

        #region RECEIVING
        public const string RECEIVING_INSPECTION_ACTIVE = "RECEIVING_INSPECTION_ACTIVE";
        #endregion
        #region Function: GetFlagString (based on enum input...)
        /// <summary>
        /// Given a parameter it returns the correct flag.
        /// </summary>
        /// <param name="eFlag"></param>
        /// <returns></returns>
        public static string GetFlagString(ProTraQFlagEnum eFlag)
        {
            string sReturn = "";
            switch (eFlag)
            {
                case ProTraQFlagEnum.FacilityID:
                    {
                        sReturn = FLAG_CURRENT_FACILITY;
                        break;
                    }
                case ProTraQFlagEnum.ProTraQVersionNumber:
                    {
                        sReturn = PROTRAQ_VERSION_NUMBER;
                        break;
                    }
                case ProTraQFlagEnum.FacilityNumber:
                    {
                        sReturn = FLAG_FacilityNumber;
                        break;
                    }


                //2020 10 22 jp
                case ProTraQFlagEnum.AIS_BYPASS_TRANSFORMIDS: { return FlagInfoService.AIS_BYPASS_TRANSFORMIDS; }


                case ProTraQFlagEnum.CoaterJobCompletionPercentage:
                    { sReturn = COATER_COMPLETION_PERCENTAGE; break; }

                case ProTraQFlagEnum.CoilScheduleHideCoatLines:
                    { sReturn = COIL_SCHEDULE_HIDE_COATLINES; break; }

                case ProTraQFlagEnum.CoaterBundleFinalizationPercentage:
                    { sReturn = COATER_FINALIZE_PERCENTAGE; break; }

                case ProTraQFlagEnum.CoaterShowReturnToStorage:
                    { sReturn = COATER_SHOW_RETURN_TO_STORAGE; break; }

                case ProTraQFlagEnum.CoaterAllowAutomaticLoadOnFinalize:
                    { sReturn = COATER_ALLOW_AUTOLOADING_ON_FINALIZE; break; }

                case ProTraQFlagEnum.CoaterShowStackedItems:
                    {
                        sReturn = COATER_SHOW_STACKED_ITEMS; break;
                    }
                case ProTraQFlagEnum.CoaterResetUntaggedBundleFlagOnJobClose:
                    {
                        sReturn = COATER_RESET_UNTAGGED_BUNDLE_FLAG_ON_JOB_CLOSE; break;
                    }
                case ProTraQFlagEnum.CoaterSplitCoatedPlateDefault:
                    {
                        sReturn = COATER_SPLIT_COATED_PLATE_BEHAVIOR_DEFAULT;
                        break;
                    }
                case ProTraQFlagEnum.CoaterSplitPrimePlateDefault:
                    {
                        sReturn = COATER_SPLIT_PRIME_PLATE_BEHAVIOR_DEFAULT;
                        break;
                    }

                case ProTraQFlagEnum.CoaterSplitAllowRemoveAndHold:
                    {
                        sReturn = COATER_SPLIT_ALLOW_REMOVE_AND_HOLD;
                        break;
                    }

                case ProTraQFlagEnum.CoaterSplitAllowRemoveOnly:
                    {
                        sReturn = COATER_SPLIT_ALLOW_REMOVE_ONLY;
                        break;
                    }

                case ProTraQFlagEnum.CoaterSplitAllowContinue:
                    {
                        sReturn = COATER_SPLIT_ALLOW_CONTINUE;
                        break;
                    }

                case ProTraQFlagEnum.Tracking_BundleOperations:
                    { sReturn = TRACKING_ACTIVITY_BUNDLEOPS; break; }

                case ProTraQFlagEnum.Tracking_Coil:
                    { sReturn = TRACKING_ACTIVITY_COIL; break; }

                case ProTraQFlagEnum.Tracking_EndMaking:
                    { sReturn = TRACKING_ACTIVITY_ENDMAKING; break; }

                case ProTraQFlagEnum.Tracking_FinishedGoods:
                    { sReturn = TRACKING_ACTIVITY_FINISHEDGOOD; break; }

                case ProTraQFlagEnum.Tracking_MaterialsReceiving:
                    { sReturn = TRACKING_ACTIVITY_MATERIALSRECEIVING; break; }

                case ProTraQFlagEnum.Tracking_PlateCoating:
                    { sReturn = TRACKING_ACTIVITY_PLATECOATING; break; }

                case ProTraQFlagEnum.Tracking_Schedule:
                    { sReturn = TRACKING_ACTIVITY_SCHEDULE; break; }

                case ProTraQFlagEnum.Tracking_SystemConfig:
                    { sReturn = TRACKING_ACTIVITY_SYSCONFIG; break; }

                case ProTraQFlagEnum.Coil_DisplayScrap:
                    { sReturn = COIL_DISPLAY_SCRAP; break; }

                case ProTraQFlagEnum.Coil_DisplayWeldCount:
                    { sReturn = COIL_DISPLAY_WELD_COUNT; break; }

                case ProTraQFlagEnum.Coil_FloorHistoryReportID:
                    { sReturn = COIL_FLOOR_HISTORY_REPORTID; break; }

                case ProTraQFlagEnum.CoilUploadStartDate:
                    { sReturn = COIL_UPLOAD_START_DATE; break; }

                case ProTraQFlagEnum.CoilUploadCoilCenter:
                    { sReturn = COIL_CENTER; break; }

                case ProTraQFlagEnum.CoilUploadTabstockCenter:
                    { sReturn = TABSTOCK_CENTER; break; }

                case ProTraQFlagEnum.BundleTagCopiesPrime:
                    { sReturn = BUNDLE_TAG_PRIME_COPIES; break; }

                case ProTraQFlagEnum.BundleTagCopiesReject:
                    { sReturn = BUNDLE_TAG_REJECT_COPIES; break; }

                case ProTraQFlagEnum.BundleTagCopiesWIP:
                    { sReturn = BUNDLE_TAG_WIP_COPIES; break; }

                case ProTraQFlagEnum.BundleTagCopiesFinal:
                    { sReturn = BUNDLE_TAG_FINAL_COPIES; break; }

                case ProTraQFlagEnum.SupportName:
                    { sReturn = FlagInfoService.SUPPORT_NAME; break; }

                case ProTraQFlagEnum.SupportPhoneNumber:
                    { sReturn = FlagInfoService.SUPPORT_PHONE_NUMBER; break; }

                case ProTraQFlagEnum.SupportEmailAddress:
                    { sReturn = FlagInfoService.SUPPORT_EMAIL_ADDRESS; break; }

                case ProTraQFlagEnum.PhysicalInventory_DefaultNumberOfTeams:
                    { sReturn = FlagInfoService.PHYSICAL_INVENTORY_DEFAULT_NUMBER_OF_TEAMS; break; }

                case ProTraQFlagEnum.PhysicalInventory_DefaultNumberOfScans:
                    { sReturn = FlagInfoService.PHYSICAL_INVENTORY_DEFAULT_NUMBER_OF_SCANS; break; }

                case ProTraQFlagEnum.PhysicalInventory_UserTimeoutValue:
                    { sReturn = FlagInfoService.PHYSICAL_INVENTORY_USER_TIMEOUT_VALUE; break; }

                case ProTraQFlagEnum.PhysicalInventory_AllowBundleMarking:
                    { sReturn = FlagInfoService.PHYSICAL_INVENTORY_ALLOW_BUNDLE_MARKING; break; }

                case ProTraQFlagEnum.PhysicalInventory_ShowUnscannedItemVerify:
                    { sReturn = FlagInfoService.PHYSICAL_INVENTORY_SHOW_UNSCANNED_ITEM_VERIFY; break; }

                case ProTraQFlagEnum.PhysicalInventory_ShowUnexpectedItemVerify:
                    { sReturn = FlagInfoService.PHYSICAL_INVENTORY_SHOW_UNEXPECTED_ITEM_VERIFY; break; }

                // Added by FWL:
                case ProTraQFlagEnum.CoilCompletionPercentage:
                    { sReturn = FlagInfoService.COIL_COMPLETION_PERCENTAGE; break; }

                case ProTraQFlagEnum.SortStationCount:
                    sReturn = FlagInfoService.SORT_STATION_COUNT;
                    break;
                case ProTraQFlagEnum.Shipping_AllowOrderEditing: { sReturn = FlagInfoService.SHIPPING_ALLOW_ORDER_EDITING; break; }
                case ProTraQFlagEnum.Shipping_DockSchedulingEnabled: { sReturn = FlagInfoService.SHIPPING_DOCK_SCHEDULING_ENABLED; break; }
                case ProTraQFlagEnum.Shipping_TrailerSchedulingEnabled: { sReturn = FlagInfoService.SHIPPING_TRAILER_SCHEDULING_ENABLED; break; }
                case ProTraQFlagEnum.Shipping_QuantityValidationAllowed: { sReturn = FlagInfoService.SHIPPING_QUANTITY_VALIDATION; break; }
                case ProTraQFlagEnum.Shipping_ShipHFIForWarehouseOrders: { sReturn = FlagInfoService.SHIPPING_SHIP_HFI_FOR_SW_ORDERS; break; }
                case ProTraQFlagEnum.Shipping_ValidationRequiresCureTime: { sReturn = FlagInfoService.SHIPPING_VALIDATION_REQUIRE_CURE_TIME; break; }
                case ProTraQFlagEnum.Shipping_RequireUserIdentification: { sReturn = FlagInfoService.SHIPPING_REQUIRE_USER_IDENTIFICATION; break; }
                case ProTraQFlagEnum.Shipping_ValidationRequiresShipTo: { sReturn = FlagInfoService.SHIPPING_VALIDATION_REQUIRE_SHIP_TO; break; }
                case ProTraQFlagEnum.Shipping_DockVerificationRequired: { sReturn = FlagInfoService.SHIPPING_DOCK_VERIFICATION_REQUIRED; break; }
                case ProTraQFlagEnum.Shipping_ShipToAllowUnknown: { sReturn = FlagInfoService.SHIPPING_SHIP_TO_ALLOW_UNKNOWN; break; }
                case ProTraQFlagEnum.Shipping_WeightMaximum: { sReturn = FlagInfoService.SHIPPING_WEIGHT_MAXIMUM; break; }
                case ProTraQFlagEnum.Shipping_AllowOverweightOrdersToClose: { sReturn = FlagInfoService.SHIPPING_ALLOW_OVERWEIGHT_ORDERS_TO_CLOSE; break; }
                case ProTraQFlagEnum.Shipping_SupportsRemotePositiveRelease: { sReturn = FlagInfoService.SHIPPING_SUPPORTS_REMOTE_POSITIVE_RELEASE; break; }
                case ProTraQFlagEnum.Shipping_RequireVanNumber: { sReturn = FlagInfoService.SHIPPING_REQUIRE_VAN_NUMBER; break; } // SWA 2013.03.22
                case ProTraQFlagEnum.Shipping_RequireSealNumber: { sReturn = FlagInfoService.SHIPPING_REQUIRE_SEAL_NUMBER; break; } // SWA 2013.03.22

                case ProTraQFlagEnum.FG_Workstation_MaxTimeAdjustment: { sReturn = FlagInfoService.FG_WORKSTATION_MAX_TIME_ADJUSTMENT; break; }
                case ProTraQFlagEnum.FG_Workstation_RequireTimeSelect: { sReturn = FlagInfoService.FG_WORKSTATION_REQUIRE_TIMESELECT; break; }
                case ProTraQFlagEnum.FG_Schedule_SubWhiteList: { sReturn = FlagInfoService.FG_SCHEDULE_SUBWHITELIST; break; }
                case ProTraQFlagEnum.FG_Schedule_ChangeoverHoursDefault: { sReturn = FlagInfoService.FG_SCHEDULE_CHANGEOVER_HOURS_DEFAULT; break; }
                case ProTraQFlagEnum.FG_Validation_AllowPackcodeSubs: { sReturn = FlagInfoService.FG_VALIDATION_ALLOW_PACKCODE_SUBS; break; }
                case ProTraQFlagEnum.FG_SCHEDULE_DEFAULT_TO_AUTOCLOSE: { sReturn = FlagInfoService.FG_SCHEDULE_DEFAULT_TO_AUTOCLOSE; break; }
                case ProTraQFlagEnum.FG_SCHEDULE_DEFAULT_FOR_PRIORITY: { sReturn = FlagInfoService.FG_SCHEDULE_DEFAULT_FOR_PRIORITY; break; }
                case ProTraQFlagEnum.FG_SCHEDULE_MOLD_REQUIREMENT: { sReturn = FlagInfoService.FG_SCHEDULE_MOLD_REQUIREMENT; break; } // SWA 2014.11.10
                case ProTraQFlagEnum.FG_SCHEDULE_DEFAULT_VIEW: { sReturn = FlagInfoService.FG_SCHEDULE_DEFAULT_VIEW; break; }
                case ProTraQFlagEnum.FG_SCHEDULE_CARTONS_PER_PALLET_REQUIREMENT: { sReturn = FlagInfoService.FG_SCHEDULE_CARTONS_PER_PALLET_REQUIREMENT; break; }// SWA 2014.11.10

                case ProTraQFlagEnum.FG_Tag_Final_Copies: { sReturn = FlagInfoService.FG_TAG_FINAL_COPIES; break; }
                case ProTraQFlagEnum.FG_Tag_Shell_Copies: { sReturn = FlagInfoService.FG_TAG_SHELL_COPIES; break; }
                case ProTraQFlagEnum.FG_Tag_NYPE_Copies: { sReturn = FlagInfoService.FG_TAG_NYPE_COPIES; break; }
                case ProTraQFlagEnum.FG_UNCURED_BEHAVIOR: { sReturn = FlagInfoService.FG_UNCURED_BEHAVIOR; break; }


                case ProTraQFlagEnum.FG_WORKSTATION_ONLYSUP_CHANGEPRINTER: { sReturn = FlagInfoService.FG_WORKSTATION_ONLYSUP_CHANGEPRINTER; break; }
                case ProTraQFlagEnum.FG_WORKSTATION_DISABLE_HOLDS: { sReturn = FlagInfoService.FG_WORKSTATION_DISABLE_HOLDS; break; }

                case ProTraQFlagEnum.FG_SORT_STATIONS: { sReturn = FlagInfoService.FG_SORT_STATIONS; break; }
                case ProTraQFlagEnum.FG_SORT_LINEID: { sReturn = FlagInfoService.FG_SORT_LINEID; break; }

                //2015 09 jp
                case ProTraQFlagEnum.FG_SPLITCAP_HIDE_EACHES: { sReturn = FlagInfoService.FG_SPLITCAP_HIDE_EACHES; break; }

                case ProTraQFlagEnum.FG_HANDHELD_ALLOW_FLOOR_CHANGEOVER: { sReturn = FlagInfoService.FG_HANDHELD_ALLOW_FLOOR_CHANGEOVER; break; }
                case ProTraQFlagEnum.FG_HANDHELD_ALLOW_FLOOR_LOAD: { sReturn = FlagInfoService.FG_HANDHELD_ALLOW_FLOOR_LOAD; break; }
                case ProTraQFlagEnum.BUNDLE_TAG_HOLD_COIL_COPIES: { sReturn = FlagInfoService.BUNDLE_TAG_HOLD_COIL_COPIES; break; }
                case ProTraQFlagEnum.BUNDLE_TAG_HOLD_PLATE_COPIES: { sReturn = FlagInfoService.BUNDLE_TAG_HOLD_PLATE_COPIES; break; }
                case ProTraQFlagEnum.BUNDLE_TAG_HOLD_CANS_COPIES: { sReturn = FlagInfoService.BUNDLE_TAG_HOLD_CANS_COPIES; break; }
                case ProTraQFlagEnum.BUNDLE_TAG_HOLD_ENDS_COPIES: { sReturn = FlagInfoService.BUNDLE_TAG_HOLD_ENDS_COPIES; break; }

                case ProTraQFlagEnum.FG_COUNTERS_RESET_BEHAVIOR: { sReturn = FlagInfoService.FG_COUNTERS_RESET_BEHAVIOR; break; }
                case ProTraQFlagEnum.FG_SCHEDULE_SHOW_SPEC_WARNINGS: { sReturn = FlagInfoService.FG_SCHEDULE_SHOW_SPEC_WARNINGS; break; }
                case ProTraQFlagEnum.FG_LOS_SHOW_WORK_ORDERS: { sReturn = FlagInfoService.FG_LOS_SHOW_WORK_ORDERS; break; }
                case ProTraQFlagEnum.FG_COILCOAT_ROUND_BB: { sReturn = FlagInfoService.FG_COILCOAT_ROUND_BB; break; }

                case ProTraQFlagEnum.TAG_NESTLE_END_CODE: { sReturn = FlagInfoService.TAG_NESTLE_END_CODE; break; }
                case ProTraQFlagEnum.TAG_NESTLE_CAN_CODE: { sReturn = FlagInfoService.TAG_NESTLE_CAN_CODE; break; }
                case ProTraQFlagEnum.PUTAWAY_AllowChangeStatusOnHH: { return FlagInfoService.PUTAWAY_ALLOW_CHANGE_STATUS_ON_HANDHELD; }
                case ProTraQFlagEnum.PUTAWAY_ShowInReceivingOnHH: { return FlagInfoService.PUTAWAY_SHOW_PUTAWAY_IN_RECEIVING; }
                case ProTraQFlagEnum.PUTAWAY_LocationLengthValue: { return FlagInfoService.PUTAWAY_LOCATION_LENGTH_VALUE; }

                case ProTraQFlagEnum.QA_ClaimSystem: { return FlagInfoService.QA_ClaimSystem; }
                //2015 04 JP s
                case ProTraQFlagEnum.WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_FG: { return FlagInfoService.WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_FG; }
                case ProTraQFlagEnum.WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_COAT_COILS: { return FlagInfoService.WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_COAT_COILS; }
                case ProTraQFlagEnum.WORKORDERS_ENABLE_CREATION_FROM_E1_BY_USER: { return FlagInfoService.WORKORDERS_ENABLE_CREATION_FROM_E1_BY_USER; }
                case ProTraQFlagEnum.BOL_PRINT_SHIPPING: { return FlagInfoService.BOL_PRINT_SHIPPING; }
                //2015 04 JP e
                //2015 08 JP s
                case ProTraQFlagEnum.BOL_PRINT_SHIPPING_NBR_OF_COPIES: { return FlagInfoService.BOL_PRINT_SHIPPING_NBR_OF_COPIES; }
                case ProTraQFlagEnum.BOL_PRINT_FORMAT: { return FlagInfoService.BOL_PRINT_FORMAT; }
                //2015 08 JP e
                //2016 01 jp s
                case ProTraQFlagEnum.RFSMART_SHIPREC_NOTICE: { return FlagInfoService.RFSMART_SHIPREC_NOTICE; }
                case ProTraQFlagEnum.SHIPPING_VIT_DEFAULT: { return FlagInfoService.SHIPPING_VIT_DEFAULT; }
                //2016 01 jp e 
                case ProTraQFlagEnum.FG_SCHEDULE_ALLOW_OVERPRODUCTION: { return FlagInfoService.FG_SCHEDULE_ALLOW_OVERPRODUCTION; }
                case ProTraQFlagEnum.RECEIVING_INSPECTION_REQUIRED: { return FlagInfoService.RECEIVING_INSPECTION_REQUIRED; }

                case ProTraQFlagEnum.PI_TO_ERP_COIL_LOCATION_MODE: { return FlagInfoService.PI_TO_ERP_COIL_LOCATION_MODE; }
                case ProTraQFlagEnum.PI_TO_ERP_CLAIM_COIL_MODE: { return FlagInfoService.PI_TO_ERP_CLAIM_COIL_MODE; }
                case ProTraQFlagEnum.PI_TO_ERP_CLAIM_PLATE_MODE: { return FlagInfoService.PI_TO_ERP_CLAIM_PLATE_MODE; }
                case ProTraQFlagEnum.PI_TO_ERP_CLAIM_FG_MODE: { return FlagInfoService.PI_TO_ERP_CLAIM_FG_MODE; }
                case ProTraQFlagEnum.RECEIVING_INSPECTION_ACTIVE: { return FlagInfoService.RECEIVING_INSPECTION_ACTIVE; }
                //  2021 08 jp
                case ProTraQFlagEnum.FG_SCHEDULE_WOPARTSLIST_shopfloor_behavior: { return FlagInfoService.FG_SCHEDULE_WOPARTSLIST_shopfloor_behavior; }

                //2022 02 19 co
                case ProTraQFlagEnum.FacilityAgvSystem: { sReturn = nameof(ProTraQFlagEnum.FacilityAgvSystem); break; }

                default:
                    {
                        sReturn = "";
                        break;
                    }
            }

            return sReturn;
        }
        #endregion

    }
}
