﻿using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.NextGeneration;
using PtqAutomation.Automation.Data;
using PtqAutomation.Automation.dbo;
using PtqAutomation.Automation.Factories.Interfaces;

namespace ProTraQ.HandHeld.Common.Api.Services
{
    public class NonAutomationStorageService : PtqAutomation.Automation.Client.INonAutomationStorageService
    {
        public readonly IAutomationRepository _repository;
        public readonly IWarehouseRepository _warehouseRepository;
        public readonly ILogger<StatusChangeService> _Logger;
        public readonly IRetrievalServiceFactory _RetrievalService;
        public NonAutomationStorageService(IAutomationRepository repository,
            ILogger<StatusChangeService> logger,
            IRetrievalServiceFactory retrievalService,
            IWarehouseRepository warehouseRepository
            )
        {
            this._repository = repository;
            this._Logger = logger;
            this._RetrievalService = retrievalService;
            this._warehouseRepository = warehouseRepository;
        }

        public bool ProcessStorageRequest(DomainAutomationModel model)
        {
            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
            try
            {
                Guid MovementID = Guid.Empty;
                AutomationInventoryInformation Inventory = new AutomationInventoryInformation();
                AutomationLocationInformation SrcLocation = new AutomationLocationInformation();
                AutomationLocationInformation TgtLocation = new AutomationLocationInformation();
                AutomationLocationInformation ExchangeLocation = new AutomationLocationInformation();

                bool bOK = true;
                try
                {
                    Inventory = this._repository.GetAutomationInventoryInfoByINVSN(model.PalletID);
                    if (Inventory == null)
                    {
                        _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - No Valid Inventory (" + model.PalletID + ")");
                        return false;
                    }
                    else
                        _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Valid Inventory (" + Inventory.PreferredDisplayID + ")");
                    if (!string.IsNullOrEmpty(model.FromLocation)
                        && model.FromLocation.ToUpper() != "Not Found".ToUpper()
                        && model.FromLocation.ToUpper() != "Already in rack".ToUpper()
                        && model.FromLocation.ToUpper() != "Rack Full".ToUpper()
                        )
                        SrcLocation = this._repository.GetAutomationLocationInfoByAutomationSystemLocationCode(model.FromLocation);
                    else
                        _Logger.Log(LogLevel.Critical, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - FromLocation Was Not Valid (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                    if (!string.IsNullOrEmpty(model.ToLocation)
                        && model.ToLocation.ToUpper() != "Not Found".ToUpper()
                        && model.ToLocation.ToUpper() != "Already in rack".ToUpper()
                        && model.ToLocation.ToUpper() != "Rack Full".ToUpper()
                        )
                        TgtLocation = this._repository.GetAutomationLocationInfoByAutomationSystemLocationCode(model.ToLocation);
                    else
                        _Logger.Log(LogLevel.Critical, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - ToLocation Was Not Valid (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");

                    if (!string.IsNullOrEmpty(model.ExchangePoint))
                    {
                        ExchangeLocation = _repository.GetAutomationLocationInfoByAutomationSystemLocationCode(model.ExchangePoint);
                    }
                    if (SrcLocation == null && TgtLocation == null && model.MessageType != "ER")
                    {
                        _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Valid Message, No Valid Locations (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                        return false;
                    }
                }
                catch
                {
                    _Logger.Log(LogLevel.Critical, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Lookups failed (" + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ").");
                    bOK = false;
                }

                if (!bOK)
                {
                    return false;
                }

                // FIND OUT IF THERE IS AN OPEN MESSAGE.
                switch (model.MessageType)
                {
                    case "SP":
                        {
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;
                            if (SrcLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Attempting Put Away (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, SrcLocation.DisplayLocationID, "PSR-NonAFT", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Completed Put Away - " + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Missing/Unexpected Data (" + model.PalletID + ", " + model.FromLocation + ")");
                            }
                            break;
                        }
                    case "SC": { break; }
                    case "RP":
                        {
                            break;
                        }
                    case "RC": { break; }
                    case "PM": { break; }
                    case "ER":
                        {
                            break;
                        }

                }

                switch (model.MessageType)
                {
                    case "SP": { break; }
                    case "SC":
                        {
                            // PUT AWAY THE ITEM, RECORD THE MOVEMENT
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;
                            if (TgtLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Attempting Put Away (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, TgtLocation.DisplayLocationID, "PSR-NonAFT", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Completed Put Away - " + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            break;
                        }
                    case "RP":
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Message Received and Skipped (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            break;
                        }
                    case "RC":
                        {
                            // RETREIVED THE ITEM, RECORD THE MOVEMENT
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;

                            if (TgtLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Attempting Put Away  (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, TgtLocation.DisplayLocationID, "PSR-NonAFT", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Completed Put Away - " + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            AutomationInventoryInformation old = Inventory;
                            Inventory = _repository.GetAutomationInventoryInfoByINVSN(model.PalletID);
                            break;
                        }
                    case "PM":
                        {
                            // PUT AWAY THE ITEM, RECORD THE MOVEMENT
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;

                            if (TgtLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Attempting Put Away (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, TgtLocation.DisplayLocationID, "PSR-NonAFT", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Completed Put Away - " + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            break;
                        }
                    case "ER":
                        {
                            List<string> ClearedExchanges = new List<string>();

                            // DO NOTHING, RECORD THE MOVEMENT.
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Received Error Message (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");

                            ProcessErrorMessage(model, Inventory, SrcLocation, TgtLocation, ExchangeLocation);
                            break;
                        }

                }
                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Completed (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                return true;
            }
            catch (System.Exception ex)
            {
                _Logger.Log(LogLevel.Critical, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Execution Failure" + ex.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                return false;
            }


        }

        public void ProcessErrorMessage(DomainAutomationModel model
          , AutomationInventoryInformation Inventory
          , AutomationLocationInformation SrcLocation
          , AutomationLocationInformation TgtLocation
          , AutomationLocationInformation ExchangeLocation)
        {
            List<string> ClearedExchanges = new List<string>();

            // DO NOTHING, RECORD THE MOVEMENT.

            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Received Error Message (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
            if (SrcLocation != null)
            {
                if (SrcLocation.ExchangeDisplayLocationID == SrcLocation.DisplayLocationID && SrcLocation.AutomationControlled)
                {
                    try
                    {
                        ClearedExchanges.Add(SrcLocation.ExchangeDisplayLocationID);

                        DomainAutomationModel d = new DomainAutomationModel()
                        {

                            ExchangePoint = SrcLocation.ExchangeAutomationSystemLocationCode,
                            ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)SrcLocation.AutomationImplementationType,
                            LocationId = SrcLocation.LocationID
                        };


                        if (Inventory != null)
                        {
                            d.PalletID = Inventory.PreferredDisplayID;
                        }
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clearing Src Exchange " + SrcLocation.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        var rs = _RetrievalService.GetRetrievalService(d);
                        var res = rs.RetrieveComplete();
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clear of Src Exchange" + SrcLocation.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                    catch (System.Exception exSrc)
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed Failure - Failure attempting clear Src Exchange" + SrcLocation.DisplayLocationID + ": " + exSrc.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }

                }
                else
                {
                    _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Skipping Clear, " + SrcLocation.DisplayLocationID + " not an exchange point. (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                }
            }

            if (TgtLocation != null)
            {
                if (TgtLocation.ExchangeDisplayLocationID == TgtLocation.DisplayLocationID)
                {
                    if (!ClearedExchanges.Exists(x => x == TgtLocation.ExchangeDisplayLocationID && TgtLocation.AutomationControlled))
                    {
                        try
                        {
                            ClearedExchanges.Add(TgtLocation.ExchangeDisplayLocationID);

                            DomainAutomationModel d = new DomainAutomationModel()
                            {

                                ExchangePoint = TgtLocation.ExchangeAutomationSystemLocationCode,
                                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)TgtLocation.AutomationImplementationType,
                                LocationId = TgtLocation.LocationID
                            };
                            if (Inventory != null)
                            {
                                d.PalletID = Inventory.PreferredDisplayID;
                            }
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clearing Tgt Exchange " + TgtLocation.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            var rs = _RetrievalService.GetRetrievalService(d);
                            var res = rs.RetrieveComplete();
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clear of Tgt Exchange" + TgtLocation.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }
                        catch (System.Exception exTgt)
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed Failure - Failure attempting clear Tgt Exchange" + TgtLocation.DisplayLocationID + ": " + exTgt.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }

                    }
                    else
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Skipping Clear, " + TgtLocation.DisplayLocationID + " already cleared (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                }
            }
            else
            {
                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Skipping Clear, " + TgtLocation.DisplayLocationID + " not an exchange point. (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
            }


            if (ExchangeLocation != null)
            {


                if (!ClearedExchanges.Exists(x => x == ExchangeLocation.DisplayLocationID && ExchangeLocation.AutomationControlled))
                {
                    try
                    {
                        ClearedExchanges.Add(ExchangeLocation.DisplayLocationID);
                        DomainAutomationModel d = new DomainAutomationModel()
                        {

                            ExchangePoint = ExchangeLocation.ExchangeAutomationSystemLocationCode,
                            ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)ExchangeLocation.AutomationImplementationType,
                            LocationId = ExchangeLocation.LocationID
                        };

                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clearing Exchange " + ExchangeLocation.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        var rs = _RetrievalService.GetRetrievalService(d);
                        var res = rs.RetrieveComplete();
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clear of Exchange" + ExchangeLocation.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                    catch (System.Exception exTgt)
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed Failure - Failure attempting clear Exchange" + ExchangeLocation.DisplayLocationID + ": " + exTgt.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                }
                else
                {
                    _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Skipping Clear, Exchange location " + ExchangeLocation.DisplayLocationID + " already cleared (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                }
            }

            if (Inventory != null)
            {
                if (Inventory.ExchangeDisplayLocationID == Inventory.DisplayLocationID && Inventory.LocationID > 0 && Inventory.AutomationControlled)
                {

                    if (!ClearedExchanges.Exists(x => x == Inventory.ExchangeDisplayLocationID))
                    {
                        try
                        {
                            ClearedExchanges.Add(Inventory.ExchangeDisplayLocationID);
                            DomainAutomationModel d = new DomainAutomationModel()
                            {

                                ExchangePoint = Inventory.ExchangeAutomationSystemLocationCode,
                                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)TgtLocation.AutomationImplementationType,
                                LocationId = Inventory.LocationID
                            };
                            if (Inventory != null)
                            {
                                d.PalletID = Inventory.PreferredDisplayID;
                            }
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clearing Inventory Exchange " + Inventory.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            var rs = _RetrievalService.GetRetrievalService(d);
                            var res = rs.RetrieveComplete();
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed - Clear of Inventory Exchange" + Inventory.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }
                        catch (System.Exception exTgt)
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Error Processed Failure - Failure attempting clear Inventory Exchange" + Inventory.DisplayLocationID + ": " + exTgt.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }
                    }
                    else
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Skipping Clear, Inventory location " + Inventory.DisplayLocationID + " already cleared (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                }
                else
                {
                    _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSR-NonAFT] - Skipping Clear, Inventory location " + Inventory.DisplayLocationID + " not an exchange point. (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                }
            }
        }
    }
}
