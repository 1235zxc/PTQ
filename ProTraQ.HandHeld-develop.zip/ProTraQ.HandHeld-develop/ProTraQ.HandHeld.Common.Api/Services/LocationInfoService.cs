﻿using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Common.Api.Controllers;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.NextGeneration;
using PtqAutomation.Automation.dbo;
using PtqAutomation.Automation.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProTraQ.HandHeld.Common.Api.Services
{
    public class LocationInfoService : PtqAutomation.Automation.Client.ILocationInfoService
    {
        private readonly IAutomationRepository _repository;
        private readonly ILogger<LocationInfoService> _logger;
        public LocationInfoService(IAutomationRepository repository, ILogger<LocationInfoService> logger)
        {
            _repository = repository;
            _logger = logger;
        }
        public LocationInformation GetLocationInformation(long locationId)
        {
            LocationInformation l = new LocationInformation();

            try
            {
                
                _logger.Log(LogLevel.Information, "GetLocationInformation (" + locationId.ToString() + ")");

                AutomationLocationInformation o = this._repository.GetAutomationLocationInfo(locationId);



                if (o != null)
                {

                    l.LocationId = o.LocationID;
                    l.ImplementationType = (ImplementationType)o.AutomationImplementationType;
                    l.ExchangePoint = o.ExchangeAutomationSystemLocationCode;

                    //_logger.Log(LogLevel.Information, "GetLocationInformation - Location Found " + o.DisplayLocationID + ", " + l.ExchangePoint.Trim() + "," + l.ImplementationType.ToString() + " (" + locationId.ToString() + ")");

                    return l;
                }
                else
                {
                    _logger.Log(LogLevel.Error, "GetLocationInformation - Location Not Found (" + locationId.ToString() + ")");
                }
            }
            catch (System.Exception ex)
            {
                _logger.Log(LogLevel.Critical, "GetLocationInformation - Execution Failure " + ex.Message + " (" + locationId.ToString() + ")");
            }
            return l;
        }
    }
}
