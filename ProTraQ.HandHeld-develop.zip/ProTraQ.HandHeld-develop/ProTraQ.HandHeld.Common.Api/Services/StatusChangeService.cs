﻿using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Common.Api.Repository;
using ProTraQ.HandHeld.Shared.NextGeneration;
using PtqAutomation.Automation.dbo;
using PtqAutomation.Automation.Factories.Interfaces;

namespace ProTraQ.HandHeld.Common.Api.Services
{
    public class StatusChangeService : PtqAutomation.Automation.Client.IStatusChangeService
    {
        public readonly IAutomationRepository _repository;
        public readonly IWarehouseRepository _warehouseRepository;
        public readonly ILogger<StatusChangeService> _Logger;
        public readonly IRetrievalServiceFactory _RetrievalService;

        public StatusChangeService(IAutomationRepository repository,
            ILogger<StatusChangeService> logger,
            IRetrievalServiceFactory retrievalService,
            IWarehouseRepository warehouseRepository
            )
        {
            this._repository = repository;
            this._Logger = logger;
            this._RetrievalService = retrievalService;
            this._warehouseRepository = warehouseRepository;
            _Logger.Log(LogLevel.Debug, "StatusChangeService Instantiated");
        }
        public bool ProcessStatusChange(DomainAutomationModel model)
        {
            try
            {
                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");

                Guid MovementID = Guid.Empty;
                AutomationInventoryInformation Inventory = new AutomationInventoryInformation();
                AutomationLocationInformation SrcLocation = new AutomationLocationInformation();
                AutomationLocationInformation TgtLocation = new AutomationLocationInformation();
                AutomationLocationInformation ExchangeLocation = new AutomationLocationInformation();


                bool bOK = true;
                try
                {
                    Inventory = this._repository.GetAutomationInventoryInfoByINVSN(model.PalletID);
                    if (Inventory == null)
                    {
                        _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - No Valid Inventory (" + model.PalletID + ")");
                        return false;
                    }
                    else
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Valid Inventory (" + Inventory.PreferredDisplayID + ")");

                    if (!string.IsNullOrEmpty(model.FromLocation)
                        && model.FromLocation.ToUpper() != "Not Found".ToUpper()
                        && model.FromLocation.ToUpper() != "Already in rack".ToUpper()
                        && model.FromLocation.ToUpper() != "Rack Full".ToUpper()
                        )
                        SrcLocation = this._repository.GetAutomationLocationInfoByAutomationSystemLocationCode(model.FromLocation);
                    else
                        _Logger.Log(LogLevel.Debug, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - FromLocation Was NOt Valid (" + model.ToLocation + ")");

                    if (!string.IsNullOrEmpty(model.ToLocation)
                        && model.ToLocation.ToUpper() != "Not Found".ToUpper()
                        && model.ToLocation.ToUpper() != "Already in rack".ToUpper()
                        && model.ToLocation.ToUpper() != "Rack Full".ToUpper()
                        )
                        TgtLocation = this._repository.GetAutomationLocationInfoByAutomationSystemLocationCode(model.ToLocation);
                    else
                        _Logger.Log(LogLevel.Debug, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - ToLocation Was Not Valid (" + model.ToLocation + ")");

                    if (SrcLocation == null && TgtLocation == null && model.MessageType != "ER")
                    {
                        _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Valid Message, No Valid Locations (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                        return false;
                    }

                    if (!string.IsNullOrEmpty(model.ExchangePoint))
                    {
                        ExchangeLocation = _repository.GetAutomationLocationInfoByAutomationSystemLocationCode(model.ExchangePoint);
                    }
                }
                catch
                {
                    _Logger.Log(LogLevel.Critical, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Lookups failed (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    bOK = false;
                }

                if (!bOK)
                {
                    return false;
                }

                // FIND OUT IF THERE IS AN OPEN MESSAGE.
                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Lookups Successful.");

                switch (model.MessageType)
                {
                    case "SP":
                        {
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;
                            if (SrcLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Store Pallet (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");

                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, SrcLocation.DisplayLocationID, "PSC", out iReturn, out strConfirmMsg);

                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Store Pallet Completed  " + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");

                                if (SrcLocation.DisplayLocationID == SrcLocation.ExchangeDisplayLocationID)
                                {
                                    _repository.AutomationInventoryInfoUpdateLastRequest(SrcLocation.DisplayLocationID, "Store of pallet " + model.PalletID + " requested.", model.TimeStamp);
                                }
                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }

                            break;
                        }
                    case "SC": { break; }
                    case "RP":
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Retrieve Pallet (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");

                            if (ExchangeLocation.DisplayLocationID == ExchangeLocation.ExchangeDisplayLocationID)
                            {
                                _repository.AutomationInventoryInfoUpdateLastRequest(ExchangeLocation.DisplayLocationID, "Retrieve of pallet " + model.PalletID + " requested.", model.TimeStamp);
                            }

                            break;
                        }
                    case "RC": { break; }
                    case "PM": { break; }
                    case "ER":
                        {
                            break;
                        }

                }

                switch (model.MessageType)
                {
                    case "SP": { break; }
                    case "SC":
                        {
                            // PUT AWAY THE ITEM, RECORD THE MOVEMENT
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;
                            if (TgtLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Attempting PutAWay (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, TgtLocation.DisplayLocationID, "PSC", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Completed PutAWay " + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                                if (ExchangeLocation.DisplayLocationID == ExchangeLocation.ExchangeDisplayLocationID)
                                {
                                    _repository.AutomationInventoryInfoUpdateLastRequest(ExchangeLocation.DisplayLocationID, "Store of pallet " + model.PalletID + " completed to " + TgtLocation.DisplayLocationID + ".", model.TimeStamp);
                                }

                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ")");
                            }
                            break;
                        }
                    case "RP": { break; }
                    case "RC":
                        {
                            // RETREIVED THE ITEM, RECORD THE MOVEMENT
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;

                            if (TgtLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Attempting Retrieval Complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, TgtLocation.DisplayLocationID, "PSC", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Completed Retrieval Complete" + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");

                                if (ExchangeLocation.DisplayLocationID == ExchangeLocation.ExchangeDisplayLocationID)
                                {
                                    _repository.AutomationInventoryInfoUpdateLastRequest(ExchangeLocation.DisplayLocationID, "Retrieval of pallet " + model.PalletID + " from " + SrcLocation.DisplayLocationID + " completed.", model.TimeStamp);
                                }

                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            }
                            AutomationInventoryInformation old = Inventory;
                            Inventory = _repository.GetAutomationInventoryInfoByINVSN(model.PalletID);
                            break;
                        }
                    case "PM":
                        {
                            // PUT AWAY THE ITEM, RECORD THE MOVEMENT
                            int iReturn = 0;
                            string strConfirmMsg = string.Empty;

                            if (TgtLocation != null && Inventory != null)
                            {
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Attempting Pallet Move (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                                _warehouseRepository.usp_PUTAWAY_PutAwayItem_ALPHA(Inventory.InvID, Inventory.InvSN, TgtLocation.DisplayLocationID, "PSC", out iReturn, out strConfirmMsg);
                                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Completed Pallet Move" + strConfirmMsg + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            }
                            else
                            {
                                _Logger.Log(LogLevel.Error, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Missing/Unexpected Data (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            }
                            break;
                        }
                    case "ER":
                        {

                            ProcessErrorMessage(model, Inventory, SrcLocation, TgtLocation, ExchangeLocation);
                            break;
                        }

                }

                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Completed (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                return true;
            }
            catch (System.Exception ex)
            {
                _Logger.Log(LogLevel.Critical, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Execution Failure" + ex.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                return false;
            }


        }

        public void ProcessErrorMessage(DomainAutomationModel model
          , AutomationInventoryInformation Inventory
          , AutomationLocationInformation SrcLocation
          , AutomationLocationInformation TgtLocation
          , AutomationLocationInformation ExchangeLocation)
        {
            List<string> ClearedExchanges = new List<string>();

            // DO NOTHING, RECORD THE MOVEMENT.
            if (ExchangeLocation != null)
            {
                if (!ClearedExchanges.Exists(x => x == ExchangeLocation.DisplayLocationID && ExchangeLocation.AutomationControlled))
                {
                    try
                    {
                        ClearedExchanges.Add(ExchangeLocation.DisplayLocationID);
                        DomainAutomationModel d = new DomainAutomationModel()
                        {

                            ExchangePoint = ExchangeLocation.ExchangeAutomationSystemLocationCode,
                            ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)ExchangeLocation.AutomationImplementationType,
                            LocationId = ExchangeLocation.LocationID
                        };

                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clearing Exchange " + ExchangeLocation.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        var rs = _RetrievalService.GetRetrievalService(d);
                        var res = rs.RetrieveComplete();
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clear of Exchange" + ExchangeLocation.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");

                        string sError = GetErrorSpecifics(d);
                        _repository.AutomationInventoryInfoUpdateLastRequest(ExchangeLocation.DisplayLocationID, sError + "(Cleared)", d.TimeStamp);
                    }
                    catch (System.Exception exTgt)
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed Failure - Failure attempting clear Exchange" + ExchangeLocation.DisplayLocationID + ": " + exTgt.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                }
                else
                {
                    _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Skipping Clear, Exchange location " + ExchangeLocation.DisplayLocationID + " already cleared (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                }
            }

            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Received Error Message (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
            if (SrcLocation != null)
            {
                if (SrcLocation.ExchangeDisplayLocationID == SrcLocation.DisplayLocationID && SrcLocation.AutomationControlled)
                {
                    if (!ClearedExchanges.Exists(x => x == SrcLocation.DisplayLocationID && SrcLocation.AutomationControlled))
                    {

                        try
                        {
                            ClearedExchanges.Add(SrcLocation.ExchangeDisplayLocationID);
                            DomainAutomationModel d = new DomainAutomationModel()
                            {

                                ExchangePoint = SrcLocation.ExchangeAutomationSystemLocationCode,
                                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)SrcLocation.AutomationImplementationType,
                                LocationId = SrcLocation.LocationID
                            };
                            if (Inventory != null)
                            {
                                d.PalletID = Inventory.PreferredDisplayID;
                            }
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clearing Src Exchange " + SrcLocation.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            var rs = _RetrievalService.GetRetrievalService(d);
                            var res = rs.RetrieveComplete();
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clear of Src Exchange" + SrcLocation.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");


                        }
                        catch (System.Exception exSrc)
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed Failure - Failure attempting clear Src Exchange" + SrcLocation.DisplayLocationID + ": " + exSrc.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }
                    }
                }
                else
                {
                    _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Skipping Clear, " + SrcLocation.DisplayLocationID + " not an exchange point. (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                }
            }

            if (TgtLocation != null)
            {
                if (TgtLocation.ExchangeDisplayLocationID == TgtLocation.DisplayLocationID)
                {
                    if (!ClearedExchanges.Exists(x => x == TgtLocation.ExchangeDisplayLocationID && TgtLocation.AutomationControlled))
                    {
                        try
                        {
                            ClearedExchanges.Add(TgtLocation.ExchangeDisplayLocationID);

                            DomainAutomationModel d = new DomainAutomationModel()
                            {

                                ExchangePoint = TgtLocation.ExchangeAutomationSystemLocationCode,
                                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)TgtLocation.AutomationImplementationType,
                                LocationId = TgtLocation.LocationID
                            };
                            if (Inventory != null)
                            {
                                d.PalletID = Inventory.PreferredDisplayID;
                            }
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clearing Tgt Exchange " + TgtLocation.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            var rs = _RetrievalService.GetRetrievalService(d);
                            var res = rs.RetrieveComplete();
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clear of Tgt Exchange" + TgtLocation.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");

                        }
                        catch (System.Exception exTgt)
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed Failure - Failure attempting clear Tgt Exchange" + TgtLocation.DisplayLocationID + ": " + exTgt.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }

                    }
                    else
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Skipping Clear, " + TgtLocation.DisplayLocationID + " already cleared (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                }
            }
            else
            {
                _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Skipping Clear, " + TgtLocation.DisplayLocationID + " not an exchange point. (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
            }




            if (Inventory != null)
            {
                if (Inventory.ExchangeDisplayLocationID == Inventory.DisplayLocationID && Inventory.LocationID > 0 && Inventory.AutomationControlled)
                {

                    if (!ClearedExchanges.Exists(x => x == Inventory.ExchangeDisplayLocationID))
                    {
                        try
                        {
                            ClearedExchanges.Add(Inventory.ExchangeDisplayLocationID);
                            DomainAutomationModel d = new DomainAutomationModel()
                            {

                                ExchangePoint = Inventory.ExchangeAutomationSystemLocationCode,
                                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)TgtLocation.AutomationImplementationType,
                                LocationId = Inventory.LocationID
                            };
                            if (Inventory != null)
                            {
                                d.PalletID = Inventory.PreferredDisplayID;
                            }
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clearing Inventory Exchange " + Inventory.DisplayLocationID + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                            var rs = _RetrievalService.GetRetrievalService(d);
                            var res = rs.RetrieveComplete();
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed - Clear of Inventory Exchange" + Inventory.DisplayLocationID + " complete (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }
                        catch (System.Exception exTgt)
                        {
                            _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Error Processed Failure - Failure attempting clear Inventory Exchange" + Inventory.DisplayLocationID + ": " + exTgt.Message + " (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                        }
                    }
                    else
                    {
                        _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Skipping Clear, Inventory location " + Inventory.DisplayLocationID + " already cleared (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                    }
                }
                else
                {
                    _Logger.Log(LogLevel.Information, "AUTO " + model.KeyField.ToString() + " - " + "[PSC] - Skipping Clear, Inventory location " + Inventory.DisplayLocationID + " not an exchange point. (" + model.MessageType + ", " + model.PalletID + ", " + model.FromLocation + ", " + model.ToLocation + ", " + model.ExchangePoint + ")");
                }
            }

        }

        public string GetErrorSpecifics(DomainAutomationModel d)
        {
            if (d.ToLocation.ToUpper() == "Not Found".ToUpper())
            {
                return "Item " + d.PalletID + " not found in automation system. ";
            }
            else if (d.ToLocation.ToUpper() == "Already in rack".ToUpper())
            {
                return "Item " + d.PalletID + " already in rack. Possibility of duplicate pallet or errant pallet location. ";
            }
            else if (d.ToLocation.ToUpper() == "Rack Full".ToUpper())
            {
                return "Rack full, contact automated storage supervisor";
            }
            else
            {
                return "Unrecognized error processed for pallet request against " + d.PalletID + " (From " + d.FromLocation + ", To" + d.ToLocation + " ?" + ".";
            }
        }
    }
}
