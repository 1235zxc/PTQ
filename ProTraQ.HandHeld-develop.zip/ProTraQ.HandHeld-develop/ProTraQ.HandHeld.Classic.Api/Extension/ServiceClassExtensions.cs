﻿using Insight.Database;
using Microsoft.Extensions.Configuration;
using ProTraQ.HandHeld.Classic.Api.Repository;
using System.Data.SqlClient;

namespace Microsoft.Extensions.DependencyInjection;

public static class ServiceClassExtensions
{
    public static IServiceCollection AddClassicServices(this IServiceCollection services)
    {
        if (services is null)
        {
            throw new ArgumentNullException(
                nameof(services), "A service collection is required.");
        }

        services
               .AddScoped(s => s.GetConnectionStringBuilder().As<IManageRowRepository>());
        services
              .AddScoped(s => s.GetConnectionStringBuilder().As<IPutAwayApiRepository>());
        services
              .AddScoped(s => s.GetConnectionStringBuilder().As<IBatchPutAwayRepository>());
        services
           .AddScoped(s => s.GetConnectionStringBuilder().As<IItemLookupRepository>());


        // Add Insight Column and Parameter mapping for repos registered here
        // Have Insight map the following table columns to the following property names
        ColumnMapping.Tables.ReplaceRegex("InvID", "InventoryId")
                    .ReplaceRegex("Qty", "Quantity")
                    .ReplaceRegex("ItemSpec", "ItemSpecification")
                    .ReplaceRegex("ReturnVal", "ReturnValue")
                    .ReplaceRegex("ReturnMsg", "ReturnMessage");

        // Have Insight map the following stored procedure parameter names to the following property names
        ColumnMapping.Parameters.ReplaceRegex("INVID_OR_SN", "ItemId");

        return services;
    }

    private static SqlConnectionStringBuilder GetConnectionStringBuilder(this IServiceProvider serviceProvider, string connectionStringName = "Protraq.Database")
    {
        var configuration = serviceProvider.GetService<IConfiguration>();
        var repositoryConnectionString = configuration.GetConnectionString(connectionStringName);
        return new SqlConnectionStringBuilder(repositoryConnectionString);
    }
}


