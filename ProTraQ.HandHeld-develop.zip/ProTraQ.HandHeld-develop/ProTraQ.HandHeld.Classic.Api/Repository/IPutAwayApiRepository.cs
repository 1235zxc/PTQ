﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.Classic.Api.Repository;

public interface IPutAwayApiRepository
{
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_PutAwayItem]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_PutAwayItem]", CommandType.StoredProcedure)]
    Task<string> GetPUTAWAY_PutAwayItem(GetLocationOldestItemInformationRequest getItemInformation);
}
