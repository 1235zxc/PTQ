﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using System.Data;

namespace ProTraQ.HandHeld.Classic.Api.Repository;

public interface IBatchPutAwayRepository
{
    /// <summary>
    /// Calls the stored procedure: [dbo].[uspPutAwayItem]
    /// </summary>
    [Sql("[dbo].[uspPutAwayItem]", CommandType.StoredProcedure)]
    BatchPutAwayResponse BatchPutAwayItem(BatchPutAwayRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[uspPutAwayItem_ALPHA]
    /// </summary>
    [Sql("[dbo].[uspPutAwayItem_ALPHA]", CommandType.StoredProcedure)]
    BatchPutAwayResponse BatchPutAwayItem_Alpha(BatchPutAwayRequest request);

}
