﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using System.Data;

namespace ProTraQ.HandHeld.Classic.Api.Repository;

public interface IManageRowRepository
{

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_SELECT_ContentsForRow]
    /// </summary>
    /// <param name="request"></param>
    /// <returns></returns>
    [Recordset(0, typeof(ItemInfo))]
    [Recordset(1, typeof(InventoryInfo))]
    [Recordset(2, typeof(ItemInfo))]
    [Sql("[dbo].[usp_PUTAWAY_SELECT_ContentsForRow]", CommandType.StoredProcedure)]
    Task<Results<ItemInfo, InventoryInfo, ItemInfo>> GetRowContents(GetRowContentRequest request);

}
