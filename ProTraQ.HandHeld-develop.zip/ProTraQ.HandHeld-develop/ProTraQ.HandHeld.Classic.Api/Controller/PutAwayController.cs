﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Classic.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.Classic.Api.Controllers;
[ApiController]
[Route("api/classic/[controller]")]
public class PutAwayController : ControllerBase
{
    private readonly ILogger<PutAwayController> _logger;
    private readonly IPutAwayApiRepository _repository;
    public PutAwayController(ILogger<PutAwayController> logger,
                             IPutAwayApiRepository repository)
    {
        _logger = logger;
        _repository = repository;
    }


    [HttpGet(nameof(AutomationClearAutomationPoint))]
    public async Task<string>AutomationClearAutomationPoint()
    {
        try
        {
            return "-1|Clear operation not implemented";
        }
        catch (System.Exception ex)
        {
            return "-1|" + ex.Message;
        }
    }

    [HttpGet(nameof(UpdateLocationVerbose_ALPHA))]
    public async Task<string>UpdateLocationVerbose_ALPHA()
    {
        try
        {
            return "-1_UpdateLocationVerbose_ALPHA not implemented";
        }
        catch (System.Exception ex)
        {
            return "-1_" + ex.Message;
        }
    }

    [HttpGet(nameof(UpdateLocationVerbose))]
    public async Task<string>UpdateLocationVerbose([FromQuery] GetLocationOldestItemInformationRequest request)
    {
        string res = "";
        long lngInvID;

        if (request.InvSN.Length > 12)
        {
            lngInvID = 0;
        }
        else if (!long.TryParse(request.InvSN, out lngInvID))
        {
            lngInvID = 0;
        }
        request.invID = lngInvID;
        try
        {
            await _repository.GetPUTAWAY_PutAwayItem(request);
            res = request.iReturn.ToString() + "_" + (request.strConfirmMsg);
        }
        catch (Exception e)
        {
            throw (e);
        }

        return res;
    }
}
