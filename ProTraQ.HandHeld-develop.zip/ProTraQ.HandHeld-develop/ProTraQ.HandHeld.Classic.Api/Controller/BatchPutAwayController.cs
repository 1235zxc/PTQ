﻿using Microsoft.AspNetCore.Mvc;
using ProTraQ.HandHeld.Classic.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;
using PtqAutomation.Automation.Factories.Interfaces;

namespace ProTraQ.HandHeld.Classic.Api.Controllers;

[ApiController]
[Route("api/classic/[controller]")]
public class BatchPutAwayController : ControllerBase
{
    private readonly IBatchPutAwayRepository _repository;
    IStorageServiceFactory _StorageService;
    public BatchPutAwayController(IBatchPutAwayRepository repository, IStorageServiceFactory StorageService)
    {
        _repository = repository;
        _StorageService = StorageService;

    }
    [HttpGet(nameof(UpdateLocation))]
    public string UpdateLocation([FromQuery]BatchPutAwayRequest request)
    {
        string returnValue = "";
        long lngInvID;

        if (request.invSN.Length > 12)
        {
            lngInvID = 0;
        }
        else if (!long.TryParse(request.invSN, out lngInvID))
        {
            lngInvID = 0;
        }
        request.invID = lngInvID;
        try
        {
            var putawayitem = _repository.BatchPutAwayItem(request);
            returnValue = request.strConfirmMsg.ToString();
        }
        catch (Exception e)
        {
            throw (e);
        }
        return returnValue;
    }
    [HttpGet(nameof(UpdateLocation_ALPHA))]
    public string UpdateLocation_ALPHA([FromQuery] BatchPutAwayRequest request)
    {

        return "-1|UpdateLocation_ALPHA not implemented";
    }
}
