﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.Classic.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.Classic.Api.Controller
{
    [ApiController]
    [Route("api/classic/[controller]")]
    public class ManageRowController : ControllerBase
    {
        private readonly ILogger<ManageRowController> _logger;
        private readonly IManageRowRepository _repository;
        public ManageRowController(ILogger<ManageRowController> logger, IManageRowRepository repository)
        {
            _logger = logger;
            _repository = repository;
        }


        [HttpGet(nameof(GetRowContents))]
        public async Task<ActionResult<object>>GetRowContents([FromQuery] GetRowContentRequest request)
        {
            object results;
            try
            {
                results = await _repository.GetRowContents(request);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
            return results;
        }

        [HttpGet(nameof(PutAwayItemAsLost_ALPHA))]
        public async Task<int>PutAwayItemAsLost_ALPHA([FromQuery] PutAwayItemAsLostRequest request)
        {
            return -1;
        }

    }
}
