﻿using Android.App;
using Android.Widget;
using ProTraQ.Handheld.MobileApp.Interfaces;
using Xamarin.Forms;
using Application = Android.App.Application;

[assembly: Dependency(typeof(ProTraQ.Handheld.MobileApp.Droid.Services.MessageAndroid))]
namespace ProTraQ.Handheld.MobileApp.Droid.Services
{
    public class MessageAndroid : IMessage
    {
        public MessageAndroid()
        {
        }

        public string GetPath()
        {
            return Application.Context.GetExternalFilesDir(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
        }
        public void LongAlert(string message)
        {
            Toast.MakeText(Application.Context, message, ToastLength.Long).Show();
        }

        public void ShortAlert(string message)
        {
            Toast.MakeText(Application.Context, message, ToastLength.Short).Show();
        }
    }
}