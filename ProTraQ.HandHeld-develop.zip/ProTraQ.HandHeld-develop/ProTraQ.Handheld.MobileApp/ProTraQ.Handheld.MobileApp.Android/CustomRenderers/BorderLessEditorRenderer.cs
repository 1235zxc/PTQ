﻿using System;
using Android.Content;
using ProTraQ.Handheld.MobileApp.CustomControls;
using ProTraQ.Handheld.MobileApp.Droid.CustomRenderers;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(BorderLessEditor), typeof(BorderLessEditorRenderer))]
namespace ProTraQ.Handheld.MobileApp.Droid.CustomRenderers
{
    public class BorderLessEditorRenderer:EditorRenderer
    {
        public BorderLessEditorRenderer(Context context):base(context)
        {
        }
        protected override void OnElementChanged(ElementChangedEventArgs<Editor> e)
        {
            base.OnElementChanged(e);
            if (e.OldElement == null)
            {
                Control.Background = null;

                var lp = new MarginLayoutParams(Control.LayoutParameters);
                lp.SetMargins(0, 0, 0, 0);
                LayoutParameters = lp;
                Control.LayoutParameters = lp;
                Control.SetPadding(0, 0, 0, 0);
                SetPadding(0, 0, 0, 0);
            }
        }
    }
}
