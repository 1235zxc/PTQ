﻿using ProTraQ.Handheld.MobileApp.Constant;
using ProTraQ.Handheld.MobileApp.Helpers;
using ProTraQ.Handheld.MobileApp.Model;
using SQLite;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProTraQ.Handheld.MobileApp.Data
{
    public class PlantDatabase
    {
        static SQLiteAsyncConnection Database;

        public static readonly AsyncLazy<PlantDatabase> Instance = new AsyncLazy<PlantDatabase>(async () =>
        {
            var instance = new PlantDatabase();
            CreateTableResult result = await Database.CreateTableAsync<Plant>();
            return instance;
        });

        public PlantDatabase()
        {
            Database = new SQLiteAsyncConnection(Constants.DatabasePath, Constants.Flags);
        }

        public Task<List<Plant>> GetItemsAsync()
        {
            return Database.Table<Plant>().ToListAsync();
        }

        public Task<List<Plant>> GetItemsNotDoneAsync()
        {
            return Database.QueryAsync<Plant>("SELECT * FROM [Plant] WHERE [Default] = true");
        }

        public Task<Plant> GetDefaultItemAsync()
        {
            return Database.Table<Plant>().Where(i => i.Default == true).FirstOrDefaultAsync();
        }
        public Task<Plant> GetPlantDetailsByName(string plantName)
        {
            return Database.Table<Plant>().Where(i => i.Name == plantName).FirstOrDefaultAsync();
        }

        public Task<int> SaveItemAsync(Plant item)
        {
            if (item.Id != 0)
            {
                return Database.UpdateAsync(item);
            }
            else
            {
                return Database.InsertAsync(item);
            }
        }

        public Task<int> DeleteItemAsync(Plant item)
        {
            return Database.DeleteAsync(item);
        }

        //public Task<int> GetTotalItemCount()
        //{
        //    return Database.GetAsync<Plant>("SELECT COUNT(*) FROM[Plant]");
        //}

    }
}
