﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.Handheld.MobileApp.Model
{
    public class NGLoginResponse
    {
        public string resultText { get; set; }
        public string adUserName { get; set; }
        public string operatingMode { get; set; }
    }
}
