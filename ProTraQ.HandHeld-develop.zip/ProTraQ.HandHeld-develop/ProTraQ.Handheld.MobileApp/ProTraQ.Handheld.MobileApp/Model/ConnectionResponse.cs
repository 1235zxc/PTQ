﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.Handheld.MobileApp.Model
{
    public class ConnectionResponse
    {
        public bool ipFound { get; set; }
        public string connectionType { get; set; }
        public object pT_IP_Address { get; set; }
        public object operatingMode { get; set; }
        public bool requireHandheldLogin { get; set; }
        public int locationLengthIndicator { get; set; }
        public bool enableReceivingPutAway { get; set; }
        public bool enableReceivingInspectionRequirement { get; set; }
        public bool alphaLocationsAllowed { get; set; }
        public bool isTraining { get; set; }
        public object facilityName { get; set; }
        public int facilityNumber { get; set; }
        public int companyID { get; set; }
        public int minSNLengthForPlant { get; set; }
    }
}
