﻿using System;
using Xamarin.Essentials;

namespace ProTraQ.Handheld.MobileApp.Model
{
    public class AboutResponse
    {
        public string appVersion { get; set; }
        public AboutInformation aboutInformation { get; set; }
    }

    public class AboutInformation
    {
        public int facilityNumber { get; set; }
        public string facilityName { get; set; }
        public int companyID { get; set; }
    }

    public static class Settings
    {
        public static bool FirstRun
        {
            get => Preferences.Get(nameof(FirstRun), true);
            set => Preferences.Set(nameof(FirstRun), value);
        }
    }
}

