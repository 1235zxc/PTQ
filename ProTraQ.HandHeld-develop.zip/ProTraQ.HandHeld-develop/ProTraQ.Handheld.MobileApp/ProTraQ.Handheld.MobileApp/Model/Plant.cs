﻿using SQLite;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Model
{
    public class Plant 
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Name { get; set; }
        public string IP_Address { get; set; }
        public bool Default { get; set; }
        public string PlantColor { get; set; }
        public string DefaultIcon { get; set; } 
    }

    public class PlantDetails : BindableObject
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string IP_Address { get; set; }
        public bool Default { get; set; }
        public string PlantColor { get; set; }


        private string _defaultIcon = string.Empty;
        public string DefaultIcon
        {
            get { return _defaultIcon; }
            set { _defaultIcon = value; OnPropertyChanged(nameof(DefaultIcon)); }
        }
    }
}
