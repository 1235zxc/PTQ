﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Converters
{
    public class SwitchImageConverter: IValueConverter
    {
        public SwitchImageConverter()
        {
        }

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool Option2 = (bool)value;
            if (Option2)
            {
                return "Toggle_Off";
            }
            else
            {
                return "Toggle_On"; 
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}

