﻿using System;
namespace ProTraQ.Handheld.MobileApp.ViewModels.PalletBuilding
{
    public class CartoonQuantityViewModel : BaseViewModel
    {
        public CartoonQuantityViewModel()
        {

        }

        
    }
}

