﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class ReceiveUnknownItemsPageViewModel:BindableObject
    {
        #region Constructor


        public ReceiveUnknownItemsPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Properties
        public INavigation Navigation { get; set; }
        #endregion
        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion
    }
}
