﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class LoadSearchPickLoadNGRecevingPageViewModel:BindableObject
    {
        #region Properties
        public INavigation Navigation { get; set; }
        private bool _isVisibleCompletePopUp;
        public bool IsVisibleCompletePopUp
        {
            get { return _isVisibleCompletePopUp; }
            set { _isVisibleCompletePopUp=value;OnPropertyChanged(); }
        }
        #endregion
        #region Constructor
        public LoadSearchPickLoadNGRecevingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Command
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand TogglecompletePopupCommand => new Command(async () =>
        {
            IsVisibleCompletePopUp = true;
        });
        public ICommand CompletePopupOKButtonCommand => new Command(async () =>
        {
            IsVisibleCompletePopUp = false;
            await Navigation.PopAsync();
        });
        #endregion

    }
}
