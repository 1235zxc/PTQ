﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class BrowseDockNGRecevingPageViewModel:BindableObject
    { 
        #region Properties
        public INavigation Navigation { get; set; }
         #endregion
        #region Constructor
        public BrowseDockNGRecevingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Command
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
      
        #endregion

    }
}

