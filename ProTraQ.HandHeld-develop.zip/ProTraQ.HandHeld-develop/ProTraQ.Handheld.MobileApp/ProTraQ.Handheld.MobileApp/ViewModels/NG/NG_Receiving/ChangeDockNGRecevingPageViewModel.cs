﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Views.NG;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class ChangeDockNGRecevingPageViewModel:BindableObject
    {
     
        #region Properties
        public INavigation Navigation { get; set; }
        private bool _isVisibleCompletePopUp;
        public bool IsVisibleCompletePopUp
        {
            get { return _isVisibleCompletePopUp; }
            set { _isVisibleCompletePopUp = value; OnPropertyChanged(); }
        }
        #endregion
        #region Constructor
        public ChangeDockNGRecevingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Command
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand TogglecompletePopupCommand => new Command(async () =>
        {
            IsVisibleCompletePopUp = true;
        });
        public ICommand CompletePopupOKButtonCommand => new Command(async () =>
        {
            IsVisibleCompletePopUp = false;
            await Navigation.PopAsync();
        });
        public ICommand AssignAndExitLoadBtnCommand => new Command(async () =>
        {
            
            var previousPage = Navigation.NavigationStack.LastOrDefault();
            await Navigation.PushAsync(new NGReceivingPage());
            Navigation.RemovePage(previousPage);

        });
        public ICommand AssignAndExitReceivingBtnCommand => new Command(async () =>
        {
            var previousPage = Navigation.NavigationStack.LastOrDefault();
           // await Navigation.PushAsync(new NGMenuPage());
            Navigation.RemovePage(previousPage);

        });

        #endregion
    }
}

