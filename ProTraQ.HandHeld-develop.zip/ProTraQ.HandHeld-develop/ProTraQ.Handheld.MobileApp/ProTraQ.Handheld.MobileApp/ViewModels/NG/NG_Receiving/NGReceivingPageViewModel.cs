﻿using System;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG
{
    public class NGReceivingPageViewModel : BindableObject
    {
        #region Constructor
        public NGReceivingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Properties
        public INavigation Navigation { get; set; }
        private bool _IsReRecevingPopupVisible;
        public bool IsReRecevingPopupVisible
        {
            get { return _IsReRecevingPopupVisible; }
            set { _IsReRecevingPopupVisible = value;OnPropertyChanged(); }
        }

        #endregion
        #region Commands
        public ICommand ToggleReReceivingPopupCommand => new Command(() =>
        {
            IsReRecevingPopupVisible = !IsReRecevingPopupVisible;
        });
        public ICommand GotoNgReceivingWithTablePageCommand => new Command(async() =>
        {
           await Navigation.PushAsync(new NGRecivingWithTablesPage());
        });
        public ICommand GotoNGRecevingLoadInformationPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new NGRecevingLoadInformationPage());
        });
        public ICommand BackButtonCommand => new Command(async() =>
        {
            await Navigation.PopAsync();
        });
        public ICommand GotoLoadSearchPickLoadNgRecevingPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new LoadSearchPickLoadNGRecevingPage());
        });
        public ICommand GotoBroowseDockPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new BrowseDockNGRecevingPage());
        });
        public ICommand GotoPrintReportNgRecevingPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new PrintReportNgRecevingPage());
        });
        #endregion

    }
}
