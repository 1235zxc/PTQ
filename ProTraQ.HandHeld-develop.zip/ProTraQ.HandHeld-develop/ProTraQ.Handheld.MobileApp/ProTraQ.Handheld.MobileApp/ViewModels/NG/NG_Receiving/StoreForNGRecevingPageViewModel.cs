﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class StoreForNGRecevingPageViewModel : BindableObject
    {
        #region Properties
        public INavigation Navigation { get; set; }
        #endregion

        #region Constructor
        public StoreForNGRecevingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }

        #endregion
        #region Command
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion
    }
}
