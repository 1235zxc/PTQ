﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class PutAllNgRecevingPageViewModel:BindableObject
    {
        #region Properties
        public INavigation Navigation { get; set; }
        #endregion
        #region Consttructor

        public PutAllNgRecevingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion
    }
}
