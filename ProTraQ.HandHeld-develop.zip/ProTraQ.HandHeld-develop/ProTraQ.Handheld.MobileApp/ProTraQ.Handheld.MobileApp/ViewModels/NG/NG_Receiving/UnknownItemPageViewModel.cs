﻿using System;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class UnknownItemPageViewModel : BindableObject
    {
        #region Constructor

        public UnknownItemPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Properties
        public INavigation Navigation { get; set; }
        #endregion
        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand GotoNGRecivingWithTablesPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new NGRecivingWithTablesPage());
        });
        #endregion
    }
}
