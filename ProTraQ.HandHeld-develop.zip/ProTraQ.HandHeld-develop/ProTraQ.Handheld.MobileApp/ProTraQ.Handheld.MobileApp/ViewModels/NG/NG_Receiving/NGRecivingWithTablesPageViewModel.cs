﻿using System;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving
{
    public class NGRecivingWithTablesPageViewModel:BindableObject
    {
        #region Constructor
        public NGRecivingWithTablesPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion


        #region Properties
        public INavigation Navigation { get; set; }
        private bool _isRePrintAllPopupVisible;
        public bool IsRePrintAllPopupVisible
        {
            get { return _isRePrintAllPopupVisible; }
            set { _isRePrintAllPopupVisible = value; OnPropertyChanged(); }
        }
        #endregion
        #region Commands
        public ICommand GotoNGRecevingLoadInformationPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new NGRecevingLoadInformationPage());
        });
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand GotoReceiveUnkownItemPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ReceiveUnknownItemsPage());

        });
        public ICommand GotoStoreForNgReceivePageCommad => new Command(async () =>
        {
            await Navigation.PushAsync(new StoreForNGRecevingPage());
        });
        public ICommand GotoPutAwayNgReceivePageCommad => new Command(async () =>
        {
            await Navigation.PushAsync(new PutAwayNGRecevingPage());
        });
        public ICommand GotoHoldNgReceivePageCommad => new Command(async () =>
        {
            await Navigation.PushAsync(new HoldNgReceivePage());
        });
        public ICommand GotoStoreAllNgRecevingPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new StoreAllNgRecevingPage());
        });
        public ICommand GotoPutAllNgRecevingPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new PutAllNgRecevingPage());
        });
        public ICommand GotoPrintReportNgRecevingPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new PrintReportNgRecevingPage());
        });
        public ICommand GotoLoadSearchPickLoadNgRecevingPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new LoadSearchPickLoadNGRecevingPage());
        });
        public ICommand ToggleRePrintAllPopupCommand => new Command(async () =>
        {
            IsRePrintAllPopupVisible = !IsRePrintAllPopupVisible;
        });
        public ICommand GotoChangeDockPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ChangeDockNGRecevingPage());
        });
        #endregion
    }
}
