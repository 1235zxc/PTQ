﻿using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG
{
    public class BatchPutAwayNGPageViewModel:BindableObject
    {
         #region Constructor

        public BatchPutAwayNGPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion
        #region Properties
        public INavigation Navigation { get; set; }
        #endregion
        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion
    }
}
