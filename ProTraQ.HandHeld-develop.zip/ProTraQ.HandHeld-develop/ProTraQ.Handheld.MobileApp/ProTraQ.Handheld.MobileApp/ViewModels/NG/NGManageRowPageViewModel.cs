﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG
{
    public class NGManageRowPageViewModel : BindableObject
    {
        #region Constructor
        public NGManageRowPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            SpecsCollection = new ObservableCollection<Specs>
            {
                new Specs{ Spec="555999",Hash="3",Row="1504",Facility="337"},
                new Specs{ Spec="556677",Hash="6",Row="1504",Facility="444"},

            };
            InventoryCollection = new ObservableCollection<Inventory>
            {
                new Inventory{ID="3334400000000",Spec="34.55.77.99."},
                 new Inventory{ID="556667789999990",Spec="44.66.88.66."}
            };
            MfgDateCollection = new ObservableCollection<MfgDate>
            {
                new MfgDate{ Spec="33.44.77.99",Mfgdate="20/09/2022", Row="680"},
                new MfgDate{ Spec="33.55.66.99",Mfgdate="21/08/2022", Row="680"}
            };
        }
        #endregion


        #region Properties
        public INavigation Navigation { get; set; }

        public ObservableCollection<Specs> SpecsCollection { get; set; }
        public ObservableCollection<Inventory> InventoryCollection { get; set; }
        public ObservableCollection<MfgDate> MfgDateCollection { get; set; }


        private bool option1;
        public bool Option1
        {
            get { return option1; }
            set
            {
                option1 = value;


                OnPropertyChanged("Option1");
            }
        }

        private bool option2;
        public bool Option2
        {
            get { return option2; }
            set
            {

                option2 = value;


                OnPropertyChanged("Option2");
            }

        }

        private bool option3;
        public bool Option3
        {
            get { return option3; }
            set
            {
                option3 = value;

                OnPropertyChanged("Option3");
            }

        }

        private bool _typePicker;
        public bool TypePicker
        {
            get { return _typePicker; }
            set { _typePicker = value; OnPropertyChanged(); }
        }
        private string _rotation;
        public string Rotation
        {
            get { return _rotation; }
            set { _rotation = value; OnPropertyChanged(nameof(Rotation)); }
        }

        private string _ImgDropDown = "whitevector.png";
        public string ImgDropDown
        {
            get
            {
                return _ImgDropDown;
            }
            set
            {
                _ImgDropDown = value; OnPropertyChanged(ImgDropDown);
            }
        }
        #endregion


        #region Commands
        public ICommand SwitchImageCommand => new Command(() =>
        {
            Option2=!Option2;
        });
        public ICommand TypePickerCommand => new Command(() =>
        {
            TypePicker = !TypePicker;

            if (TypePicker)
            {
                ImgDropDown = "whitevector.png";
                Rotation = "180";
            }
            else
            {
                ImgDropDown = "whitevector.png";
                Rotation = "0";
            }
        });
        public ICommand ToggleOption1Command => new Command(() =>
        {
            Option1 = !Option1;

        });
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion
    }


    #region Classes
    public class Specs
    {
        public string Spec { get; set; }
        public string Hash { get; set; }
        public string Row { get; set; }
        public string Facility { get; set; }


    }
    public class MfgDate
    {
        public string Spec { get; set; }
        public string Mfgdate { get; set; }
        public string Row { get; set; }
    }

    public class Inventory
    {
        public string ID { get; set; }
        public string Spec { get; set; }
    }
    #endregion
}
