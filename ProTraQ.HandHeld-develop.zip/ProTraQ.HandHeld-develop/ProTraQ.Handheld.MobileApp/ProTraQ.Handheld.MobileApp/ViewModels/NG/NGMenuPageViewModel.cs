﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.nswag;
using ProTraQ.Handheld.MobileApp.Views.ItemLookup;
using ProTraQ.Handheld.MobileApp.Views.NG;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using ProTraQ.Handheld.MobileApp.Views.PutAway;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.NG
{
    public class NGMenuPageViewModel : BindableObject
    {
        #region Properties
        public INavigation Navigation { get; set; }
        public ObservableCollection<NGS> NGCollection { get; set; }
        public ObservableCollection<Count> Counts { get; set; }
        private bool _putAwayPopupIsvisible;
        public bool PutAwayPopupIsvisible
        {
            get { return _putAwayPopupIsvisible; }
            set { _putAwayPopupIsvisible = value; OnPropertyChanged(); }
        }

        private bool _lookupItemPopupIsVisible;
        public bool LookupItemPopupIsVisible
        {
            get { return _lookupItemPopupIsVisible; }
            set { _lookupItemPopupIsVisible = value; OnPropertyChanged(); }
        }

        private string _username;
        public string UserName
        {
            get { return _username; }
            set { _username = value; OnPropertyChanged(); }
        }

        private string _plantName;

        public string PlantName
        {
            get { return _plantName; }
            set { _plantName = value; OnPropertyChanged(); }
        }

        #endregion

        public class Count
        {

            public ObservableCollection<NGS> NGs { get; set; }
        }
        public class NGS
        {
            public int id { get; set; }
            public string Name { get; set; }
            public string Image { get; set; }
        }

        #region Constructor
        public NGMenuPageViewModel(INavigation navigation, LoginResponse loginResponse, string plantName)
        {
            Navigation = navigation;
            UserName = loginResponse.AdUserName;
            PlantName = plantName;
            Counts = new ObservableCollection<Count>
            {
               new Count
               {

                  NGs = new ObservableCollection<NGS>
                  {
                      new NGS{id=1,Name="Put-Away",Image="bluevector"},
                      new NGS{id=2,Name="Look Up Item",Image="bluevector"},
                      new NGS{id=3,Name="Shipping",Image="bluevector"},
                      new NGS{id=4,Name="Receiving"},
                      new NGS{id=5,Name="Manage Rows"},
                      new NGS{id=6,Name="Physical Inventory"},
                  }
               },
               new Count
               {

                  NGs = new ObservableCollection<NGS>
                  {
                      new NGS{id=7,Name="Finished Goods",Image="bluevector"},

                      new NGS{id=8,Name="Pallet Building"},
                      new NGS{id=9,Name="Raw Material Update"},
                      new NGS{id=10,Name="Scrap",Image="bluevector"},
                      new NGS{id=11,Name="AGV"},
                      new NGS{id=12,Name="Utilities",Image="bluevector"}

                  }
               }
            };

        }

        #endregion

        #region Commands
        public ICommand LogoutCommand => new Command(() =>
        {
            Application.Current.MainPage = new NavigationPage(new StaffSplashPage());
        });

        public ICommand GotoPutAwayNGPageCommmand => new Command(() =>
        {
            PutAwayPopupIsvisible = false;
            Navigation.PushAsync(new PutAwayPage());
        });

        public ICommand GotoBatchPutAwayNGPageCommmand => new Command(() =>
        {
            Navigation.PushAsync(new BatchPutAwayNGPage());
        });

        public ICommand LocationLookupItemCommmand => new Command(async () =>
        {
            await Navigation.PushAsync(new NGItemLocationLookupPage());
        });

        public ICommand LookupItemCommmand => new Command(async () =>
        {
            await Navigation.PushAsync(new LookupItemPage());
        });

        public ICommand GotoNGManageRowPageCommand => new Command(async (obj) =>
        {
            var type = obj as NGS;
            if (type != null)
            {
                await Navigation.PushAsync(new NGManageRowsPage(type.id));
            }
        });

        public ICommand PutAwayPopupIsVisibleCommand => new Command(async () =>
        {
            PutAwayPopupIsvisible = !PutAwayPopupIsvisible;
        });

        public ICommand LookupItemPopupIsVisibleCommand => new Command(async () =>
        {
            LookupItemPopupIsVisible = !LookupItemPopupIsVisible;
        });

        public ICommand GotoAboutPageCommand => new Command(() =>
        {
            Navigation.PushAsync(new AboutPage());
        });
        #endregion




    }
}
