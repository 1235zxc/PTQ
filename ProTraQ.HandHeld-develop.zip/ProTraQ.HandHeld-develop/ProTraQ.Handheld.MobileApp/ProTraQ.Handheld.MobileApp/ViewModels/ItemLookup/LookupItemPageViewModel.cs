﻿using ProTraQ.Handheld.MobileApp.Views;
using ProTraQ.Handheld.MobileApp.Views.ItemLookup;
using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.ItemLookup
{
    public class LookupItemPageViewModel : BindableObject
    {
        public LookupItemPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }

        #region Properties
        public INavigation Navigation { get; set; }
        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        public ICommand ManageCartonCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ManageCartonReferencePage());
        });

        public ICommand ReassignSalesOrderCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new SalesOrderAssignmentPage());
        });
        
        public ICommand StatusButtonCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ChangeStatusPage());
        });
        
        public ICommand StoreForButtonCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ChangeStoreForCustomerPage());
        });
        #endregion
    }
}
