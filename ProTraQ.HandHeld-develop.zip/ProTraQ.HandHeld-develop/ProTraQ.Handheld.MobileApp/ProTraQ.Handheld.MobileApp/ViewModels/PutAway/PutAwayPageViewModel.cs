﻿using ProTraQ.Handheld.MobileApp.Helpers;
using ProTraQ.Handheld.MobileApp.Interfaces;
using ProTraQ.Handheld.MobileApp.nswag;
using ProTraQ.Handheld.MobileApp.Views.LegacyMenu;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.PutAway
{
    public class PutAwayPageViewModel : BindableObject
    {
        #region Constructor
        public PutAwayPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();
        }
        #endregion

        #region Properties
        public IMessage toast { get; set; }
        public INavigation Navigation { get; set; }

        private string  _barcodeNum;
        public string BarCodeNumber
        {
            get { return _barcodeNum; }
            set { _barcodeNum = value; OnPropertyChanged(nameof(BarCodeNumber)); }
        }

        private ItemInformation _iteminfoList;
        public ItemInformation ItemInfoList
        {
            get { return _iteminfoList; }
            set { _iteminfoList = value; OnPropertyChanged(); }
        }


        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand GetItemInfoCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    if (!string.IsNullOrEmpty(BarCodeNumber))
                    {
                        HttpClient client = new HttpClient();
                        client.Timeout = TimeSpan.FromSeconds(5);
                        var testClient = new PutAwayClient(client);
                        var getresult = testClient.GetItemInformationAsync(BarCodeNumber).GetAwaiter().GetResult();
                        if (getresult != null)
                        {
                            ItemInfoList = getresult.ItemInformation;
                            BarCodeNumber = string.Empty;
                        }
                        else
                        {
                            toast.LongAlert("Something went wrong!");
                        }
                    }

                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }
            catch (OperationCanceledException ex)
            {
                if (ex.CancellationToken.IsCancellationRequested)
                {
                    toast.LongAlert("Connection Error! A connection to the ProTraQ Server could not be established. Check the connection settings and contact Technical Support.");
                    //await App.Current.MainPage.DisplayAlert("Connection Error!",
                    //"A connection to the ProTraQ Server could not be established. Check the connection settings and contact Technical Support.", "OK");

                }
                await Navigation.PopAsync();
            }
            catch (Exception ex)
            {
                toast.LongAlert("Something went wrong!");
            }
            finally
            {

            }
        });
        #endregion
    }
}
