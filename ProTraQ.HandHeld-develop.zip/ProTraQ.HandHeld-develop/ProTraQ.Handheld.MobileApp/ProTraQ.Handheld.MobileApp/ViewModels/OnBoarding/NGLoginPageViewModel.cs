﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Input;
using Plugin.DeviceInfo;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using ProTraQ.Handheld.MobileApp.Helpers;
using ProTraQ.Handheld.MobileApp.Interfaces;
using ProTraQ.Handheld.MobileApp.nswag;
using ProTraQ.Handheld.MobileApp.Views;
using ProTraQ.Handheld.MobileApp.Views.LegacyMenu;
using ProTraQ.Handheld.MobileApp.Views.NG;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using Rg.Plugins.Popup.Services;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class NGLoginPageViewModel:BindableObject
    {
        public INavigation Navigation { get; set; }

        public NGLoginPageViewModel(INavigation navigation, string plantName)
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();
            PlantName = plantName;
            DateAndTime = Convert.ToString(DateTime.Now);
            AppVersion = CrossDeviceInfo.Current.AppVersion;
        }

        #region Properties
        public IMessage toast { get; set; }
        private string _plantName;
        public string PlantName
        {
            get { return _plantName; }
            set { _plantName = value; OnPropertyChanged(); }
        }

        private string _appVersion;
        public string AppVersion
        {
            get { return _appVersion; }
            set { _appVersion = value; OnPropertyChanged(); }
        }
        private string _dateTime;
        public string DateAndTime
        {
            get { return _dateTime; }
            set { _dateTime = value; }
        }
        private string _loginId;
        public string StaffLoginId
        {
            get { return _loginId; }
            set { _loginId = value; OnPropertyChanged(nameof(StaffLoginId)); }
        }

        #endregion
        //public ICommand GotoAboutPageCommand => new Command(() =>
        //{
        //    Navigation.PushAsync(new AboutPage(PlantName));
        //});
        public ICommand LoginCommand => new Command(async() =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    HttpClient client = new HttpClient();

                    client.Timeout = TimeSpan.FromSeconds(5);
                    var testClient = new NGClient(client);
                    var getresult = testClient.LoginAsync(StaffLoginId, null).GetAwaiter().GetResult();


                    if (getresult != null)
                    {
                        if (getresult.ResultText == "Login Success")
                        {
                            toast.LongAlert("Logged in as - " + getresult.AdUserName);
                            await Navigation.PushAsync(new NGMenuPage(getresult, PlantName));
                        }
                        else
                        {
                            toast.LongAlert("Something Went wrong!");
                        }
                    }
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }

            catch (OperationCanceledException ex)
            {
                if (ex.CancellationToken.IsCancellationRequested)
                {
                    toast.LongAlert("Connection Error! A connection to the ProTraQ Server could not be established. Check the connection settings and contact Technical Support.");
                }
            }
            catch (Exception ex)
            {
                toast.LongAlert("Login failed!");
            }
            finally
            {

            }
        });
        public ICommand ScanQrCodeCommand => new Command(async() =>
        {
            try
            {
                string param = String.Empty;
                var page = new ScanQRCodePopupPage();

                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    page.Action += async (sender, stringparameter) =>
                    {
                        param = stringparameter;
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }

                page.Disappearing += (c, d) =>
                {
                    if (!string.IsNullOrEmpty(param))
                    {
                        StaffLoginId = param;   
                    }
                    else
                    {
                        
                    }
                };
            }
            catch (Exception ex)
            {

            }
        });


        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        var popUppage = new AccessWarningPopupPage();
                        await PopupNavigation.Instance.PushAsync(popUppage);
                        return status;
                    }
                }

                await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                }
            }
            return status;
        }
    }
}
