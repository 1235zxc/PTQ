﻿using ProTraQ.Handheld.MobileApp.Data;
using ProTraQ.Handheld.MobileApp.Model;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Input;
using Xamarin.CommunityToolkit.Extensions;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class ConfigurationDetailsViewModel : BindableObject
    {
        public ConfigurationDetailsViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }

        #region Properties
        public INavigation Navigation { get; set; }
        public Plant Plant { get; set; }

        private List<Plant> _palletGetlist;
        public List<Plant> ConfiguredPlantList
        {
            get { return _palletGetlist; }
            set
            {
                _palletGetlist = value;
                OnPropertyChanged(nameof(ConfiguredPlantList));
            }
        }

        private bool _isdelteVisible;
        public bool IsDeletePopupVisible
        {
            get { return _isdelteVisible; }
            set { _isdelteVisible = value; OnPropertyChanged(); }
        }

        private string _defaultSrc;
        public string DefaultIcon
        {
            get { return _defaultSrc; }
            set { _defaultSrc = value; OnPropertyChanged(nameof(DefaultIcon)); }
        }


        #endregion

        #region Commands
        public ICommand DeleteConfiguration => new Command(async (obj) =>
        {
            try
            {
                Plant = obj as Plant;
                if (Plant != null)
                {
                    var result = await Navigation.ShowPopupAsync(new DeletePlantPopupPage(Plant.Name));
                    if (Convert.ToBoolean(result) == true)
                    {
                        PlantDatabase database = await PlantDatabase.Instance;
                        await database.DeleteItemAsync(Plant);
                        ConfiguredPlantList = await database.GetItemsAsync();
                        if (ConfiguredPlantList == null || ConfiguredPlantList.Count == 0)
                        {
                            Preferences.Set("IsPlantConfigured", false);
                            await Navigation.PopAsync();
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        });
        public ICommand EditConfiguration => new Command(async (obj) =>
        {
            Plant = obj as Plant;

            var previousPage = Navigation.NavigationStack.LastOrDefault();
            await Navigation.PushAsync(new ConfigurationManagerPage(Plant));
            Navigation.RemovePage(previousPage);
        });

        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        public ICommand SaveCommand => new Command(async () =>
        {
            Preferences.Set("IsPlantConfigured", true);
            Application.Current.MainPage = new NavigationPage(new StaffSplashPage());
        });


        #endregion
    }
}
