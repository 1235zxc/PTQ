﻿using Plugin.DeviceInfo;
using ProTraQ.Handheld.MobileApp.Interfaces;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class ManagerLoginPageViewModel : BindableObject
    {
        public INavigation Navigation { get; set; }
        public IMessage toast { get; set; }

        public ManagerLoginPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();

            AppVersion = CrossDeviceInfo.Current.AppVersion;
        }


        #region Properties

        private string _appVersion;
        public string AppVersion
        {
            get { return _appVersion; }
            set { _appVersion = value; OnPropertyChanged(); }
        }

        private string _mPassword;
        public string ManagerPassword
        {
            get { return _mPassword; }
            set { _mPassword = value; OnPropertyChanged(); }
        }

        #endregion

        public ICommand ManagerLoginButtonCommand => new Command(() =>
        {
            if (!string.IsNullOrEmpty(ManagerPassword))
            {
                if (ManagerPassword == Preferences.Get("ManagerLoginPassword", ""))
                {
                    Application.Current.MainPage = new NavigationPage(new ConfigurationManagerPage());
                }
                else
                {
                    toast.ShortAlert("You have entered wrong password");
                }
            }
            else
            {
                toast.ShortAlert("Enter password first!");
            }
        });

    }
}
