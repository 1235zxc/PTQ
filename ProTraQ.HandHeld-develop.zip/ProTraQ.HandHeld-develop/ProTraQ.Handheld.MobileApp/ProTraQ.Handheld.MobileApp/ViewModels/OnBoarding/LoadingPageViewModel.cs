﻿using System;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class LoadingPageViewModel:BindableObject
    {
        public INavigation Navigation { get; set; }

        public LoadingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        public ICommand GoToNGLoginPageCommand => new Command(() =>
        {
            //Navigation.PushAsync(new NGLoginPage());
        });
    }
}
