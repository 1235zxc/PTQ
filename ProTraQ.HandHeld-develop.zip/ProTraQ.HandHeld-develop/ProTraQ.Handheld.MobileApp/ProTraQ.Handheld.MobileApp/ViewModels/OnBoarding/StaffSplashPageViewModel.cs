﻿using ProTraQ.Handheld.MobileApp.Data;
using ProTraQ.Handheld.MobileApp.Helpers;
using ProTraQ.Handheld.MobileApp.Interfaces;
using ProTraQ.Handheld.MobileApp.Model;
using ProTraQ.Handheld.MobileApp.nswag;
using ProTraQ.Handheld.MobileApp.Views.LegacyMenu;
using ProTraQ.Handheld.MobileApp.Views.NG;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.CommunityToolkit.Extensions;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class StaffSplashPageViewModel:BindableObject
    {
        public INavigation Navigation { get; set; }

        public StaffSplashPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            GetPant();
            toast = DependencyService.Get<IMessage>();
            DateAndTime = Convert.ToString(DateTime.Now);

            //System.Reflection.Assembly a1 = System.Reflection.Assembly.GetCallingAssembly();
            //var AppVersion = a1.GetName().Version.ToString();
        }

        private async void GetPant()
        {
            PlantDatabase database = await PlantDatabase.Instance;

            var defaultPlant = await database.GetDefaultItemAsync();
            if (defaultPlant != null)
            {
                SelectedPlantIpAddress = defaultPlant.IP_Address;
                DefaultPlant = defaultPlant.Name;
            }
            else
            {
                DefaultPlant = "Select your plant";
            }

            var returndata = await database.GetItemsAsync();
            ConfiguredPlantList = returndata;
        }

        #region Properties
        public IMessage toast { get; set; }
        private string _dateTime;
        public string DateAndTime
        {
            get { return _dateTime; }
            set { _dateTime = value; }
        }

        private string _defaultPlant;
        public string DefaultPlant
        {
            get { return _defaultPlant; }
            set { _defaultPlant = value; OnPropertyChanged(nameof(DefaultPlant)); }
        }

        private string _ipaddress;
        public string SelectedPlantIpAddress
        {
            get { return _ipaddress; }
            set { _ipaddress = value; OnPropertyChanged(nameof(SelectedPlantIpAddress)); }
        }


        private List<Plant> _palletGetlist;
        public List<Plant> ConfiguredPlantList
        {
            get { return _palletGetlist; }
            set
            {
                _palletGetlist = value;
                OnPropertyChanged(nameof(ConfiguredPlantList));
            }
        }

        private bool _plantListVisible;

        public bool PlantListVisible
        {
            get { return _plantListVisible; }
            set { _plantListVisible = value; OnPropertyChanged(); }
        }


        #endregion
        public ICommand ConnectCommand => new Command(async() =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    if (DefaultPlant != "Select your plant")
                    {
                        await Navigation.PushAsync(new LoadingPage(), false);
                        HttpClient client = new HttpClient();
                        client.Timeout = TimeSpan.FromSeconds(5);
                        var testClient = new AuthClient(client);
                        var getresult = testClient.GetFacilityInformationAsync().GetAwaiter().GetResult();
                        var previousPage = Navigation.NavigationStack.LastOrDefault();
                        if (getresult != null)
                        {
                            if (!string.IsNullOrEmpty(getresult.Address1))
                            {
                                if (getresult.FacilityName == "Winfield")
                                {
                                    await Navigation.PushAsync(new NGLoginPage(DefaultPlant), false);
                                    Navigation.RemovePage(previousPage);
                                }
                                else
                                {
                                    await Navigation.PushAsync(new LegacyMenuPage(), false);
                                    Navigation.RemovePage(previousPage);
                                }
                                ApiUrlConstant.Ip_address = SelectedPlantIpAddress;
                            }
                            else
                            {
                                Navigation.RemovePage(previousPage);
                            }
                        }
                        else
                        {
                            toast.LongAlert("Something went wrong!");
                            Navigation.RemovePage(previousPage);
                        }
                    }

                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }
            catch (OperationCanceledException ex)
            {
                if (ex.CancellationToken.IsCancellationRequested)
                {
                    toast.LongAlert("Connection Error! A connection to the ProTraQ Server could not be established. Check the connection settings and contact Technical Support.");
                    //await App.Current.MainPage.DisplayAlert("Connection Error!",
                    //"A connection to the ProTraQ Server could not be established. Check the connection settings and contact Technical Support.", "OK");

                }
                await Navigation.PopAsync();
            }
            catch (Exception ex)
            {
                toast.LongAlert("Something went wrong!");
                await Navigation.PopAsync();
            }
            finally
            {

            }

        });
        public ICommand GoToConfiguratioMnagerLoginPage => new Command(() =>
        {
           Application.Current.MainPage = new NavigationPage(new ManagerLoginPage());
        });
        public ICommand GetAllPantCommand => new Command(() =>
        {
            PlantListVisible = true;
        });

        public ICommand TogglePopupCommand => new Command(() =>
        {
            PlantListVisible = false;
        });

        public ICommand SelectPlantCommand => new Command((obj) =>
        {
            var plant = obj as Plant;
            if (plant != null)
            {
                DefaultPlant = plant.Name;
                SelectedPlantIpAddress = plant.IP_Address;
                PlantListVisible = false;
            }
        });
    }
}
