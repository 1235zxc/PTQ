﻿using Plugin.DeviceInfo;
using ProTraQ.Handheld.MobileApp.Data;
using ProTraQ.Handheld.MobileApp.Interfaces;
using ProTraQ.Handheld.MobileApp.Model;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using System;
using System.Linq;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class ConfigurationManagerPageViewModel : BindableObject
    {

        #region Constructor
        public ConfigurationManagerPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();
            AppVersion = CrossDeviceInfo.Current.AppVersion;
        }

        public ConfigurationManagerPageViewModel(INavigation navigation, Plant plant) 
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();
            if (plant != null)
            {
                plantId = plant.Id;
                PlantName = plant.Name;
                PlantIP_Address = plant.IP_Address;
                SelectedColor = plant.PlantColor;
                IsSetDefault = plant.Default;
            }
        }
        #endregion


        #region Properties
        public IMessage toast { get; set; }
        public INavigation Navigation { get; set; }

        public int plantId { get; set; }
        private string _appVersion;
        public string AppVersion
        {
            get { return _appVersion; }
            set { _appVersion = value; OnPropertyChanged(); }
        }
        private string _plantName;
        public string PlantName
        {
            get { return _plantName; }
            set { _plantName = value; OnPropertyChanged(); }
        }

        private string _plantIp;
        public string PlantIP_Address
        {
            get { return _plantIp; }
            set { _plantIp = value; OnPropertyChanged(nameof(PlantIP_Address)); }
        }

        private bool _isSetdefault;
        public bool IsSetDefault
        {
            get { return _isSetdefault; }
            set { _isSetdefault = value; OnPropertyChanged(); }
        }

        private string  _sourceIc;

        public string  SourceIcon
        {
            get { return _sourceIc; }
            set { _sourceIc = value; OnPropertyChanged(); }
        }

        private string _color;

        public string SelectedColor
        {
            get { return _color; }
            set { _color = value; OnPropertyChanged(); }
        }
        #endregion 


        #region Commands
        public ICommand LogoutCommand => new Command(async () =>
        {
            Application.Current.MainPage = new NavigationPage(new ManagerLoginPage());
        });
        public ICommand SaveConfigurationCommand => new Command(async () =>
        {
            try
            {
                if (!string.IsNullOrEmpty(PlantName) && !string.IsNullOrEmpty(PlantIP_Address))
                {
                    PlantDatabase database = await PlantDatabase.Instance;
                    var configuredPlantList = await database.GetItemsAsync();
                    if (configuredPlantList.Count < 4)
                    {
                        bool contains_Ip = configuredPlantList.Any(item => item.IP_Address.ToLower().Contains(PlantIP_Address.ToLower()));
                        bool contains_Name = configuredPlantList.Any(item => item.Name.ToLower().Contains(PlantName.ToLower()));
                        bool contains_Color = configuredPlantList.Any(item => item.PlantColor.ToLower().Contains(SelectedColor.ToLower()));
                        if (contains_Ip || contains_Name || contains_Color)
                        {
                            toast.ShortAlert("Configuration already exist!");
                        }
                        else
                        {
                            if (IsSetDefault)
                            {
                                SourceIcon = "OkIcon";
                            }
                            else
                            {
                                SourceIcon = "NoSetIcon";
                            }
                            var plantmodel = new Plant()
                            {
                                Id = plantId,
                                Name = PlantName,
                                IP_Address = PlantIP_Address,
                                Default = IsSetDefault,
                                PlantColor = SelectedColor,
                                DefaultIcon = SourceIcon
                            };
                            var returndata = await database.SaveItemAsync(plantmodel);
                            if (returndata == 1)
                            {
                                Preferences.Set("IsPlantConfigured", true);
                                if (plantId != 0)
                                {
                                    toast.LongAlert("Configuration Updated!");
                                    await Navigation.PopAsync();
                                }
                                else
                                {
                                    toast.LongAlert("Configuration Saved!");
                                }
                                PlantName = string.Empty;
                                PlantIP_Address = string.Empty;
                                IsSetDefault = false;
                            }
                        }
                    }
                    else
                    {
                        toast.LongAlert("Device Configuration limit Completed");
                    }
                }
                else
                {
                    toast.LongAlert("First enter all Configuration details!");
                }
            }
            catch (Exception ex)
            {

            }
        });

        public ICommand ConfigurationDetailsCommand => new Command(async() =>
        {
            try
            {
                PlantDatabase database = await PlantDatabase.Instance;
                var configuredPlantList = await database.GetItemsAsync();
                if (configuredPlantList.Count > 0)
                {
                    if (plantId !=0)
                    {
                        var previousPage = Navigation.NavigationStack.LastOrDefault();
                        await Navigation.PushAsync(new ConfigurationDetailPage());
                        Navigation.RemovePage(previousPage);
                    }
                    else
                    {
                        await Navigation.PushAsync(new ConfigurationDetailPage());
                    }
                }
                else
                {
                    toast.LongAlert("Configuration is not set yet.");
                }
            }
            catch(Exception ex)
            {

            }
        });


        #endregion
    }
}
