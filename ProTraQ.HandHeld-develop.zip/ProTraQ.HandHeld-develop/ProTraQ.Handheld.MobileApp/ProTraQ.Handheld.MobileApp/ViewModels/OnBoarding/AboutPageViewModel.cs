﻿using System;
using System.Net.NetworkInformation;
using System.Net;
using Xamarin.Forms;
using System.Linq;
using Xamarin.Essentials;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Data;
using Plugin.DeviceInfo;
using ProTraQ.Handheld.MobileApp.Helpers;
using ProTraQ.Handheld.MobileApp.Views.NG;
using ProTraQ.Handheld.MobileApp.nswag;
using System.Net.Http;
using ProTraQ.Handheld.MobileApp.Interfaces;

namespace ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding
{
    public class AboutPageViewModel:BindableObject
    {
        public INavigation Navigation { get; set; }
        public AboutPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();
            GetFacilityInfo();


            //System.Reflection.Assembly a1 = System.Reflection.Assembly.GetCallingAssembly();
            //AppVersion = a1.GetName().Version.ToString();

        }

        private void GetFacilityInfo()
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    HttpClient client = new HttpClient();
                    client.Timeout = TimeSpan.FromSeconds(5);
                    var testClient = new CommonClient(client);
                    var getresult = testClient.GetAboutInformationAsync().GetAwaiter().GetResult();

                    if (getresult != null)
                    {
                        FacilityName = getresult.AboutInformation.FacilityName;
                        FacilityNumber = getresult.AboutInformation.FacilityNumber;
                        PlantIPaddress = ApiUrlConstant.Ip_address;
                        AppVersion = CrossDeviceInfo.Current.AppVersion;
                    }
                    else
                    {
                        toast.LongAlert("Something Went wrong!");
                    }
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }

            }
            catch (OperationCanceledException ex)
            {
                if (ex.CancellationToken.IsCancellationRequested)
                {
                    toast.LongAlert("Connection Error! A connection to the ProTraQ Server could not be established. Check the connection settings and contact Technical Support.");
                   

                }
            }
            catch (Exception ex)
            {
                toast.LongAlert("Something went wrong!");
            }
            finally
            {

            }

            var mainDisplayInfo = DeviceDisplay.MainDisplayInfo;
            ScreenResolution = mainDisplayInfo.Height + "*" + mainDisplayInfo.Width;
            DeviceManufacturerName = DeviceInfo.Manufacturer;
            var deviceId = Plugin.DeviceInfo.CrossDeviceInfo.Current.Id;
            MacAddress = deviceId;
        }

        private async void GetPlant(string plantName)
        {

            PlantDatabase database = await PlantDatabase.Instance;
            var pantdetails = await database.GetPlantDetailsByName(plantName);
            if (pantdetails != null)
            {
                FacilityName = pantdetails.Name;
                PlantIPaddress = pantdetails.IP_Address;
            }

        }



        #region Properties
        public IMessage toast { get; set; }

        private string _plantName;
        public string FacilityName
        {
            get { return _plantName; }
            set { _plantName = value; OnPropertyChanged(); }
        }
        private int _facilityNum;
        public int FacilityNumber
        {
            get { return _facilityNum; }
            set { _facilityNum = value; OnPropertyChanged(); }
        }
        private string _plantIpaddress;
        public string PlantIPaddress
        {
            get { return _plantIpaddress; }
            set { _plantIpaddress = value; OnPropertyChanged(); }
        }

        private string _appVersion;
        public string AppVersion
        {
            get { return _appVersion; }
            set { _appVersion = value; OnPropertyChanged(); }
        }

        private string _macAddress;
        public string MacAddress
        {
            get { return _macAddress; }
            set { _macAddress = value;}
        }

        private string _screenReso;
        public string ScreenResolution
        {
            get { return _screenReso; }
            set { _screenReso = value; }
        }

        private string _mfname;
        public string DeviceManufacturerName
        {
            get { return _mfname; }
            set { _mfname = value; }
        }

        #endregion
        public ICommand GobackCommand => new Command(() =>
        {
            Navigation.PopAsync();
        });

    }
}
