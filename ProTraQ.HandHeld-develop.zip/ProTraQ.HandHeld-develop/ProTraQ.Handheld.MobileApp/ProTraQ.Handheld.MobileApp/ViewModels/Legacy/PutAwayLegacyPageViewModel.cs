﻿using System;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.Legacy
{
    public class PutAwayLegacyPageViewModel:BindableObject
    {
        public INavigation Navigation { get; set; }
        public PutAwayLegacyPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
    }
}
