﻿using System;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.Legacy
{
    public class LegacyManageRowPageViewModel : BindableObject
    {
        public INavigation Navigation { get; set; }
        public LegacyManageRowPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
    }
}
