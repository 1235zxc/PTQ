﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.Views.Legacy;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.LegacyMenu
{
    public class LegacyMenuPageViewModel : BindableObject
    {
        #region Properties

        public INavigation Navigation { get; set; }
        public ObservableCollection<Legacys> Legacies { get; set; }
        public ObservableCollection<Count> Counts { get; set; }
        private bool _putAwayPopupIsvisible;
        public bool PutAwayPopupIsvisible
        {
            get { return _putAwayPopupIsvisible; }
            set { _putAwayPopupIsvisible = value; OnPropertyChanged(); }
        }
        #endregion

        #region Constructors
        public LegacyMenuPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            Counts = new ObservableCollection<Count>
            {
               new Count
               {

                  Legacy = new ObservableCollection<Legacys>
                  {
                      new Legacys{Id=1,Name="Put-Away",Image="bluevector"},
                      new Legacys{Id=2,Name="Look Up Item"},
                      new Legacys{Id=3,Name="Shipping",Image="bluevector"},
                      new Legacys{Id=4,Name="Receiving"},
                      new Legacys{Id=5,Name="Manage Rows"},
                  }
               },
               new Count
               {

                  Legacy = new ObservableCollection<Legacys>
                  {
                      new Legacys{Id=6,Name="Finished Goods",Image="bluevector"},
                      new Legacys{Id=7,Name="Physical Inventory"},
                      new Legacys{Id=8,Name="Pallet Building"},
                      new Legacys{Id=9,Name="Raw Material Update"},
                      new Legacys{Id=10,Name="Coater"},

                  }
               },new Count
               {

                  Legacy = new ObservableCollection<Legacys>
                  { new Legacys{Id=11,Name="Staging/Audits"},
                      new Legacys{Id=12,Name="Coil Integrity"},

                      new Legacys{Id=13,Name="Bundle Dropoff"},
                      new Legacys{Id=14,Name="Utilities",Image="bluevector"}
                  }
               }
            };
        }

        #endregion
        #region Commands
        public ICommand ExitCommand => new Command(() =>
        {
            Navigation.PopAsync();
        });
        public ICommand GotoPutAwayPageCommmand => new Command(() =>
        {
            Navigation.PushAsync(new PutAwayLegacyPage());
        });
        public ICommand GotoBatchPutAwayLegacyPageCommmand => new Command(() =>
        {
            Navigation.PushAsync(new BatchPutAwayLegacyPage());
        });
        public ICommand PutAwayPopupIsVisibleCommand => new Command(async () =>
        {
            PutAwayPopupIsvisible = !PutAwayPopupIsvisible;
        });

        public ICommand GotoAboutPageCommand => new Command(() =>
        {
            Navigation.PushAsync(new AboutPage());
        });

        #endregion

        #region Clasess
        public class Count
        {
            public ObservableCollection<Legacys> Legacy { get; set; }
        }
        public class Legacys
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public string Image { get; set; }
        }
        #endregion


    }
    

}


