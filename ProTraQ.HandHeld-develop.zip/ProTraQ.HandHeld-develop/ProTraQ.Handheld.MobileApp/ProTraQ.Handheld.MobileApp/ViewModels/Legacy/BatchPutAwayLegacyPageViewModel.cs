﻿using System;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels.Legacy
{
    public class BatchPutAwayLegacyPageViewModel:BindableObject
    {
        public INavigation Navigation { get; set; }
        public BatchPutAwayLegacyPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
    }
}
