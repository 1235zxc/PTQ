﻿using System.Windows.Input;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.ViewModels
{
    public class ManageCartonReferencePageViewModel:BindableObject
    {
        public ManageCartonReferencePageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }

        #region Properties
        public INavigation Navigation { get; set; }
        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion
    }
}
