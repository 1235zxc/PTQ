﻿using ProTraQ.Handheld.MobileApp.Model;
using ProTraQ.Handheld.MobileApp.Views.LegacyMenu;
using ProTraQ.Handheld.MobileApp.Views.NG;
using ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving;
using ProTraQ.Handheld.MobileApp.Views.OnBoarding;
using Xamarin.CommunityToolkit.Extensions;
using Xamarin.Essentials;
using Xamarin.Forms;


[assembly: ExportFont("Manrope-Regular.ttf", Alias = "ManropeRegular")]
[assembly: ExportFont("Manrope-Bold.ttf", Alias = "ManropeBold")]
[assembly: ExportFont("Manrope-SemiBold.ttf", Alias = "ManropeSemiBold")]
[assembly: ExportFont("Manrope-Medium.ttf", Alias = "ManropeMedium")]
[assembly: ExportFont("Manrope-Light.ttf", Alias = "ManropeLight")]
[assembly: ExportFont("Manrope-ExtraLight.ttf", Alias = "ManropeExtraLight")]
[assembly: ExportFont("Manrope-ExtraBold.ttf", Alias = "ManropeExtraBold")]
namespace ProTraQ.Handheld.MobileApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            if (Settings.FirstRun)
            {
                // Perform an action such as a "Pop-Up".
                Settings.FirstRun = false;
                Preferences.Set("ManagerLoginPassword", "123456");
            }
        }

        protected override void OnStart()
        {
            var isPlantConfigured = Preferences.Get("IsPlantConfigured", false);
            if (isPlantConfigured)
            {
                MainPage = new NavigationPage(new StaffSplashPage());
            }
            else
            {
                MainPage = new NavigationPage(new ManagerLoginPage());
            }
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
