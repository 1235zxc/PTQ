﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.Legacy;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.Legacy
{
    public partial class BatchPutAwayLegacyPage : ContentPage
    {
        public BatchPutAwayLegacyPage()
        {
            InitializeComponent();
            BindingContext = new BatchPutAwayLegacyPageViewModel(Navigation);
        }
    }
}
