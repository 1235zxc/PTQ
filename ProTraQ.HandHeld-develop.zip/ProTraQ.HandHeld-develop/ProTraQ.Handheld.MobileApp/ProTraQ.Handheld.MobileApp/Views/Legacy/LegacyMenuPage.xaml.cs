﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.LegacyMenu;
using ProTraQ.Handheld.MobileApp.Views.Legacy;
using ProTraQ.Handheld.MobileApp.Views.NG;
using Xamarin.Forms;
using static ProTraQ.Handheld.MobileApp.ViewModels.LegacyMenu.LegacyMenuPageViewModel;

namespace ProTraQ.Handheld.MobileApp.Views.LegacyMenu
{
    public partial class LegacyMenuPage : ContentPage
    {
        public LegacyMenuPageViewModel legacyMenu;
        public LegacyMenuPage()
        {
            InitializeComponent();
            legacyMenu = new LegacyMenuPageViewModel(Navigation);
            BindingContext = legacyMenu;
        }

       async void TapGestureRecognizer_Tapped(System.Object sender, System.EventArgs e)
        {
            
            var type = sender as Frame;
            if (type != null)
            {
                var x = type.BindingContext as Legacys;
                switch (x.Id)
                {
                    case 1:
                        legacyMenu.PutAwayPopupIsvisible = true;
                        break;
                    case 4:
                        await Navigation.PushAsync(new NGReceivingPage(x.Id));
                        break;
                    case 5:
                        await Navigation.PushAsync(new LegacyManageRowPage(x.Id));
                        break;

                }
            }
        }
    }
}
