﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.Legacy;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.Legacy
{
    public partial class LegacyManageRowPage : ContentPage
    {
        public LegacyManageRowPage(int id)
        {
            InitializeComponent();
            BindingContext = new LegacyManageRowPageViewModel(Navigation);
        }
    }
}
