﻿using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views
{
    public partial class ScanQRCodePopupPage : PopupPage
    {
        public ScanQRCodePopupPage()
        {
            InitializeComponent();
            _scanView.Options = new ZXing.Mobile.MobileBarcodeScanningOptions()
            {
                DelayBetweenContinuousScans = 2000
            };
            Device.BeginInvokeOnMainThread(() =>
            {
                var animation = new Animation(v => line.TranslationY = v, 0, 240);
                animation.Commit(this, "SimpleAnimation", 16, 1800, Easing.Linear, (v, c) => line.TranslationY = 240, () => true);
            });
        }


        public EventHandler<string> Action;
        private void _scanView_OnScanResult(ZXing.Result result)
        {
            try
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    if (result != null && System.Text.RegularExpressions.Regex.IsMatch(result.Text, @"^[a-zA-Z0-9]*$"))
                    {
                        var scanresult = result.Text;
                        Action?.Invoke(this, scanresult);
                        await PopupNavigation.Instance.PopAsync();
                    }
                    else
                    {
                        Action?.Invoke(this, null);
                        await DisplayAlert("Invalid QR Code", "We do not recognize this code. Please try another one.", "OK");
                    }
                });
            }
            catch (Exception)
            {

            }
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
        }


        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            _scanView.IsScanning = false;
            _scanView.IsAnalyzing = false;
            _scanView.IsTorchOn = false;
        }

        void _flashTurnOffOrOn_Clicked(System.Object sender, System.EventArgs e)
        {
            try
            {
                if (_flashTurnOffOrOn.BackgroundColor == Color.FromHex("#8f8584"))
                {
                    _scanView.IsTorchOn = true;
                    _flashTurnOffOrOn.BackgroundColor = Color.FromHex("#3D7CCA");
                }
                else
                {
                    _scanView.IsTorchOn = false;
                    _flashTurnOffOrOn.BackgroundColor = Color.FromHex("#8f8584");
                }

            }
            catch (Exception)
            {

            }
        }

      async  void  ImageButton_Clicked(System.Object sender, System.EventArgs e)
        {
            await PopupNavigation.Instance.PopAsync();
        }
    }
}
