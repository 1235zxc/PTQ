﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG
{
    public partial class BatchPutAwayNGPage : ContentPage
    {
        public BatchPutAwayNGPage()
        {
            InitializeComponent();
            BindingContext = new BatchPutAwayNGPageViewModel(Navigation);
        }
    }
}
