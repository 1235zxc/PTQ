﻿using ProTraQ.Handheld.MobileApp.nswag;
using ProTraQ.Handheld.MobileApp.ViewModels.NG;
using Xamarin.Forms;
using static ProTraQ.Handheld.MobileApp.ViewModels.NG.NGMenuPageViewModel;

namespace ProTraQ.Handheld.MobileApp.Views.NG
{
    public partial class NGMenuPage : ContentPage
    {
        public NGMenuPageViewModel nGMenu;
        public NGMenuPage(LoginResponse loginResponse, string plantName)
        {
            InitializeComponent();
            nGMenu= new NGMenuPageViewModel(Navigation, loginResponse, plantName);
            BindingContext = nGMenu;
        }

    
        async void TapGestureRecognizer_Tapped(System.Object sender, System.EventArgs e)
        {
            var type = sender as Frame;
            if (type != null)
            {
                var x = type.BindingContext as NGS;
                switch (x.id)
                {
                    case 1:
                        nGMenu.PutAwayPopupIsvisible = true;
                        break;
                    case 2:
                        nGMenu.LookupItemPopupIsVisible = true;
                        break;
                    case 4:
                       await Navigation.PushAsync(new NGReceivingPage(x.id));
                    break;
                    case 5:
                        await Navigation.PushAsync(new NGManageRowsPage(x.id));
                        break;
                   
                }
            }
        }

    }
}
