﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG
{
    public partial class NGReceivingPage : ContentPage
    {
        public NGReceivingPageViewModel NGReceivingVM;
        public NGReceivingPage()
        {
            InitializeComponent();
           NGReceivingVM = new NGReceivingPageViewModel(Navigation);
            BindingContext = NGReceivingVM;

        }

        public NGReceivingPage(int id)
        {
            InitializeComponent();
            NGReceivingVM = new NGReceivingPageViewModel(Navigation);
            BindingContext = NGReceivingVM;
        }

        void CustomEntry_ImageClicked(System.Object sender, System.EventArgs e)
        {
          //NGReceivingVM.ToggleReReceivingPopupCommand();
        }
    }
}
