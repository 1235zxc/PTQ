﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class NGRecivingWithTablesPage : ContentPage
    {
        public NGRecivingWithTablesPage()
        {
            InitializeComponent();
            BindingContext = new NGRecivingWithTablesPageViewModel(Navigation);
            //only for table data refernce
           // var nGManage = new NGManageRowPageViewModel(Navigation);
           // BindingContext = nGManage;

        }

        
    }
}
