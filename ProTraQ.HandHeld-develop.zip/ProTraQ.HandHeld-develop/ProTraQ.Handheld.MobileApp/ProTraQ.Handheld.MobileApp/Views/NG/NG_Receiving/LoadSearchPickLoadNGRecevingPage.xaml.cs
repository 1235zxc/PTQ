﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class LoadSearchPickLoadNGRecevingPage : ContentPage
    {
        public LoadSearchPickLoadNGRecevingPageViewModel loadSearchVM;
        public LoadSearchPickLoadNGRecevingPage()
        {
            InitializeComponent();
            loadSearchVM = new LoadSearchPickLoadNGRecevingPageViewModel(Navigation);
            BindingContext = loadSearchVM;
        }
    }
}
