﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class HoldNgReceivePage : ContentPage
    {
        public HoldNgReceivePageViewModel holdVM;
        public HoldNgReceivePage()
        {
            InitializeComponent();
            holdVM = new HoldNgReceivePageViewModel(Navigation);
            BindingContext = holdVM;
        }

        void TapGestureRecognizer_Tapped(System.Object sender, System.EventArgs e)
        {
            PlaceOnHoldVisibility.IsVisible = true;
            AddToBatchVisiblity.IsVisible = false;
        }

        void TapGestureRecognizer_Tapped_1(System.Object sender, System.EventArgs e)
        {
            AddToBatchVisiblity.IsVisible = true;
            PlaceOnHoldVisibility.IsVisible = false;


        }
    }
}
