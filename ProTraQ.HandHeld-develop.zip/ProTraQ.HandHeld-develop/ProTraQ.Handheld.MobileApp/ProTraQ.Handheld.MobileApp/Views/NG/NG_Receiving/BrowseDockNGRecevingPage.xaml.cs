﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class BrowseDockNGRecevingPage : ContentPage
    {
        public BrowseDockNGRecevingPageViewModel browseDockVM;
        public BrowseDockNGRecevingPage()
        {
            InitializeComponent();
            browseDockVM = new BrowseDockNGRecevingPageViewModel(Navigation);
            BindingContext = browseDockVM;
        }
    }
}

