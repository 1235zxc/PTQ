﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class StoreAllNgRecevingPage : ContentPage
    {
        public StoreAllNgRecevingPageViewModel storeAllVM;
        public StoreAllNgRecevingPage()
        {
            InitializeComponent();
            storeAllVM = new StoreAllNgRecevingPageViewModel(Navigation);
            BindingContext = storeAllVM;
        }
    }
}
