﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class ReceiveUnknownItemsPage : ContentPage
    {
        public ReceiveUnknownItemsPage()
        {
            InitializeComponent();
            BindingContext = new ReceiveUnknownItemsPageViewModel(Navigation);
        }
    }
}
