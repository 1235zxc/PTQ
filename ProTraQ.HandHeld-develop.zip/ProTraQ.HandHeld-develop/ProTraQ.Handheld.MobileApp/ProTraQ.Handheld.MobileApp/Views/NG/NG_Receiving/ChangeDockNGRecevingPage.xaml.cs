﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class ChangeDockNGRecevingPage : ContentPage
    {
        public ChangeDockNGRecevingPageViewModel changeDockVM;
        public ChangeDockNGRecevingPage()
        {
            InitializeComponent();
            changeDockVM = new ChangeDockNGRecevingPageViewModel(Navigation);
            BindingContext = changeDockVM;
        }
    }
}

