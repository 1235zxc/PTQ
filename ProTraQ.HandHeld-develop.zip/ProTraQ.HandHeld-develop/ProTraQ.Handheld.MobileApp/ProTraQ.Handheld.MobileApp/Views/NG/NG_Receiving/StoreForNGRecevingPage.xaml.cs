﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG.NG_Receiving;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG.NG_Receiving
{
    public partial class StoreForNGRecevingPage : ContentPage
    {
        public StoreForNGRecevingPageViewModel storeFor;
        public StoreForNGRecevingPage()
        {
            InitializeComponent();
            storeFor = new StoreForNGRecevingPageViewModel(Navigation);
            BindingContext = storeFor;

        }
    }
}
