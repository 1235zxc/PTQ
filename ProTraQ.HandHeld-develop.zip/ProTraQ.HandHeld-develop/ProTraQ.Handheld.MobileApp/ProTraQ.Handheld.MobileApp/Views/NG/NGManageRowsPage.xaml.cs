﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.NG;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG
{
    public partial class NGManageRowsPage : ContentPage
    {
        public NGManageRowPageViewModel nGManage;
 
        public NGManageRowsPage(int id)
        {
            InitializeComponent(); 
            var nGManage = new NGManageRowPageViewModel(Navigation);
            BindingContext = nGManage;

        }

       
    }
}
