﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.NG
{
    public partial class GeneralScanningPage : ContentPage
    {
        public GeneralScanningPage()
        {
            InitializeComponent();
        }
    }
}
