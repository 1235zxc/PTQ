﻿using ProTraQ.Handheld.MobileApp.ViewModels.PutAway;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.PutAway
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PutAwayPage : ContentPage
    {
        public PutAwayPage()
        {
            InitializeComponent();
            BindingContext = new PutAwayPageViewModel(Navigation);
        }
    }
}