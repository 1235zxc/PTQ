﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.OnBoarding
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class StaffSplashPage : ContentPage
    {
        public StaffSplashPage()
        {
            InitializeComponent();
            BindingContext = new StaffSplashPageViewModel(Navigation);
        }
    }
}