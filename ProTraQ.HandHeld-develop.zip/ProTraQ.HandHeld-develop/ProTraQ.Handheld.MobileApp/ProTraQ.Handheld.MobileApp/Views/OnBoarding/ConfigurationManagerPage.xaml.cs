﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.Data;
using ProTraQ.Handheld.MobileApp.Model;
using ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.OnBoarding
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ConfigurationManagerPage : ContentPage
    {
        private readonly ConfigurationManagerPageViewModel viewModel;
        public Color Color
        {
            get { return this.BtnColor.BackgroundColor; }
            set { this.BtnColor.BackgroundColor = value; }
        }
        public ConfigurationManagerPage()
        {
            InitializeComponent();
            var configurationManagerPageViewModel = new ConfigurationManagerPageViewModel(Navigation);
            BindingContext = configurationManagerPageViewModel;
            viewModel = configurationManagerPageViewModel;
            foreach (string colorName in colorDict.Keys)
            {
                pickerColorPicker.Items.Add(colorName);
            }

        }
        public ConfigurationManagerPage(Plant plant)
        {
            InitializeComponent();
            var configViewModel = new ConfigurationManagerPageViewModel(Navigation, plant);
            BindingContext = configViewModel;
            viewModel = configViewModel;
        }

        void Button_Clicked(System.Object sender, System.EventArgs e)
        {
            if(viewModel.plantId == 0)
            {
                pickerColorPicker.Focus();
            }

        }
        Dictionary<string, Color> colorDict = new Dictionary<string, Color>
        {
            { "Default", Color.Default },                  
            { "Black", Color.FromHex("#212121") },         { "Blue", Color.FromHex("#2196F3") },
            { "Brown", Color.FromHex("#795548") },
            { "Cyan", Color.FromHex("#00BCD4") },          { "DarkOrange", Color.FromHex("#FF5722") },
            { "Green", Color.FromHex("#4CAF50") },
            { "Gray", Color.FromHex("#9E9E9E") },          { "Indigo", Color.FromHex("#3F51B5") },
            { "LightBlue", Color.FromHex("#02A8F3") },     { "LightGreen", Color.FromHex("#8AC249") },
            { "Lime", Color.FromHex("#CDDC39") },          { "Orange", Color.FromHex("#FF9800") },
            { "Pink", Color.FromHex("#E91E63") },          { "Purple", Color.FromHex("#94499D") },
            { "Red", Color.FromHex("#D32F2F") },           { "Teal", Color.FromHex("#009587") },
            { "Yellow", Color.FromHex("#FFEB3B") },
        };

        void pickerColorPicker_SelectedIndexChanged(System.Object sender, System.EventArgs e)
        {
            string colorName = pickerColorPicker.Items[pickerColorPicker.SelectedIndex];
            this.Color = colorDict[colorName];
            viewModel.SelectedColor = colorName;
        }

        private async void CheckBox_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            try
            {
                if (viewModel.IsSetDefault)
                {
                    PlantDatabase database = await PlantDatabase.Instance;
                    var defaultSet = await database.GetDefaultItemAsync();
                    if (defaultSet != null)
                    {
                        viewModel.IsSetDefault = false;
                        viewModel.toast.ShortAlert("One plant is already set default");
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void IpCustomEntry_Unfocused(object sender, FocusEventArgs e)
        {
            string srchitem = _ipEntry.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(srchitem, @"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b"))
                {
                    viewModel.toast.LongAlert("Please input correct Ip");
                    viewModel.PlantIP_Address = String.Empty;
                }
            }
        }
    }
}