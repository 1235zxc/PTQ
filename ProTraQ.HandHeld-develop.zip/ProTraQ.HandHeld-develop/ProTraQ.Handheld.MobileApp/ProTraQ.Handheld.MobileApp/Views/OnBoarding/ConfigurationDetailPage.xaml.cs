﻿using ProTraQ.Handheld.MobileApp.Data;
using ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.OnBoarding
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ConfigurationDetailPage : ContentPage
    {
        private readonly ConfigurationDetailsViewModel viewModel;
        public ConfigurationDetailPage()
        {
            InitializeComponent();
            var configrationVM = new ConfigurationDetailsViewModel(Navigation);
            BindingContext = configrationVM;
            viewModel = configrationVM;
        }


        protected override async void OnAppearing()
        {
            base.OnAppearing();
            PlantDatabase database = await PlantDatabase.Instance;
            viewModel.ConfiguredPlantList = await database.GetItemsAsync();
            
        }
    }
}