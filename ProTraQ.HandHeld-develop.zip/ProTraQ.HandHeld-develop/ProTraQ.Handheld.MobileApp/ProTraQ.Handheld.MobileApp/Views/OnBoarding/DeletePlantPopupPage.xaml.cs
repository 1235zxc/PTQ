﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.CommunityToolkit.UI.Views;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.OnBoarding
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class DeletePlantPopupPage : Popup
    {
        public DeletePlantPopupPage(string PlantName)
        {
            InitializeComponent();
            plantName.Text = PlantName;
        }


        private void Button_ClickedOk(object sender, EventArgs e)
        {
            Dismiss(true);
        }

        private void Button_ClickedCancle(object sender, EventArgs e)
        {
            Dismiss(false);
        }
    }
}