﻿using ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.OnBoarding
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ManagerLoginPage : ContentPage
    {
        public ManagerLoginPage()
        {
            InitializeComponent();
            BindingContext = new ManagerLoginPageViewModel(Navigation);

        }
    }
}