﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.OnBoarding;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.OnBoarding
{
    public partial class NGLoginPage : ContentPage
    {
        public NGLoginPage(string plantName)
        {
            InitializeComponent();
            BindingContext = new NGLoginPageViewModel(Navigation, plantName);
        }
    }
}
