﻿using System;
using System.Collections.Generic;
using System.Windows.Input;
using ProTraQ.Handheld.MobileApp.CustomControls;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views
{
    public partial class OutlinedEntryControl : Grid
    {
        public event EventHandler ImageClicked;

        public OutlinedEntryControl()
        {
            InitializeComponent();
            var tgr = new TapGestureRecognizer { NumberOfTapsRequired = 1 };
            tgr.Tapped += ImageOn_Clicked;
            this.GestureRecognizers.Add(tgr);
        }

        private void ImageOn_Clicked(object sender, EventArgs e)
        {
            ImageClicked?.Invoke(sender, e);
        }

       public static readonly BindableProperty TextProperty = BindableProperty.Create(
       propertyName: nameof(Text),
       returnType: typeof(string),
       declaringType: typeof(OutlinedEntryControl),
       defaultValue: null,
       defaultBindingMode: BindingMode.TwoWay);

        public string Text
        {
            get => (string)GetValue(TextProperty);
            set { SetValue(TextProperty, value); }
        }

        public static readonly BindableProperty PlaceholderProperty = BindableProperty.Create(
          propertyName: nameof(Placeholder),
          returnType: typeof(string),
          declaringType: typeof(OutlinedEntryControl),
          defaultValue: null,
          defaultBindingMode: BindingMode.OneWay);

        public string Placeholder
        {
            get => (string)GetValue(PlaceholderProperty);
            set { SetValue(PlaceholderProperty, value); }
        }


        public static readonly BindableProperty ImageProperty = BindableProperty.Create(
        propertyName: nameof(Source),
        returnType: typeof(ImageSource),
        declaringType: typeof(OutlinedEntryControl),
        defaultValue: null,
        defaultBindingMode: BindingMode.TwoWay);

        public ImageSource  Source
        {
            get => (ImageSource)GetValue(ImageProperty);
            set { SetValue(ImageProperty, value); }
        }
        public static readonly BindableProperty RotationProperty = BindableProperty.Create(
            propertyName: nameof(Rotation),
            returnType: typeof(string),
            declaringType: typeof(OutlinedEntryControl),
            defaultValue: null,
            defaultBindingMode: BindingMode.TwoWay);
        public string Rotation
        {
            get => (string)GetValue(RotationProperty);
            set { SetValue(RotationProperty, value); }
        }
        public static readonly BindableProperty CommandProperty = BindableProperty.Create(
       propertyName: nameof(Command),
       returnType: typeof(ICommand),
       declaringType: typeof(OutlinedEntryControl),
       defaultValue: null,
       defaultBindingMode: BindingMode.TwoWay);


        public ICommand Command
        {
            get => (ICommand)GetValue(CommandProperty);
            set => SetValue(CommandProperty, value);
           
        }

        private void txtEntry_Focused(object sender, FocusEventArgs e)
        {

            lblPlaceholder.FontSize = 12;
            lblPlaceholder.TranslateTo(0, -18, 80, easing: Easing.Linear);
        }

        private void txtEntry_Unfocused(object sender, FocusEventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(Text))
            {
                lblPlaceholder.FontSize = 12;
                lblPlaceholder.TranslateTo(0, -18,80, easing: Easing.Linear);
            }
            else
            {
                lblPlaceholder.FontSize = 12;
                lblPlaceholder.TranslateTo(0, 0, 80, easing: Easing.Linear);
            }
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            txtEntry.Focus();
        }

        private void txtEntry_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
   
}

