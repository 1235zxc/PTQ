﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.PalletBuilding
{
    public partial class ModeSelectionPage : ContentPage
    {
        public ModeSelectionPage()
        {
            InitializeComponent();
        }

        void ProductionButton_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new ProductionModePage());
        }

        void ReconstructionButton_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new ReconstructionModePage());
        }

        void ValidateButton_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new ValidationModePage());
        }

        void PalletizeButton_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new PallletizerModePage());
        }
    }
}

