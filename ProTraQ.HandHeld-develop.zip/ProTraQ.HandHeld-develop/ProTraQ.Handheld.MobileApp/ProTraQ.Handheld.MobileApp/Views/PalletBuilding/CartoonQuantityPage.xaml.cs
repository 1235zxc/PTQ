﻿using System;
using System.Collections.Generic;
using ProTraQ.Handheld.MobileApp.ViewModels.PalletBuilding;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.PalletBuilding
{
    public partial class CartoonQuantityPage : ContentPage
    {
        CartoonQuantityViewModel ViewModel { get; set; }

        public CartoonQuantityPage()
        {
            InitializeComponent();
            BindingContext = ViewModel = new CartoonQuantityViewModel();
        }

    }
}

