﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.PalletBuilding
{
    public partial class ReconstructionModePage : ContentPage
    {
        public ReconstructionModePage()
        {
            InitializeComponent();
        }

        void ReturnButton_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PopAsync();
        }
    }
}

