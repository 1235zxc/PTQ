﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.Views.PalletBuilding
{
    public partial class PalletLoginPage : ContentPage
    {
        public PalletLoginPage()
        {
            InitializeComponent();
        }

        void ReturnButton_Clicked(System.Object sender, System.EventArgs e)
        {
        }

        void LoginButton_Clicked(System.Object sender, System.EventArgs e)
        {
            Navigation.PushAsync(new ModeSelectionPage());
        }
    }
}

