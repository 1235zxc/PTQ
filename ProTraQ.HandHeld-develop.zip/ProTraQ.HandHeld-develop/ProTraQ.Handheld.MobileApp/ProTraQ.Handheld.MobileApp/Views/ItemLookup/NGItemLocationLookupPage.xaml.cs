﻿using ProTraQ.Handheld.MobileApp.ViewModels.ItemLookup;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.ItemLookup
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class NGItemLocationLookupPage : ContentPage
    {
        public NGItemLocationLookupPage()
        {
            InitializeComponent();
            BindingContext = new NGItemLocationLookupPageViewModel(Navigation);
        }
    }
}