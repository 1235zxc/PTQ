﻿using ProTraQ.Handheld.MobileApp.ViewModels.ItemLookup;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views.ItemLookup
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SalesOrderAssignmentPage : ContentPage
    {
        public SalesOrderAssignmentPage()
        {
            InitializeComponent();
            BindingContext = new SalesOrderAssignmentPageViewModel(Navigation);
        }
    }
}