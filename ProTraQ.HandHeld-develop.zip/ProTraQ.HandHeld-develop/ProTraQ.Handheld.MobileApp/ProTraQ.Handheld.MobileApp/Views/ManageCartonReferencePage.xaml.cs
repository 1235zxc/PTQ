﻿using ProTraQ.Handheld.MobileApp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ProTraQ.Handheld.MobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ManageCartonReferencePage : ContentPage
    {
        public ManageCartonReferencePage()
        {
            InitializeComponent();
            BindingContext = new ManageCartonReferencePageViewModel(Navigation);
        }
    }
}