﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using ProTraQ.Handheld.MobileApp.Model;
using System.Net.Http.Headers;
using ProTraQ.Handheld.MobileApp.nswag;

namespace ProTraQ.Handheld.MobileApp.Helpers
{
    public class ApiHelper
    {
        public string BASE_URL = "http://" + ApiUrlConstant.Ip_address + "/api/";
        JsonSerializerSettings settings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };


        public async Task<ConnectionResponse> GetPlantConnection(string extURl)
        {
            var result = new ConnectionResponse();
            string url = string.Format("{0}{1}", BASE_URL, extURl);
            try
            {
                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var postresult = await client.GetAsync(url);
                if (postresult.IsSuccessStatusCode)
                {
                    var response = await postresult.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<ConnectionResponse>(response);
                }

            }
            catch (Exception ex)
            {

            }
            return result;
        }


        public async Task<NGLoginResponse> NGLogin(string extURl)
        {
            var result = new NGLoginResponse();
            string url = string.Format("{0}{1}", BASE_URL, extURl);
            try
            {
                HttpClient client = new HttpClient();
               // var testClient = new LoginClient(client);

                // Call GetAsync Values API  
               // var getresult = testClient.LoginAsync(extURl, null).GetAwaiter().GetResult();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var postresult = await client.GetAsync(url);

                if (postresult.IsSuccessStatusCode)
                {
                    var response = await postresult.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<NGLoginResponse>(response);
                }

            }
            catch (Exception ex)
            {

            }
            return result;
        }

        public async Task<AboutResponse> GetFacilityInfo(string extURl)
        {
            var result = new AboutResponse();
            string url = string.Format("{0}{1}", BASE_URL, extURl);
            try
            {
                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var postresult = await client.GetAsync(url);
                if (postresult.IsSuccessStatusCode)
                {
                    var response = await postresult.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<AboutResponse>(response);
                }

            }
            catch (Exception ex)
            {

            }
            return result;
        }
    }
}
