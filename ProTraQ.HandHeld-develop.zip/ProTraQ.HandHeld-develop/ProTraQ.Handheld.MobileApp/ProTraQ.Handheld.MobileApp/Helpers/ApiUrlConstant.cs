﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.Handheld.MobileApp.Helpers
{
    public static class ApiUrlConstant
    {
        public static string Ip_address { get; set; }
       
        //public static string BASE_URL = "http://"+ Ip_address +"/api/";

    }
}
