﻿using System;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.CustomControls
{
	public class BorderLessEntry : Entry
	{

	}
}

