﻿using System;
using Xamarin.Forms;

namespace ProTraQ.Handheld.MobileApp.CustomControls
{
    public class BorderLessEditor:Editor
    {
        public BorderLessEditor()
        {
        }
    }
}
