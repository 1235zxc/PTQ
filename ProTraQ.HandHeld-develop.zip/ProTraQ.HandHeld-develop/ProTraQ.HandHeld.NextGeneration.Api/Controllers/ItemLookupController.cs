﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ProTraQ.HandHeld.NextGeneration.Api.Repository;

namespace ProTraQ.HandHeld.NextGeneration.Api.Controller
{
    [ApiController]
    [Route("api/nextgeneration/[controller]")]
    public class ItemLookupController:ControllerBase
    {
        private readonly IItemLookupRepository _repository;
        
        public ItemLookupController(IItemLookupRepository repository)
        {
            _repository = repository;
        }
        [HttpGet(nameof(GetInvCartonInfo))]
        public async Task<ActionResult<object>>GetInvCartonInfo([FromQuery] string INVID_OR_SN)
        {
            DataSet oDS = new DataSet();
            try
            {
                var oDA = await _repository.InvCartonInfo(INVID_OR_SN);
                return oDA;
            }
            catch (System.Exception ex)
            {
                DataTable dt = new DataTable();
                dt.Columns.Add(new DataColumn("ReturnVal", typeof(int)));
                dt.Columns.Add(new DataColumn("ReturnMsg", typeof(string)));
                DataRow dr = dt.NewRow();
                dr["ReturnVal"] = -1;
                dr["ReturnMsg"] = ex.Message;
                dt.Rows.Add(dr);

                oDS.Tables.Add(dt);
            }
            return oDS;
            // end of method
        }
    }
}
