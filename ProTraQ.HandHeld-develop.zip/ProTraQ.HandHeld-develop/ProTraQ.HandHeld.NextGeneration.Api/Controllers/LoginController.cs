﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.NextGeneration.Api.Repository;
using ProTraQ.HandHeld.Shared.NextGeneration;
using static ProTraQ.HandHeld.Shared.Enumerations;

namespace ProTraQ.HandHeld.NextGeneration.Api.Controllers;

[ApiController]
[Route("api/nextgeneration/[controller]")]
public class LoginController : ControllerBase
{
    private static IConfiguration _config;
    private readonly ILogger<LoginController> _logger;
    private readonly ILoginRepository _login;
    public LoginController(ILogger<LoginController> logger,
                            ILoginRepository login, IConfiguration config)
    {
        _logger = logger;
        _login = login;
        _config = config;
    }

    [HttpGet(nameof(Login))]
    public async Task<ActionResult<LoginResponse>>Login([FromQuery] LoginRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.BarcodeToken))
        {
            var message = "Login Id is required.";
            _logger.LogError(message);
            return BadRequest(message);
        }
        var result = await _login.UserLogin_Verify(request.BarcodeToken, request.HandheldToken);
        var status = result.Set1.First();
        var adUserName = result.Set2.First();
        var operatingModeValue = _config.GetSection("OperatingMode").Value;
        var operatingMode = (OperatingMode)Enum.Parse(typeof(OperatingMode), operatingModeValue);//To Do
        return Ok(new LoginResponse() { ResultText = status.ResultText, ADUserName = adUserName.ADUserName, operatingMode = operatingMode.ToString() });
    }


}
