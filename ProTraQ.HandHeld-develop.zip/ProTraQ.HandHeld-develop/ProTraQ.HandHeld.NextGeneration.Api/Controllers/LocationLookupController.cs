﻿using Microsoft.AspNetCore.Mvc;
using ProTraQ.HandHeld.NextGeneration.Api.Repository;
using ProTraQ.HandHeld.Shared.NextGeneration;

namespace ProTraQ.HandHeld.NextGeneration.Api.Controllers
{
    [ApiController]
    [Route("api/nextgeneration/[controller]")]
    public class LocationLookupController : ControllerBase
    {
        private readonly ILocationLookupRepository _locationlookupRepository;

        public LocationLookupController(ILocationLookupRepository locationlookupRepository)
        {
            _locationlookupRepository = locationlookupRepository;
        }
        [HttpGet(nameof(GetCurrentInventoryLookup))]
        public async Task<List<LocationLookupModel>>GetCurrentInventoryLookup(string searchStr)
        {
            try
            {
                return await _locationlookupRepository.GetCurrentInventoryLookup(searchStr);
            }
            catch (Exception e)
            {
                throw (e);
            }
        }
    }
}
