﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.NextGeneration.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;

namespace ProTraQ.HandHeld.NextGeneration.Api.Controllers
{
    [ApiController]
    [Route("api/nextgeneration/[controller]")]
    public class ManageRowController : ControllerBase
    {
        private readonly ILogger<ManageRowController> _logger;
        private readonly IManageRowRepository _repository;
        public ManageRowController(ILogger<ManageRowController> logger, IManageRowRepository repository)
        {
            _logger = logger;
            _repository = repository;
        }

        [HttpGet(nameof(PutAwayItemAsLost_ALPHA))]
        public async Task<int>PutAwayItemAsLost_ALPHA([FromQuery] PutAwayItemAsLostRequest request)
        {
            int iReturn = 0;
            try
            {
                await _repository.PutAwayItemAsLost_ALPHA(request);
                if (request.Return != null)
                {
                    int.TryParse(request.Return.ToString(), out iReturn);
                }
                if (request.ReturnMsg != null)
                {
                    request.ReturnMsg = request.ReturnMsg.ToString();
                }
            }
            catch (Exception e) { throw (e); }
            return iReturn;
        }
        [HttpGet(nameof(MoveSpecProductionDateContents_ALPHA))]
        public async Task<ActionResult<object>>MoveSpecProductionDateContents_ALPHA([FromQuery] MoveSpecProductionDateContentsRequest request)
        {
            try
            {
                string sReturn = string.Empty;
                var response = await _repository.MoveSpecProductionDateContents_ALPHA(request);
                if (request.Return != null)
                    sReturn += request.Return.ToString();
                if (request.ReturnMsg != null)
                    sReturn += "|" + request.Return.ToString();

                return response;
            }
            catch (Exception e)
            {
                throw (e);
            }
        }
        [HttpGet(nameof(MoveRowContents_ALPHA))]
        public async Task<ActionResult<object>>MoveRowContents_ALPHA([FromQuery] MoveSpecProductionDateContentsRequest request)
        {
            try
            {
                // Create the data reader to get the data, add in the parameters
                var response = await _repository.MoveRowContents_ALPHA(request);
                return response;
            }
            catch (Exception e)
            {
                throw (e);
            }
        }

    }
}
