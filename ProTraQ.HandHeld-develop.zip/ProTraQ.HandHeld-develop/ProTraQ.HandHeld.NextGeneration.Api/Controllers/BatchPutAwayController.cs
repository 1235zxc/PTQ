﻿using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ProTraQ.HandHeld.NextGeneration.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using PtqAutomation.Automation.dbo;
using PtqAutomation.Automation.Factories.Interfaces;

namespace ProTraQ.HandHeld.NextGeneration.Api.Controllers;

[ApiController]
[Route("api/nextgeneration/[controller]")]
public class BatchPutAwayController : ControllerBase
{
    private static IConfiguration _config;
    private readonly IBatchPutAwayRepository _repository;
    IStorageServiceFactory _StorageService;
    RecurringJobManager _RecurringJobManager;
    public BatchPutAwayController(IBatchPutAwayRepository repository, IStorageServiceFactory StorageService, RecurringJobManager recurringJobManager)
    {
        _repository = repository;
        _StorageService = StorageService;
        _RecurringJobManager = recurringJobManager;
    }
    [HttpGet(nameof(UpdateLocation))]
    public string UpdateLocation([FromQuery] BatchPutAwayRequest request)
    {
        try
        {
            AutomationInventoryInformation o = _repository.GetAutomationInventoryInfo(request.invSN);
            AutomationLocationInformation L = _repository.GetLocationInfo(request.RowLocation);

            if (o == null)
            {
                return "-2_Inventory Item '" + request.invSN + "' not found.";
            }

            if (L == null)
            {
                return "-2_Location '" + request.RowLocation.ToString() + "' not found.";
            }

            if (L.AutomationImplementationType == 0 || !L.AutomationControlled)
            {
                return NG_UpdateLocation_LEGACY(request);
            }
            else
            {

                var model = new DomainAutomationModel
                {
                    PalletID = ((o.InvSN == string.Empty || o.InvSN == null) && o.InvID > 0) ? o.InvID.ToString() : o.InvSN,
                    PartNumber = o.ItemSpec,
                    Qty = o.Qty,
                    FromLocation = L.AutomationSystemLocationCode,
                    //ToLocation = L.DisplayLocationID,
                    MessageType = "SP",
                    ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)L.AutomationImplementationType,
                    ExchangePoint = L.ExchangeAutomationSystemLocationCode,
                    LocationId = L.LocationID
                };

                var storageService = _StorageService.GetStorageService(model);

                var storeResult = storageService.Store();

                //return new ResultMessage { ResultCode = storeResult.ReturnCode, ResultText = storeResult.ReturnMessage };                    
                if (storeResult != null)
                {
                    _RecurringJobManager.Trigger($"{System.Environment.MachineName}-AFT");
                    return storeResult.ReturnCode.ToString() + "_" + storeResult.ReturnMessage;
                }
                else
                {
                    return "-3_Unknown storage result. Contact Technical Support.";
                }
                //return new ResultMessage { ResultCode = storeResult.ReturnCode, ResultText = storeResult.ReturnMessage };

            }
        }
        catch (System.Exception ex)
        {
            return "-1_Error putting away inventory:" + ex.Message;
        }
    }
    [HttpGet(nameof(UpdateLocation_ALPHA))]
    public string UpdateLocation_ALPHA([FromQuery] BatchPutAwayRequest request)
    {

        try
        {

            AutomationInventoryInformation o = _repository.GetAutomationInventoryInfo(request.invSN);
            AutomationLocationInformation L = _repository.getAutomationLocationInfo_SELECT_ITEM_DisplayLocationID(request.DisplayTargetLocationID);
            if (o == null)
            {
                return "-2_Inventory Item '" + request.invSN + "' not found.";
            }

            if (L == null)
            {
                return "-2_Location '" + request.DisplayTargetLocationID + "' not found.";
            }

            if (L.AutomationImplementationType == 0)
            {
                return NG_UpdateLocation_ALPHA_LEGACY(request);
            }
            else
            {

                var model = new DomainAutomationModel
                {
                    PalletID = ((o.InvSN == string.Empty || o.InvSN == null) && o.InvID > 0) ? o.InvID.ToString() : o.InvSN,
                    PartNumber = o.ItemSpec,
                    Qty = o.Qty,
                    FromLocation = L.AutomationSystemLocationCode,
                    //ToLocation = L.DisplayLocationID,
                    MessageType = "SP",
                    ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)L.AutomationImplementationType,
                    ExchangePoint = L.ExchangeAutomationSystemLocationCode,
                    LocationId = L.LocationID
                };

                var storageService = _StorageService.GetStorageService(model);

                var storeResult = storageService.Store();
                if (storeResult != null)
                {
                    _RecurringJobManager.Trigger($"{System.Environment.MachineName}-AFT");
                    return storeResult.ReturnCode.ToString() + "_" + storeResult.ReturnMessage;
                }
                else
                {
                    return "-3_Unknown storage result. Contact Technical Support.";
                }
                //return new ResultMessage { ResultCode = storeResult.ReturnCode, ResultText = storeResult.ReturnMessage };

            }
        }
        catch (System.Exception ex)
        {
            return "-1_Error putting away inventory:" + ex.Message;
        }
    }
    private string NG_UpdateLocation_LEGACY(BatchPutAwayRequest request)
    {
        string returnValue = "";
        long lngInvID;

        if (request.invSN.Length > 12)
        {
            lngInvID = 0;
        }
        else if (!long.TryParse(request.invSN, out lngInvID))
        {
            lngInvID = 0;
        }
        request.invID = lngInvID;
        try
        {
            var putawayitem = _repository.BatchPutAwayItem(request);
            returnValue = request.strConfirmMsg.ToString();
        }
        catch (Exception e)
        {
            throw (e);
        }
        return returnValue;
    }
    private string NG_UpdateLocation_ALPHA_LEGACY(BatchPutAwayRequest request)
    {


        string returnValue = "";
        long lngInvID;

        if (request.invSN.Length > 12)
        {
            lngInvID = 0;
        }
        else if (!long.TryParse(request.invSN, out lngInvID))
        {
            lngInvID = 0;
        }
        request.invID = lngInvID;
        try
        {
            var putawayitem = _repository.BatchPutAwayItem_Alpha(request);
            bool blnPutAway = request.blnPutAway;
            returnValue = request.strConfirmMsg.ToString();
        }
        catch (Exception e)
        {
            throw (e);
        }
        return returnValue;
    }
}
