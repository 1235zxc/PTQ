﻿using Hangfire;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ProTraQ.HandHeld.NextGeneration.Api.Repository;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using PtqAutomation.Automation.dbo;
using PtqAutomation.Automation.Factories.Interfaces;
using System.Data.SqlClient;

namespace ProTraQ.HandHeld.NextGeneration.Api.Controllers;

[ApiController]
[Route("api/nextgeneration/[controller]")]
public class PutAwayController : ControllerBase
{
    private readonly ILogger<PutAwayController> _logger;
    private readonly IPutAwayRepository _repository;
    private IRetrievalServiceFactory _RetrievalService;
    private ICancelServiceFactory _CancelService;
    private readonly IStorageServiceFactory _StorageService;
    RecurringJobManager _RecurringJobManager;
    public PutAwayController(ILogger<PutAwayController> logger, IRetrievalServiceFactory RetrievalService, ICancelServiceFactory CancelService,
                             IPutAwayRepository repository, RecurringJobManager recurringJobManager, IStorageServiceFactory storageService)
    {
        _logger = logger;
        _repository = repository;
        _RetrievalService = RetrievalService;
        _CancelService = CancelService;
        _RecurringJobManager = recurringJobManager;
        _StorageService = storageService;
    }

    [HttpGet(nameof(RetrievePallet))]
    public async Task<string> RetrievePallet([FromQuery] RetrieveRequest request)
    {
        try
        {
            if (request.InvSN == null)
            {
                var message = "-1|One or more required parameters are missing.";
                return message;

            }

            if (string.IsNullOrEmpty(request.InvSN.Trim()))
            {
                return "-2|One or more required parameters are empty/invalid.";

            }

            AutomationInventoryInformation I = await _repository.GetAutomationInventoryInfo(request.InvSN);
            //AutomationLocationInformation L = _repository.Automation.usp_AutomationLocationInfo_SELECT_ITEM_DisplayLocationID(DisplayLocationID);
            if (I == null)
            {
                return "-2|Inventory Item '" + request.InvSN.ToString() + "' not found.";

            }

            if (I != null)
            {
                if (I.DisplayLocationID == I.ExchangeDisplayLocationID && I.ExchangeDisplayLocationID != "" && !request.Override)
                {
                    return "-2|Item " + I.PreferredDisplayID + " already appears to have been retrieved to" + I.ExchangeDisplayLocationID + ".";
                }
            }

            var model = new DomainAutomationModel
            {
                PalletID = ((I.InvSN == string.Empty || I.InvSN == null) && I.InvID > 0) ? I.InvID.ToString() : I.InvSN,
                MessageType = "RP",
                PartNumber = I.ItemSpec,
                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)I.AutomationImplementationType,
                //Qty = 1,
                //FromLocation = "Location",

                //ExchangePoint = "Location",
                LocationId = I.LocationID,
                ExchangePoint = I.ExchangeAutomationSystemLocationCode

            };
            var svc = _RetrievalService.GetRetrievalService(model);
            var res = svc.Retrieve();

            return res.ReturnCode.ToString() + "|" + (string.IsNullOrEmpty(res.ReturnMessage) ? string.Empty : res.ReturnMessage);
        }
        catch (System.Exception ex)
        {
            return "-1|" + ex.Message;
        }

    }

    [HttpGet(nameof(CancelPalletOperation))]
    public async Task<string> CancelPalletOperation([FromQuery] string strInvSN)
    {
        try
        {
            // see docs: https://git.silganmfg.com/developers/ProTraQ-Automation/blob/develop/PtqAutomation/Automation/dbo/DomainAutomationModel.cs
            AutomationInventoryInformation o = await _repository.GetAutomationInventoryInfo(strInvSN);

            if (o == null)
            {
                return "-2|Inventory Item '" + strInvSN + "' not found.";
            }


            var model = new DomainAutomationModel
            {
                PalletID = o.PreferredDisplayID,
                PartNumber = o.ItemSpec,
                Qty = o.Qty,
                //FromLocation = L.AutomationSystemLocationCode,
                //ToLocation = L.DisplayLocationID,
                //MessageType = "SP",
                ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)o.AutomationImplementationType,
                ExchangePoint = o.ExchangeAutomationSystemLocationCode,
                LocationId = o.LocationID
            };

            var cancelService = _CancelService.GetCancelService(model);

            var cancelResult = cancelService.Cancel();

            //return new ResultMessage { ResultCode = storeResult.ReturnCode, ResultText = storeResult.ReturnMessage };
            return cancelResult.ReturnCode.ToString() + "|" + (string.IsNullOrEmpty(cancelResult.ReturnMessage) ? string.Empty : cancelResult.ReturnMessage);

        }
        catch (System.Exception ex)
        {
            return "-1|" + ex.Message;
        }
    }

    [HttpGet(nameof(AutomationClearAutomationPoint))]
    public async Task<string> AutomationClearAutomationPoint([FromQuery] GetLocationOldestItemInformationRequest request)
    {
        try
        {
            AutomationLocationInformation L = await _repository.getAutomationLocationInfo_SELECT_ITEM_DisplayLocationID(request.LocationId);

            AutomationInventoryInformation I = await _repository.getAutomationInventoryInfo_SELECT_ITEM_INVID(request.invID);

            if (L != null)
            {
                if (L.DisplayLocationID == L.ExchangeDisplayLocationID)
                {
                    DomainAutomationModel d = new DomainAutomationModel()
                    {

                        ExchangePoint = L.ExchangeAutomationSystemLocationCode,
                        ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)L.AutomationImplementationType,
                        LocationId = L.LocationID
                    };
                    if (request.invID > 0 && I != null)
                    {
                        d.PalletID = I.PreferredDisplayID;
                    }
                    var rs = _RetrievalService.GetRetrievalService(d);

                    var res = rs.RetrieveComplete();
                    // _RecurringJobManager.Trigger($"{System.Environment.MachineName}-AFT");

                    return res.ReturnCode.ToString() + "|" + res.ReturnMessage;
                }

            }

            if (I != null)
            {
                if (I.DisplayLocationID == I.ExchangeDisplayLocationID)
                {
                    DomainAutomationModel d = new DomainAutomationModel()
                    {

                        ExchangePoint = I.ExchangeAutomationSystemLocationCode,
                        ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)L.AutomationImplementationType,
                        LocationId = I.LocationID,
                        PalletID = I.PreferredDisplayID
                    };
                    var rs = _RetrievalService.GetRetrievalService(d);
                    var res = rs.RetrieveComplete();
                    _RecurringJobManager.Trigger($"{System.Environment.MachineName}-AFT");
                    return res.ReturnCode.ToString() + "|" + res.ReturnMessage;

                }

            }
            if (I != null && L != null && I.ExchangeDisplayLocationID != I.DisplayLocationID && L.ExchangeDisplayLocationID != L.DisplayLocationID)
            {
                return "-2|Neither location for Inventory '" + request.invID.ToString() + "' (" + I.ExchangeDisplayLocationID + ") nor Exchange Point '" + request.LocationId + "' could be cleared because neither were Exchange points. Try again or contact technical support for assistance.";
            }

            if (I == null && L == null)
            {
                return "-2|Neither Inventory '" + request.invID.ToString() + "' nor Exchange Point '" + request.LocationId + "' were found to clear. Try again or contact technical support for assistance.";
            }

            return "-2|Nothing to clear at this time.";
        }
        catch (System.Exception ex)
        {
            return "-1|" + ex.Message;
        }
    }

    [HttpGet(nameof(UpdateLocationVerbose_ALPHA))]
    public async Task<string> UpdateLocationVerbose_ALPHA([FromQuery] GetLocationOldestItemInformationRequest request)
    {
        try
        {
            // see docs: https://git.silganmfg.com/developers/ProTraQ-Automation/blob/develop/PtqAutomation/Automation/dbo/DomainAutomationModel.cs
            AutomationInventoryInformation o = await _repository.GetAutomationInventoryInfo(request.InvSN);
            AutomationLocationInformation L = await _repository.getAutomationLocationInfo_SELECT_ITEM_DisplayLocationID(request.LocationId);
            if (o == null)
            {
                return "-2_Inventory Item '" + request.InvSN + "' not found.";
            }

            if (L == null)
            {
                return "-2_Location '" + request.LocationId + "' not found.";
            }

            if (L.AutomationImplementationType == 0)
            {
                return await UpdateLocationVerbose_ALPHA_LEGACY(request);
            }
            else
            {
                var model = new DomainAutomationModel
                {
                    PalletID = ((o.InvSN == string.Empty || o.InvSN == null) && o.InvID > 0) ? o.InvID.ToString() : o.InvSN,
                    PartNumber = o.ItemSpec,
                    Qty = o.Qty,
                    FromLocation = L.AutomationSystemLocationCode,
                    // ToLocation = L.DisplayLocationID,
                    MessageType = "SP",
                    ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)L.AutomationImplementationType,
                    ExchangePoint = L.ExchangeAutomationSystemLocationCode,
                    LocationId = L.LocationID
                };

                var storageService = _StorageService.GetStorageService(model);

                var storeResult = storageService.Store();
                _RecurringJobManager.Trigger($"{System.Environment.MachineName}-AFT");
                //return new ResultMessage { ResultCode = storeResult.ReturnCode, ResultText = storeResult.ReturnMessage };
                return storeResult.ReturnCode.ToString() + "_" + (string.IsNullOrEmpty(storeResult.ReturnMessage) ? string.Empty : storeResult.ReturnMessage);
            }
        }
        catch (System.Exception ex)
        {
            return "-1_" + ex.Message;
        }
    }

    private async Task<string> UpdateLocationVerbose_ALPHA_LEGACY(GetLocationOldestItemInformationRequest request)
    {
        string res = "";
        long lngInvID;

        if (request.InvSN.Length > 12)
        {
            lngInvID = 0;
        }
        else if (!long.TryParse(request.InvSN, out lngInvID))
        {
            lngInvID = 0;
        }
        request.invID = lngInvID;
        try
        {
            await _repository.getPUTAWAY_PutAwayItem_ALPHA(request);
            res = request.iReturn.ToString() + "_" + (request.strConfirmMsg);
        }
        catch (Exception e)
        {
            throw (e);
        }

        return res;
    }

    [HttpGet(nameof(UpdateLocationVerbose))]
    public async Task<string> UpdateLocationVerbose([FromQuery] GetLocationOldestItemInformationRequest request)
    {
        try
        {
            // see docs: https://git.silganmfg.com/developers/ProTraQ-Automation/blob/develop/PtqAutomation/Automation/dbo/DomainAutomationModel.cs
            AutomationInventoryInformation o = await _repository.GetAutomationInventoryInfo(request.InvSN);
            AutomationLocationInformation L = await _repository.getAutomationLocationInfo_SELECT_ITEM_LocationID(request.intRowLocation);

            if (o == null)
            {
                return "-2_Inventory Item '" + request.InvSN + "' not found.";
            }

            if (L == null)
            {
                return "-2_Location '" + request.invID + "' not found.";
            }

            if (L.AutomationImplementationType == 0)
            {
                return await UpdateLocationVerbose_LEGACY(request);
            }
            else
            {

                var model = new DomainAutomationModel
                {
                    PalletID = ((o.InvSN == string.Empty || o.InvSN == null) && o.InvID > 0) ? o.InvID.ToString() : o.InvSN,
                    PartNumber = o.ItemSpec,
                    Qty = o.Qty,
                    FromLocation = L.AutomationSystemLocationCode,
                    //ToLocation = L.DisplayLocationID,
                    MessageType = "SP",
                    ImplementationType = (PtqAutomation.Automation.Enum.ImplementationType)L.AutomationImplementationType,
                    ExchangePoint = L.ExchangeAutomationSystemLocationCode,
                    LocationId = L.LocationID
                };

                var storageService = _StorageService.GetStorageService(model);

                var storeResult = storageService.Store();
                _RecurringJobManager.Trigger($"{System.Environment.MachineName}-AFT");
                //return new ResultMessage { ResultCode = storeResult.ReturnCode, ResultText = storeResult.ReturnMessage };
                return storeResult.ReturnCode.ToString() + "_" + (string.IsNullOrEmpty(storeResult.ReturnMessage) ? string.Empty : storeResult.ReturnMessage);
            }
        }
        catch (System.Exception ex)
        {
            return ex.Message;
        }
    }

    private async Task<string> UpdateLocationVerbose_LEGACY(GetLocationOldestItemInformationRequest request)
    {
        string res = "";
        long lngInvID;

        if (request.InvSN.Length > 12)
        {
            lngInvID = 0;
        }
        else if (!long.TryParse(request.InvSN, out lngInvID))
        {
            lngInvID = 0;
        }
        request.invID = lngInvID;
        try
        {
            await _repository.GetPUTAWAY_PutAwayItem(request);
            res = request.iReturn.ToString() + "_" + (request.strConfirmMsg);
        }
        catch (Exception e)
        {
            throw (e);
        }

        return res;
    }


    [HttpGet(nameof(UseAlphaRowLocations))]
    public bool UseAlphaRowLocations()
    {
        try
        {
            // This will fail if called on an old version of ProTraQ.
            return true;
        }
        catch
        {
        }
        return false;
    }
}
