﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using System.Data;

namespace ProTraQ.HandHeld.NextGeneration.Api.Repository;
public interface IManageRowRepository
{

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_PutAwayItem_AsLost_ALPHA]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_PutAwayItem_AsLost_ALPHA]", CommandType.StoredProcedure)]
    Task<int?> PutAwayItemAsLost_ALPHA(PutAwayItemAsLostRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRow_ALPHA_FULL]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_MoveSpecProdDateContents_ForRow_ALPHA_FULL]", CommandType.StoredProcedure)]
    Task<Results<object>> MoveSpecProductionDateContents_ALPHA(MoveSpecProductionDateContentsRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_MoveRowContents_ForSpec_ALPHA_FULL]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_MoveRowContents_ForSpec_ALPHA_FULL]", CommandType.StoredProcedure)]
    Task<Results<object, object, object>> MoveRowContents_ALPHA(MoveSpecProductionDateContentsRequest request);
}
