﻿
using Insight.Database;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.NextGeneration.Api.Repository;

public interface IBatchPutAwayRepository
{
    /// <summary>
    /// Calls the stored procedure: [Automation].[usp_AutomationInventoryInfo_SELECT_ITEM_INVSN]
    /// </summary>
    [Sql("[Automation].[usp_AutomationInventoryInfo_SELECT_ITEM_INVSN]", CommandType.StoredProcedure)]
    AutomationInventoryInformation GetAutomationInventoryInfo(string InvSn);

    /// <summary>
    /// Calls the stored procedure: [Automation].[usp_AutomationLocationInfo_SELECT_ITEM_LocationID]
    /// </summary>
    [Sql("[Automation].[usp_AutomationLocationInfo_SELECT_ITEM_LocationID]", CommandType.StoredProcedure)]
    AutomationInventoryInformation GetLocationInfo(long LocationID);

    /// <summary>
    /// Calls the stored procedure: [dbo].[uspPutAwayItem]
    /// </summary>
    [Sql("[dbo].[uspPutAwayItem]", CommandType.StoredProcedure)]
    BatchPutAwayResponse BatchPutAwayItem(BatchPutAwayRequest request);

    /// <summary>
    /// Calls the stored procedure: [dbo].[uspPutAwayItem_ALPHA]
    /// </summary>
    [Sql("[dbo].[uspPutAwayItem_ALPHA]", CommandType.StoredProcedure)]
    BatchPutAwayResponse BatchPutAwayItem_Alpha(BatchPutAwayRequest request);

    /// <summary>
    /// Calls the stored procedure: [AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_DisplayLocationID]
    /// </summary>
    [Sql("[AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_DisplayLocationID]", CommandType.StoredProcedure)]
    AutomationLocationInformation getAutomationLocationInfo_SELECT_ITEM_DisplayLocationID(string DisplayTargetLocationID);

}
