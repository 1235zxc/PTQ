﻿using Insight.Database;
using ProTraQ.Handheld.Shared;
using ProTraQ.HandHeld.Shared.Common;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.NextGeneration.Api.Repository;

public interface IPutAwayRepository
{
    /// <summary>
    /// Calls the stored procedure: [Automation].[usp_AutomationInventoryInfo_SELECT_ITEM_INVSN]
    /// </summary>
    [Sql("[Automation].[usp_AutomationInventoryInfo_SELECT_ITEM_INVSN]", CommandType.StoredProcedure)]
    Task<AutomationInventoryInformation> GetAutomationInventoryInfo(string InvSn);

    /// <summary>
    /// Calls the stored procedure: [AUTOMATION].[usp_AutomationInventoryInfo_SELECT_ITEM_INVID]
    /// </summary>
    [Sql("[AUTOMATION].[usp_AutomationInventoryInfo_SELECT_ITEM_INVID]", CommandType.StoredProcedure)]
    Task<AutomationInventoryInformation> getAutomationInventoryInfo_SELECT_ITEM_INVID(long InviD);

    /// <summary>
    /// Calls the stored procedure: [AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_DisplayLocationID]
    /// </summary>
    [Sql("[AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_DisplayLocationID]", CommandType.StoredProcedure)]
    Task<AutomationLocationInformation> getAutomationLocationInfo_SELECT_ITEM_DisplayLocationID(string DisplayLocationID);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_PutAwayItem]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_PutAwayItem]", CommandType.StoredProcedure)]
    Task<string> GetPUTAWAY_PutAwayItem(GetLocationOldestItemInformationRequest getItemInformation);

    /// <summary>
    /// Calls the stored procedure: [AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_LocationID]
    /// </summary>
    [Sql("[AUTOMATION].[usp_AutomationLocationInfo_SELECT_ITEM_LocationID]", CommandType.StoredProcedure)]
    Task<AutomationLocationInformation> getAutomationLocationInfo_SELECT_ITEM_LocationID(long LocationID);

    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_PUTAWAY_PutAwayItem_ALPHA]
    /// </summary>
    [Sql("[dbo].[usp_PUTAWAY_PutAwayItem_ALPHA]", CommandType.StoredProcedure)]
    Task<string> getPUTAWAY_PutAwayItem_ALPHA(GetLocationOldestItemInformationRequest getItemInformation);
}

