﻿
using Insight.Database;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.NextGeneration.Api.Repository;

public interface ILoginRepository
{
    /// <summary>
    /// Calls the stored procedure:[Users].[UserLogins_Login_Verify]
    /// </summary>
    [Recordset(0, typeof(LoginResponse))]
    [Recordset(1, typeof(UserName))]
    [Sql("[Users].[UserLogins_Login_Verify]", CommandType.StoredProcedure)]
    Task<Results<LoginResponse,UserName>> UserLogin_Verify(string barcodeToken, string handheldToken);

    //[Sql("[Users].[UserLogins_Get_Details]", CommandType.StoredProcedure)]
    //Task<LoginResponse> UserLoginDetails(string barcodeToken, string handheldToken);

}
