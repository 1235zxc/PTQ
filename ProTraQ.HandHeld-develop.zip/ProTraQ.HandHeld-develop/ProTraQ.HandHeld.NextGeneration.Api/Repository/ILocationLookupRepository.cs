﻿using Insight.Database;
using ProTraQ.HandHeld.Shared.NextGeneration;
using System.Data;

namespace ProTraQ.HandHeld.NextGeneration.Api.Repository
{
    public interface ILocationLookupRepository
    {
        [Sql("[dbo].[usp_FG_CurrentInventoryLookup_HH]", CommandType.StoredProcedure)]
        Task<List<LocationLookupModel>> GetCurrentInventoryLookup(string searchStr);
    }
}
