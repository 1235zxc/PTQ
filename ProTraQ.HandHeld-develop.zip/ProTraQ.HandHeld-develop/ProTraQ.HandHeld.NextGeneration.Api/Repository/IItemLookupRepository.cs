﻿using Insight.Database;
using System.Data;


namespace ProTraQ.HandHeld.NextGeneration.Api.Repository;

public interface IItemLookupRepository
{
    /// <summary>
    /// Calls the stored procedure: [dbo].[usp_CARTONS_Qty_SELECT_CartonQtyInfoForInvID]
    /// </summary>
    [Sql("[dbo].[usp_CARTONS_Qty_SELECT_CartonQtyInfoForInvID]", CommandType.StoredProcedure)]
    Task<Results<object, object, object>> InvCartonInfo(string ItemId);
}
