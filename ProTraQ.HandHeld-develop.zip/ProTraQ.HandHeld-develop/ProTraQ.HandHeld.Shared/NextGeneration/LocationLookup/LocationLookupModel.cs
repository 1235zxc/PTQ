﻿using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using System.Text;

namespace ProTraQ.HandHeld.Shared.NextGeneration
{
    public class LocationLookupModel
    {
        public string ItemSpec { get; set; }
		public int StatusID { get; set; }
        public string StatusName { get; set; }
        public string DisplayLocationID { get; set; }
        public string LotCode { get; set; }
        public decimal QuantityMP { get; set; }
    }
}
