﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.NextGeneration
{
    public class RetrieveRequest
    {
       public string InvSN { get; set; }
       public bool Override { get; set; }
    }
}
