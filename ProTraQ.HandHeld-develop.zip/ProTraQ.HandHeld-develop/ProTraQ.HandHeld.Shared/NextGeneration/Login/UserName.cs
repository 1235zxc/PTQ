﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.NextGeneration
{
    public class UserName
    {
        public string ADUserName { get; set; }
    }
}
