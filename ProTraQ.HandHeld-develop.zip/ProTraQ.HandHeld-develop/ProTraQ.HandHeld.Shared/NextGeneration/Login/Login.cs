﻿namespace ProTraQ.HandHeld.Shared.NextGeneration
{
    public class LoginRequest
    {
        public string BarcodeToken { get; set; }

        public string HandheldToken { get; set; }
    }

    public class LoginResponse
    {
        public string ResultText { get; set; }
        public string ADUserName { get; set; }
        public string operatingMode { get; set; }
    }

}
