﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.NextGeneration
{
    public class AutomationInventoryInformation : AutomationLocationInformation
    {
        public string PreferredDisplayID { get; set; }
        public long InvID { get; set; }
        public string InvSN { get; set; }
        public decimal Qty { get; set; }
        public string ItemSpec { get; set; }
        public DateTime InvDT { get; set; }
        public int StatusID { get; set; }
        public long MadeForCustomer { get; set; }
        public string LotCode { get; set; }
        public string E1LotNumber { get; set; }
        //2020 04 JP ADDED THE 2 ABOVE FIELDS
    }
}

