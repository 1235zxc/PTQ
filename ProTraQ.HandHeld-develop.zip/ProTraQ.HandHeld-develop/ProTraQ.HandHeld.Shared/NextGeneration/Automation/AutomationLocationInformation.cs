﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.NextGeneration
{
    public class AutomationLocationInformation
    {
        public long LocationID { get; set; }
        public string DisplayLocationID { get; set; }
        public long FacilityContext { get; set; }
        public string FacilityContextName { get; set; }
        public string WarehouseCode { get; set; }
        public string DescSmall { get; set; }
        public string DescLarge { get; set; }
        public string DescAuto { get; set; }
        public string AutomationSystemLocationCode { get; set; }
        public int AFID { get; set; }
        public bool ForInput { get; set; }
        public bool ForOutput { get; set; }
        public long ASID { get; set; }
        public string ASName { get; set; }
        public int AutomationImplementationType { get; set; }
        public string ASGName { get; set; }
        public long ExchangeLocationID { get; set; }
        public string ExchangeDisplayLocationID { get; set; }
        public long ExchangeALID { get; set; }
        public string ExchangeAutomationSystemLocationCode { get; set; }
        public string ExchangeAFName { get; set; }
        public bool ExchangeForInput { get; set; }
        public bool ExchangeForOutput { get; set; }
        public bool AllowsBatchStorage { get; set; }
        public string AutomationImplementationTypeName { get; set; }
        public bool AutomationControlled { get; set; }
        public long ALID { get; set; }
        public string LastRequestDetail { get; set; }
        public DateTime LastRequestUTC { get; set; }
        public DateTime LastRequestLocalDT { get; set; }
        public string LastResponseDetail { get; set; }
        public DateTime LastResponseUTC { get; set; }
        public DateTime LastResponseLocalDT { get; set; }
    }
}
