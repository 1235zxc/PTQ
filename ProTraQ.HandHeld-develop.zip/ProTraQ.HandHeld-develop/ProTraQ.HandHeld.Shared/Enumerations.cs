﻿namespace ProTraQ.HandHeld.Shared
{
    public class Enumerations
    {
        public enum OperatingMode
        {
            Production = 0,
            Test = 1,
            Development = 2,
            Training = 3,
            NotSet = 99
        }
        public enum ConnectionType
        {
            Legacy = 0,
            NG = 1
        }
    }
}
