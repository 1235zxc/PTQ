﻿// Copyright (c) 2022 Silgan Holdings Inc. All rights reserved.
// This software constitutes the trade secrets and confidential and proprietary
// information of Silgan Holdings Inc. It is intended solely for use by Silgan
// Holdings Inc. This code may not be copied or redistributed to third parties
// without prior written authorization from Silgan Holdings Inc.

namespace ProTraQ.Handheld.Shared
{
    // This class can be used as a placeholder for queries 
    // that return more result sets than are consumed/used
    public struct NotUsed
    {
    }
}
