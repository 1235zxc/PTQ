﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class PlantConnectRequest
    {
        public string PlantId { get; set; }
    }
}
