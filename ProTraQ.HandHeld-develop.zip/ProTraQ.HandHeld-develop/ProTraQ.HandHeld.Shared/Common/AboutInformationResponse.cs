﻿
namespace ProTraQ.HandHeld.Shared.Common
{
    public class AboutInformationResponse
    {
        public string AppVersion { get; set; }
        public AboutInformation aboutInformation { get; set; }
    }

    public class AboutInformation
    {
        public int FacilityNumber { get; set; }
        public string FacilityName { get; set; }

        public int CompanyID { get; set; }

    }
}
