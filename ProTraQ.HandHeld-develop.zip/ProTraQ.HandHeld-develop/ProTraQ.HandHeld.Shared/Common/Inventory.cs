﻿namespace ProTraQ.HandHeld.Shared.Common
{
    public class Inventory
    {
        public int InventoryTypeID { get; set; }
        public string InventoryTypeName { get; set; }
    }
}
