﻿namespace ProTraQ.HandHeld.Shared.Common
{
    public class PlantConnectResponse
    {
        public bool IpFound { get; set; }
        public string ConnectionType { get; set; }
        public string PT_IP_Address { get; set; }
        public string OperatingMode { get; set; }
        public bool RequireHandheldLogin { get; set; }
        public int LocationLengthIndicator { get; set; }
        public bool EnableReceivingPutAway { get; set; }
        public bool EnableReceivingInspectionRequirement { get; set; }
        public bool AlphaLocationsAllowed { get; set; }//To Do
        public bool IsTraining { get; set; }
        public string FacilityName { get; set; }
        public int FacilityNumber { get; set; }
        public int CompanyID { get; set; }
        public int MinSNLengthForPlant { get; set; }
    }
}
