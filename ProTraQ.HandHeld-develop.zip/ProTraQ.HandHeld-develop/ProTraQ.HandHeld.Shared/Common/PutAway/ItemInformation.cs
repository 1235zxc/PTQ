﻿// Copyright (c) 2022 Silgan Holdings Inc. All rights reserved.
// This software constitutes the trade secrets and confidential and proprietary
// information of Silgan Holdings Inc. It is intended solely for use by Silgan
// Holdings Inc. This code may not be copied or redistributed to third parties
// without prior written authorization from Silgan Holdings Inc.

namespace ProTraQ.HandHeld.Shared.Common
{
    public class ItemInformation
    {
        public decimal InventoryId { get; set; }
        public string DisplayId { get; set; }
        public decimal Quantity { get; set; }
        public string E1LotNumber { get; set; }
        public string ItemSpecification { get; set; }
        public string StatusType { get; set; }
        public int Pass { get; set; }
        public string DisplayLocationId { get; set; }
        public decimal LocationId { get; set; }
        public decimal CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string ProductLineCode { get; set; }
        public string ProductLineName { get; set; }
        public string BaseColorCode { get; set; }
        public string BaseColorName { get; set; }
        public string PackCode { get; set; }
        public string PrintDesignCode { get; set; }
        public string PrintDesignName { get; set; }
    }
}
