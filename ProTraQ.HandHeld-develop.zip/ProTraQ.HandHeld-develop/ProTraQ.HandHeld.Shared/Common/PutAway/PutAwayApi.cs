﻿// Copyright (c) 2022 Silgan Holdings Inc. All rights reserved.
// This software constitutes the trade secrets and confidential and proprietary
// information of Silgan Holdings Inc. It is intended solely for use by Silgan
// Holdings Inc. This code may not be copied or redistributed to third parties
// without prior written authorization from Silgan Holdings Inc.

namespace ProTraQ.HandHeld.Shared.Common
{
    public class GetItemInformationRequest
    {
        public string ItemId { get; set; } = string.Empty;
    }

    public class GetItemInformationResponse
    {
        public ItemInformation ItemInformation { get; set; } = new ItemInformation();
    }

    public class GetLocationOldestItemInformationRequest
    {
        public string LocationId { get; set; }
        public string InvSN { get; set; }
        public string UserName { get; set; }

        public long invID { get; set; }

        public int iReturn { get; set; }
        public long intRowLocation { get; set; }

        public long RowLocation { get; set; }

        public string strConfirmMsg { get; set; }


    }

    public class GetLocationOldestItemInformationResponse
    {
        public ItemInformation ItemInformation { get; set; } = new ItemInformation();
    }

    public class GetDisplayLocationOldestItemInformationRequest
    {
        public string DisplayLocationId { get; set; } = string.Empty;
    }

    public class GetDisplayLocationOldestItemInformationResponse
    {
        public ItemInformation ItemInformation { get; set; } = new ItemInformation();
    }

    public class GetCartonInformationForItemRequest
    {
        public string ItemId { get; set; } = string.Empty;
    }

    public class GetCartonInformationForItemResponse
    {
        public CartonInformation CartonInformation { get; set; } = new CartonInformation();
    }
}
