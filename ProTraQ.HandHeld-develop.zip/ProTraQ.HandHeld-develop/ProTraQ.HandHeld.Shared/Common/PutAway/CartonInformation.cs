﻿// Copyright (c) 2022 Silgan Holdings Inc. All rights reserved.
// This software constitutes the trade secrets and confidential and proprietary
// information of Silgan Holdings Inc. It is intended solely for use by Silgan
// Holdings Inc. This code may not be copied or redistributed to third parties
// without prior written authorization from Silgan Holdings Inc.

namespace ProTraQ.HandHeld.Shared.Common
{
    public class CartonInformation
    {
        public int CartonCount { get; set; }

        public int CartonCountEstimated { get; set; }
    }
}
