﻿using System;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class Facility
    {
        public decimal FacilityID { get; set; }
        public decimal CompanyID { get; set; }
        public int FacilityNumber { get; set; }
        public decimal AddressBookNumber { get; set; }
        public string FacilityName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string Region { get; set; }
        public string ZipCode { get; set; }
        public string ExtendedZIPCode { get; set; }
        public string Country { get; set; }
        public bool Operational { get; set; }
        public decimal FacilityTypeID { get; set; }
        public string PhoneNumber { get; set; }
        public string FaxNumber { get; set; }
        public string Notes { get; set; }
        public string County { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public int Zone { get; set; }
        public string UTM_Easting { get; set; }
        public string UTM_Northing { get; set; }
        public string FacilityFein { get; set; }
        public Guid rowguid { get; set; }
        public string FacilityAlpha { get; set; }
        public FacilityShort SelectedFacility { get; set; }
        public string FacilityContextName { get; set; }
        public bool IsWarehouse { get; set; }

        #region Legacy Fields
        public bool? IsProduction { get; set; }
        public string OperatingMode { get; set; }
        #endregion
    }
}
