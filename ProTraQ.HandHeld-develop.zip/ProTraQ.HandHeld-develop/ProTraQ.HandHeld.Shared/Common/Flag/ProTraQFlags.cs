﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public enum ProTraQFlagEnum
    {
        Unknown,
        FacilityID,
        FacilityNumber,
        ProTraQVersionNumber,

        CoaterJobCompletionPercentage,
        CoaterBundleFinalizationPercentage,
        CoaterShowReturnToStorage,
        CoaterShowStackedItems,
        CoaterAllowAutomaticLoadOnFinalize,
        CoaterResetUntaggedBundleFlagOnJobClose,
        CoaterSplitCoatedPlateDefault,
        CoaterSplitPrimePlateDefault,
        CoaterSplitAllowRemoveAndHold,
        CoaterSplitAllowRemoveOnly,
        CoaterSplitAllowContinue,

        Tracking_BundleOperations,
        Tracking_Coil,
        Tracking_EndMaking,
        Tracking_FinishedGoods,
        Tracking_MaterialsReceiving,
        Tracking_PlateCoating,
        Tracking_Schedule,
        Tracking_SystemConfig,
        // Added by FWL:
        Coil_DisplayScrap,
        Coil_DisplayWeldCount,
        Coil_FloorHistoryReportID,
        CoilUploadStartDate,
        CoilUploadCoilCenter,
        CoilUploadTabstockCenter,
        CoilScheduleHideCoatLines,

        BundleTagCopiesPrime,
        BundleTagCopiesReject,
        BundleTagCopiesWIP,
        BundleTagCopiesFinal,
        SupportName,
        SupportPhoneNumber,
        SupportEmailAddress,
        PhysicalInventory_DefaultNumberOfTeams,
        PhysicalInventory_DefaultNumberOfScans,
        PhysicalInventory_UserTimeoutValue,
        PhysicalInventory_AllowBundleMarking,
        PhysicalInventory_ShowUnscannedItemVerify,
        PhysicalInventory_ShowUnexpectedItemVerify,
        // Added by FWL:
        CoilCompletionPercentage,
        SortStationCount,
        Shipping_AllowOrderEditing,
        Shipping_DockSchedulingEnabled,
        Shipping_TrailerSchedulingEnabled,
        Shipping_ValidationRequiresCureTime,
        Shipping_ValidationRequiresShipTo,
        Shipping_QuantityValidationAllowed,
        Shipping_ShipHFIForWarehouseOrders,
        Shipping_ShipUnfinishedForWarehouseOrders,
        Shipping_ShipToAllowUnknown,
        Shipping_RequireUserIdentification,
        Shipping_RequireVanNumber,
        Shipping_RequireSealNumber,
        Shipping_DockVerificationRequired,
        Shipping_WeightMaximum,
        Shipping_AllowOverweightOrdersToClose,
        Shipping_SupportsRemotePositiveRelease,
        FG_Workstation_MaxTimeAdjustment,
        FG_Workstation_RequireTimeSelect,
        FG_Schedule_SubWhiteList,
        FG_Schedule_ChangeoverHoursDefault,
        FG_Validation_AllowPackcodeSubs,
        FG_Tag_Final_Copies,
        FG_Tag_Shell_Copies,
        FG_Tag_NYPE_Copies,
        FG_UNCURED_BEHAVIOR,
        FG_SCHEDULE_SHOW_SPEC_WARNINGS,
        FG_LOS_SHOW_WORK_ORDERS,
        FG_SCHEDULE_DEFAULT_TO_AUTOCLOSE,
        FG_SCHEDULE_DEFAULT_FOR_PRIORITY,
        FG_SCHEDULE_CARTONS_PER_PALLET_REQUIREMENT,// SWA 2014.11.10
        FG_SCHEDULE_MOLD_REQUIREMENT,// SWA 2014.11.10
        /// <summary>
        ///  2008-02-01  FWL : Added new flags
        /// </summary>
        FG_SCHEDULE_DEFAULT_VIEW,
        FG_WORKSTATION_ONLYSUP_CHANGEPRINTER,
        FG_WORKSTATION_DISABLE_HOLDS,
        FG_SORT_STATIONS,
        FG_SORT_LINEID,

        FG_HANDHELD_ALLOW_FLOOR_CHANGEOVER, // SWA 2009-03-04
        FG_HANDHELD_ALLOW_FLOOR_LOAD, // SWA 2009-03-04

        /// <summary>
        /// 2008-02-12  FWL : Added tags for printing holds
        /// </summary>
        BUNDLE_TAG_HOLD_COIL_COPIES,
        BUNDLE_TAG_HOLD_PLATE_COPIES,
        BUNDLE_TAG_HOLD_CANS_COPIES,
        BUNDLE_TAG_HOLD_ENDS_COPIES,


        FG_COUNTERS_RESET_BEHAVIOR, //2008-02-15 FWL : Counter Reset behaviors

        /// 2008-05-22  FWL : Added to handle coated coil
        FG_COILCOAT_ROUND_BB,

        TAG_NESTLE_END_CODE,
        TAG_NESTLE_CAN_CODE,

        PUTAWAY_AllowChangeStatusOnHH,
        PUTAWAY_ShowInReceivingOnHH,
        PUTAWAY_LocationLengthValue,

        QA_ClaimSystem,

        //2015 04 JP
        WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_FG,
        WORKORDERS_ENABLE_CREATION_FROM_E1_FOR_COAT_COILS,
        WORKORDERS_ENABLE_CREATION_FROM_E1_BY_USER,
        BOL_PRINT_SHIPPING,

        //2015 08 jp
        BOL_PRINT_SHIPPING_NBR_OF_COPIES,

        //2015 09 jp
        FG_SPLITCAP_HIDE_EACHES,

        HH_EXT_DISPLAY_SHIPPING_PRINT_DESIGN,

        //2016 01 jp
        RFSMART_SHIPREC_NOTICE,
        //2016 05 JP
        SHIPPING_VIT_DEFAULT,

        PI_TO_ERP_COIL_LOCATION_MODE,
        PI_TO_ERP_CLAIM_COIL_MODE,
        PI_TO_ERP_CLAIM_PLATE_MODE,
        PI_TO_ERP_CLAIM_FG_MODE,
        RECEIVING_INSPECTION_ACTIVE,
        BOL_PRINT_FORMAT,
        //2020 08 JP
        FG_SCHEDULE_ALLOW_OVERPRODUCTION,
        RECEIVING_INSPECTION_REQUIRED,

        //2020 10 22 jp
        AIS_BYPASS_TRANSFORMIDS,
        FG_SCHEDULE_WOPARTSLIST_shopfloor_behavior,

        //2022 02 19 co
        FacilityAgvSystem,
    }
}
