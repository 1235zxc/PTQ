﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class BatchPutAwayRequest
    {
        public long invID { get; set; }
        public string invSN { get; set; }
        public string UserName { get; set; }
        public long RowLocation { get; set; }
        public string DisplayTargetLocationID { get; set; }
        public bool blnPutAway { get; set; }  
        public string strConfirmMsg { get; set; }
    }
}
