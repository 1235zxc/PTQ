﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class BatchPutAwayResponse
    {
        public bool blnPutAway { get; set; }
        public string strConfirmMsg { get; set; }
    }
}
