﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class MoveSpecProductionDateContentsRequest
    {
        public string ItemSpec { get; set; }
        public long SourceLocationID { get; set; }
        public string ProductionDate { get; set; }
        public long TargetLocationID { get; set; }
        public bool MarkAsLost { get; set; }
        public long FacilityContext { get; set; }
        public int InventoryTypeID { get; set; }
        public bool IncludeLost { get; set; }
        public bool IncludeResale { get; set; }
        public bool IncludePR { get; set; }
        public bool Reget { get; set; }
        public int Return { get; set; }
        public string ReturnMsg { get; set; }
        public string SourceDisplayLocationID { get; set; }
        public string TargetDisplayLocationID { get; set; }
    }
}
