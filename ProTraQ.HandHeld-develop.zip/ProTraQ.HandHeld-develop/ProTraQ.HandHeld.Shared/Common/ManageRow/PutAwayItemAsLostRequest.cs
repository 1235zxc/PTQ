﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class PutAwayItemAsLostRequest
    {
        public long InvID { get; set; }
        public int LocationID { get; set; }
        public string UserName { get; set; }
        public string DisplayTargetLocationID { get; set; }
        public int Return { get; set; }
        public string ReturnMsg { get; set; }
    }
}
