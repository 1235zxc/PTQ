﻿using System;
using System.Collections.Generic;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class GetFacilityInfoResponse
    {
        public List<Facility> FacilityInformation { get; set; } = new List<Facility>();
    }
    public class GetInventoryResponse
    {
        public List<Inventory> InventoryTypes { get; set; } = new List<Inventory>();
    }

    public class GetRowContentRequest
    {
        public string DisplayLocationID { get; set; }
        public long FacilityContext { get; set; }
        public int InventoryTypeID { get; set; }
        public bool IncludeLost { get; set; }
        public bool IncludeResale { get; set; }
        public bool IncludePR { get; set; }
        public int Return { get; set; }
        public string ItemSpec { get; set; }
        public DateTime ProductionDate { get; set; }
        public string INV_OR_SN { get; set; }
    }

    public class ItemInfo
    {
        public string ItemSpec { get; set; }
        public int ItemCount { get; set; }
        public int LocationID { get; set; }
        public int DisplayLocationID { get; set; }
        public int LocationTypeID { get; set; }
        public string Name { get; set; }
        public long FacilityContext { get; set; }
        public string FacilityContextName { get; set; }
        public DateTime ProductionDate { get; set; }
    }

    public class InventoryInfo
    {
        public int InvID { get; set; }
        public string InvSN { get; set; }
        public int DisplayKey { get; set; }
        public string ItemSpec { get; set; }
        public int Qty { get; set; }
        public int StoredForCustomer { get; set; }
        public int LocationID { get; set; }
        public int DisplayLocationID { get; set; }
        public int StatusID { get; set; }
        public int StatusType { get; set; }
        public long InvDT { get; set; }
        public long FacilityContext { get; set; }
        public string FacilityContextName { get; set; }
    }

    public class GetResponse
    {
        public List<ItemInfo> ItemInfo { get; set; } = new List<ItemInfo>();
        public List<InventoryInfo> InventoryInfo { get; set; } = new List<InventoryInfo>();
        public List<ItemInfo> ItemsInfo { get; set; } = new List<ItemInfo>();
    }
}
