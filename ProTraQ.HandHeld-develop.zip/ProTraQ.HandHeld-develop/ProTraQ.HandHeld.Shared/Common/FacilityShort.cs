﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProTraQ.HandHeld.Shared.Common
{
    public class FacilityShort
    {
        public int CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string DisplayText { get; set; }
    }
}
