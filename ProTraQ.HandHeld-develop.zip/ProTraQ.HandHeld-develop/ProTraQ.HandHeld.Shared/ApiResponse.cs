﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace ProTraQ.HandHeld.Shared
{
    public class ApiResponse
    {
        public const string ErrorMessage = "Something went wrong. Please try again later.";
        public const string SuccessMessage = "Successful!";
        public const string UnAuthorizeAccess = "You are not authroized to perform this operation.";
        public int Id { get; set; }
        public string Message { get; set; }
        public HttpStatusCode StatusCode { get; set; }
        public dynamic Data { get; set; }
    }
}
