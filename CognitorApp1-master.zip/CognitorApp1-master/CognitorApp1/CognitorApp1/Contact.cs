﻿namespace CognitorApp1
{
    internal class Contact
    {
        public string Name { get; internal set; }
    }
}