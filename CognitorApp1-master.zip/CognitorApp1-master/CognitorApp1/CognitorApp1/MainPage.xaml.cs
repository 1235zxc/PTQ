﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace CognitorApp1
{
    public partial class MainPage : ContentPage
    {
        private bool isbool;
        static string date;
        public string Tooltip { get; private set; }

        public MainPage()
        {
            InitializeComponent();

            //var list = new List<ListColors>();
            //list.Add(new ListColors
            //{
            //    color = isbool ? "Red" : "Gray",
            //});

            //list1.ItemsSource = list;
            BindingContext = this;




        }

        private void list1_ItemTapped(object sender, ItemTappedEventArgs e)
        {
            isbool = !isbool;
        }

        private async void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new Page1());

        }

       
    }
    public class ListColors
    {

        public string color { get; set; }
    }
}
