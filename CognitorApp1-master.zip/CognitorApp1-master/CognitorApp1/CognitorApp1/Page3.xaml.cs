﻿using Plugin.myToolTip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CognitorApp1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page3 : ContentPage
    {
        public Page3()
        {
            InitializeComponent();
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            try
            {
                foreach (var c in mainLayout.Children)
                {
                    if (c != null && XamarinAndroidToolTIp.GetHasTooltip(c))
                    {
                        XamarinAndroidToolTIp.SetHasTooltip(c, false);
                        XamarinAndroidToolTIp.SetHasTooltip(c, true);
                    }
                }
            }
            catch
            {
            }


        }

        private void btn4_Clicked(object sender, EventArgs e)
        {

            foreach (var c in mainLayout.Children)
            {

                if (c.Id == btn4.Id)
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

                if (XamarinAndroidToolTIp.GetHasTooltip(c))
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, false);
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }


            }
        }

        private void TapGestureRecognizer_Tapped_1(object sender, EventArgs e)
        {
            foreach (var c in mainLayout.Children)
            {
                if (c.Id == btn3.Id)
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

                if (XamarinAndroidToolTIp.GetHasTooltip(c))
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, false);
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

            }
        }

        private void TapGestureRecognizer_Tapped_2(object sender, EventArgs e)
        {

            foreach (var c in mainLayout.Children)
            {
                if (c.Id == btn2.Id)
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

                if (XamarinAndroidToolTIp.GetHasTooltip(c))
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, false);
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

            }
        }

        private void btn_Clicked(object sender, EventArgs e)
        {

            foreach (var c in mainLayout.Children)
            {

                if (c.Id == btn.Id)
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

                if (XamarinAndroidToolTIp.GetHasTooltip(c))
                {
                    XamarinAndroidToolTIp.SetHasTooltip(c, false);
                    XamarinAndroidToolTIp.SetHasTooltip(c, true);
                }

            }
        }
    }
}