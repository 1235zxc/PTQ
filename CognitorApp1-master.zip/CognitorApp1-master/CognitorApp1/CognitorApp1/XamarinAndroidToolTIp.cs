﻿using CognitorApp1;
using Plugin.myToolTip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin.Forms;

namespace CognitorApp1
{
    public static class XamarinAndroidToolTIp
    {
        public static readonly BindableProperty HasTooltipProperty =
          BindableProperty.CreateAttached("HasTooltip", typeof(bool), typeof(XamarinAndroidToolTIp), false, propertyChanged: OnHasTooltipChanged);
        public static readonly BindableProperty TextColorProperty =
          BindableProperty.CreateAttached("TextColor", typeof(Color), typeof(XamarinAndroidToolTIp), Color.White);
        public static readonly BindableProperty BackgroundColorProperty =
          BindableProperty.CreateAttached("BackgroundColor", typeof(Color), typeof(XamarinAndroidToolTIp), Color.Black);
        public static readonly BindableProperty TextProperty =
          BindableProperty.CreateAttached("Text", typeof(string), typeof(XamarinAndroidToolTIp), string.Empty);
        public static readonly BindableProperty PositionProperty =
        BindableProperty.CreateAttached("Position", typeof(TooltipPosition), typeof(XamarinAndroidToolTIp), TooltipPosition.Bottom);
        public static bool GetHasTooltip(BindableObject view)
        {
            return (bool)view.GetValue(HasTooltipProperty);
        }

        public static void SetHasTooltip(BindableObject view, bool value)
        {
            view.SetValue(HasTooltipProperty, value);
        }

        public static Color GetTextColor(BindableObject view)
        {
            return (Color)view.GetValue(TextColorProperty);
        }

        public static void SetTextColor(BindableObject view, Color value)
        {
            view.SetValue(TextColorProperty, value);
        }

        public static Color GetBackgroundColor(BindableObject view)
        {
            return (Color)view.GetValue(BackgroundColorProperty);
        }

        public static void SetBackgroundColor(BindableObject view, Color value)
        {
            view.SetValue(BackgroundColorProperty, value);
        }

        public static string GetText(BindableObject view)
        {
            return (string)view.GetValue(TextProperty);
        }

        public static void SetText(BindableObject view, string value)
        {
            view.SetValue(TextProperty, value);
        }

        public static TooltipPosition GetPosition(BindableObject view)
        {
            return (TooltipPosition)view.GetValue(PositionProperty);
        }

        public static void SetPosition(BindableObject view, TooltipPosition value)
        {
            view.SetValue(PositionProperty, value);
        }

        private static void OnHasTooltipChanged(BindableObject bindable, object oldValue, object newValue)
        {
            if (!(bindable is View view))
                return;


            bool hasTooltip = (bool)newValue;
            if (!hasTooltip)
            {
                var toRemove = view.Effects.FirstOrDefault(e => e is ControlXamarinAndroidToolTIp);
                if (toRemove != null)
                {
                    view.Effects.Remove(toRemove);
                }
                return;
            }
            view.Effects.Add(new ControlXamarinAndroidToolTIp());

        }
    }

    internal class ControlXamarinAndroidToolTIp : RoutingEffect
    {
        public ControlXamarinAndroidToolTIp() : base("CrossGeeks.XamarinAndroidToolTIp")
        {

        }
    }
    public enum TooltipPosition
    {
        Top,
        Bottom,
        Left,
        Right
    }

}
