﻿using Plugin.myToolTip;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CognitorApp1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page2 : ContentPage
    {
        public Page2()
        {
            InitializeComponent();
        }

        private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
        {
            foreach (var c in mainStackLayout.Children.Where(
            // Turn off any that are on.
            c => XamarinAndroidToolTIp.GetHasTooltip(c)))
            {
                XamarinAndroidToolTIp.SetHasTooltip(c, false);
            }

            if (sender is View activeView)
            {
                XamarinAndroidToolTIp.SetHasTooltip(activeView, true);
            }
        }

   
    }
}