﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace QuiltsMobileApp.NavigationServices
{
    public class RichNavigationService
    {
        public static async Task PushAsync(Page page, Type type, bool isAnimated = false)
        {
            var i = Application.Current.MainPage.Navigation.NavigationStack.LastOrDefault();
            if (i == null)
            {
                await Application.Current.MainPage.Navigation.PushAsync(page, isAnimated);
                return;
            }
            if (i.GetType() != type)
            {
                await Application.Current.MainPage.Navigation.PushAsync(page, isAnimated);
                return;
            }
        }
        public static async Task PushModalAysnc(Page page, Type type, bool isAnimated = true)
        {
            var i = Application.Current.MainPage.Navigation.NavigationStack.LastOrDefault();
            if (i == null)
            {
                await Application.Current.MainPage.Navigation.PushModalAsync(page, isAnimated);
                return;
            }
            if (i.GetType() != type)
            {
                await Application.Current.MainPage.Navigation.PushModalAsync(page, isAnimated);
                return;
            }
        }
        public static async Task PopAsync()
        {
            await Application.Current.MainPage.Navigation.PopAsync();
        }
        public static async Task PopModelAsync()
        {
            try
            {
                await Application.Current.MainPage.Navigation.PopModalAsync();
            }
            catch (Exception)
            {
                
            }
        }
    }
}
