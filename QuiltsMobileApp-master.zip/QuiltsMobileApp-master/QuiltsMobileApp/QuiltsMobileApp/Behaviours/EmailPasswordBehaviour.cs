﻿using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace QuiltsMobileApp.Behaviours
{
    public class EmailPasswordBehaviour : Behavior<Entry>
    {
        protected override void OnAttachedTo(Entry bindable)
        {
            bindable.TextChanged += PasswordEntryChanged;
            base.OnAttachedTo(bindable);
        }

        private void PasswordEntryChanged(object sender, TextChangedEventArgs e)
        {
            Entry entry = (Entry)sender;
            if (!string.IsNullOrEmpty(entry.Text))
            {
                string pwdRegex = @"^(?=.*\d)(?=.*[a-zA-Z])(?!.*\s).{8,32}$";
                bool isMatched = Regex.IsMatch(entry.Text, pwdRegex);
                if (isMatched)
                {
                    entry.TextColor = Color.Black;
                }
                else
                {
                    entry.TextColor = Color.Black;
                }
            }
        }
        protected override void OnDetachingFrom(Entry bindable)
        {
            bindable.TextChanged -= PasswordEntryChanged;
            base.OnDetachingFrom(bindable);
        }
        public static bool IsValidPassword(string input)
        {

            string pwdRegex = @"^(?=.*\d)(?=.*[a-zA-Z])(?!.*\s).{8,32}$";
            return Regex.IsMatch(input, pwdRegex);
        }

    }
}
