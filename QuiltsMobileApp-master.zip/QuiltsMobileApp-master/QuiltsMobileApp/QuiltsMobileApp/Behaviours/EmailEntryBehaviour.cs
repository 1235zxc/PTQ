﻿using System.Text.RegularExpressions;
using Xamarin.Forms;

namespace QuiltsMobileApp.Behaviours
{
    public class EmailEntryBehaviour : Behavior<Entry>
    {
        protected override void OnAttachedTo(Entry bindable)
        {
            bindable.TextChanged += EmailEntryChanged;
            base.OnAttachedTo(bindable);
        }

        private void EmailEntryChanged(object sender, TextChangedEventArgs e)
        {
            Entry entry = (Entry)sender;
            if (!string.IsNullOrEmpty(entry.Text))
            {
                string emailRegex = @"^((?:[a-zA-Z0-9]+)|(([a-zA-Z0-9]+(\.|\+|\-|_))+[a-zA-Z0-9]+))@(([a-zA-Z0-9]+(\.|\-))+[a-zA-Z\s]{2,})$";
                bool isMatched = Regex.IsMatch(entry.Text, emailRegex);
                if (isMatched)
                {
                    entry.TextColor = Color.Black;
                }
                else
                {
                    entry.TextColor = Color.Black;
                }
            }
        }
        protected override void OnDetachingFrom(Entry bindable)
        {
            bindable.TextChanged -= EmailEntryChanged;
            base.OnDetachingFrom(bindable);
        }
        public static bool IsValidEmailId(string input)
        {
            string emailRegex = @"^((?:[a-zA-Z0-9]+)|(([a-zA-Z0-9]+(\.|\+|\-|_))+[a-zA-Z0-9]+))@(([a-zA-Z0-9]+(\.|\-))+[a-zA-Z\s]{2,})$";
            return Regex.IsMatch(input, emailRegex);
        }
    }
}
