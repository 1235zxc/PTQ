﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Behaviours
{
    public class ComparePasswordBehaviour : Behavior<Entry>
    {

        public static BindableProperty TextProperty = BindableProperty.Create<ComparePasswordBehaviour, string>(tc => tc.Text, string.Empty, BindingMode.TwoWay);
        public string Text
        {
            get
            {
                return (string)GetValue(TextProperty);
            }
            set
            {
                SetValue(TextProperty, value);
            }
        }
        protected override void OnAttachedTo(Entry entry)
        {
            entry.TextChanged += ComparePasswordEntryChanged;
            base.OnAttachedTo(entry);
        }

        private void ComparePasswordEntryChanged(object sender, TextChangedEventArgs e)
        {
            Entry entry = (Entry)sender;
            if (!string.IsNullOrEmpty(Text))
            {
                if (Text.Length >= 8)
                {
                    bool isValid = e.NewTextValue == Text;
                    if (isValid)
                    {
                        entry.TextColor = Color.Black;
                    }
                    else
                    {
                        entry.TextColor = Color.Black;
                    }
                }
                else
                {
                    entry.TextColor = Color.Black;
                }
            }
        }
        protected override void OnDetachingFrom(Entry bindable)
        {
            bindable.TextChanged -= ComparePasswordEntryChanged;
            base.OnDetachingFrom(bindable);
        }

    }
}
