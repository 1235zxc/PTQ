﻿using System.IO;

namespace QuiltsMobileApp.Interfaces
{
    public interface IPrintService
    {
        bool PrintPdfFile(Stream file);
    }
}
