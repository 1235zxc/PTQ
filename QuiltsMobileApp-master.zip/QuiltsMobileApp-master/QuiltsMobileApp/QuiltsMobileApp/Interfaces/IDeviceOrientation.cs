﻿namespace QuiltsMobileApp.Interfaces
{
    public interface IDeviceOrientation
    {
        void EnableRotation();
        void DisableRotation();
    }
}
