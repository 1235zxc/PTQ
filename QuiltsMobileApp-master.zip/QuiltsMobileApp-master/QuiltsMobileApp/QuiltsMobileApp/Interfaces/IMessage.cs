﻿namespace QuiltsMobileApp.Interfaces
{
    public interface IMessage
    {
        void LongAlert(string message);
        void ShortAlert(string message);
        void CustomShowAlert(string message);
        void CustomLongAlert(string message);
        string GetPath();
    }
}
