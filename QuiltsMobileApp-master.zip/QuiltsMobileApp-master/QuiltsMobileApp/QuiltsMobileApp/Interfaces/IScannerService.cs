﻿using System.Threading.Tasks;

namespace QuiltsMobileApp.Interfaces
{
    public interface IScannerService
    {
        Task<string> ScanAsync();
    }
}
