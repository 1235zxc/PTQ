﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace QuiltsMobileApp.Interfaces
{
    public interface ILatestVersionService
    {
        //Task<string> GetLatestVersionNumber();
        Task<bool> IsUsingLatestVersion();
    }
}
