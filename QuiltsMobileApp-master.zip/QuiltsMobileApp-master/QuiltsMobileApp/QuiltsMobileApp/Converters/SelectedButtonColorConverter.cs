﻿using System;
using System.Globalization;
using Xamarin.Forms;

namespace QuiltsMobileApp.Converters
{
    public class SelectedButtonColorConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if ((bool)value)
            {
                {
                    return Color.FromHex("#3D7CCA");
                }
            }
            return Color.FromHex("#AAAAAA");
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
