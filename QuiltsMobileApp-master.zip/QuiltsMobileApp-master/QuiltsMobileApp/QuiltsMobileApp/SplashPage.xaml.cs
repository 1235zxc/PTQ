﻿using Plugin.LatestVersion;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;


namespace QuiltsMobileApp
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SplashPage : ContentPage
    {
        public SplashPage()
        {
            InitializeComponent();
            BindingContext = new SplashPageViewModel();
        }


        protected override async void OnAppearing()
        {
            base.OnAppearing();
            Logo.Opacity = 0;
            await Logo.FadeTo(1, 2000);
            await Task.Delay(1000);

            if (await CheckUpdates())
            {
                if (!string.IsNullOrEmpty(await User_secrets.GetAccessToken()))
                {
                    Application.Current.MainPage = new NavigationPage(new TabbedPage1());
                }
                else
                {
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
            }
        }


        private async Task<bool> CheckUpdates()
        {
            try
            {
                if (Device.RuntimePlatform == Device.Android)
                {
                    var isLatest = await DependencyService.Get<ILatestVersionService>().IsUsingLatestVersion();

                    if (!isLatest)
                    {
                        await PopupNavigation.Instance.PushAsync(new AppUpdatePopUpPage());

                        return false;
                    }
                    else
                    {
                        return true;
                    }

                }
                else
                {
                    var isLatest = await CrossLatestVersion.Current.IsUsingLatestVersion();
                    if (!isLatest)
                    {
                        await PopupNavigation.Instance.PushAsync(new AppUpdatePopUpPage());
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }


            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}