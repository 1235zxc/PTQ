﻿using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Style;
using QuiltsMobileApp.Views;
using System;
using System.Web;
using Xamarin.Essentials;
using Xamarin.Forms;

[assembly: ExportFont("OpenSans-Regular.ttf", Alias = "OpenSansRegular")]
[assembly: ExportFont("OpenSans-Bold.ttf", Alias = "OpenSansBold")]
[assembly: ExportFont("OpenSans-SemiBold.ttf", Alias = "OpenSansSemiBold")]
[assembly: ExportFont("OpenSans-Medium.ttf", Alias = "OpenSansMedium")]
[assembly: ExportFont("OpenSans-Light.ttf", Alias = "OpenSansLight")]
[assembly: ExportFont("OpenSans-Italic.ttf", Alias = "OpenSansItalic")]
[assembly: ExportFont("OpenSans-SemiBoldItalic.ttf", Alias = "OpenSansSemiBoldItalic")]
namespace QuiltsMobileApp
{
    public partial class App : Application
    {
        public IMessage toast;
        const int smallWightResolution = 768;
        const int smallHeightResolution = 1280;
        public App()
        {
            InitializeComponent();
            LoadStyles();
            toast = DependencyService.Get<IMessage>();
        }

        private void LoadStyles()
        {
            if (IsASmallDevice())
            {
                dictionary.MergedDictionaries.Add(SmallDevicesStyle.SharedInstance);
            }
            else
            {
                dictionary.MergedDictionaries.Add(GeneralDevicesStyle.SharedInstance);
            }
        }

        private bool IsASmallDevice()
        {
            var mainDisplayInfo = DeviceDisplay.MainDisplayInfo;

            // Width (in pixels)
            var width = mainDisplayInfo.Width;

            // Height (in pixels)
            var height = mainDisplayInfo.Height;
            return (width <= smallWightResolution && height <= smallHeightResolution);

        }
        protected override void OnStart()
        {
            if (string.IsNullOrEmpty(resetToken) || string.IsNullOrEmpty(userEmail))
            {
                MainPage = new NavigationPage(new SplashPage());
            }
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {

        }
        public string resetToken { get; set; }
        public string userEmail { get; set; }
        protected override void OnAppLinkRequestReceived(Uri uri)
        {
            base.OnAppLinkRequestReceived(uri);
            if (uri.Host.EndsWith("quilttracker-production-frontend.azurewebsites.net", StringComparison.OrdinalIgnoreCase))
            {
                string decodedUrl = HttpUtility.UrlDecode(uri.AbsoluteUri);
                var substrings = decodedUrl.Split(new string[] { "=", "&" }, StringSplitOptions.None);
                var token = substrings[1];
                var email = substrings[3];
                if (uri.Segments != null && uri.Segments.Length == 3)
                {
                    string action = uri.Segments[2];
                    if (action != null && action == "reset-password")
                    {
                        resetToken = token;
                        userEmail = email;
                        MainPage = new NavigationPage(new SetNewPasswordPage(resetToken, userEmail));
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                        MainPage = new NavigationPage(new OnBoardingPage());
                    }
                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                    MainPage = new NavigationPage(new OnBoardingPage());
                }

            }
        }
    }

}

