﻿using System;
using System.Threading.Tasks;
using Xamarin.Essentials;

namespace QuiltsMobileApp.Helpers
{
    public static class User_secrets
    {
        public static int User_Id
        {
            get => Preferences.Get(nameof(User_Id), 0);
            set => Preferences.Set(nameof(User_Id), value);
        }
        public static int? Location_Id
        {
            get => Preferences.Get(nameof(Location_Id), 0);
            set => Preferences.Set(nameof(Location_Id), (int)value);
        }
        public static async void SetAccessToken(string accessToken)
        {
            try
            {
                await SecureStorage.SetAsync("Access_Token", accessToken);
            }
            catch (Exception)
            {

            }
        }
        public static async Task<string> GetAccessToken()
        {
            string accessToken = string.Empty;
            try
            {
                accessToken = await SecureStorage.GetAsync("Access_Token");
            }
            catch (Exception)
            {

            }
            return accessToken;
        }
        public static string User_type
        {
            get => Preferences.Get(nameof(User_type), string.Empty);
            set => Preferences.Set(nameof(User_type), value);
        }
        public static string User_Email
        {
            get => Preferences.Get(nameof(User_Email), string.Empty);
            set => Preferences.Set(nameof(User_Email), value);
        }
        public static string UserFull_Name
        {
            get => Preferences.Get(nameof(UserFull_Name), string.Empty);
            set => Preferences.Set(nameof(UserFull_Name), value);
        }
        public static int? Company_Id
        {
            get => Preferences.Get(nameof(Company_Id), 0);
            set => Preferences.Set(nameof(Company_Id), (int)value);
        }
    }
}
