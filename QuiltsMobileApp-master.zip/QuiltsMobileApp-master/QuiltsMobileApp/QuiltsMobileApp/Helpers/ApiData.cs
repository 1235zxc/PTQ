﻿using Newtonsoft.Json;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.Helpers
{
    public class ApiData : ObservableObjects
    {
        JsonSerializerSettings settings = new JsonSerializerSettings
        {
            NullValueHandling = NullValueHandling.Ignore,
            MissingMemberHandling = MissingMemberHandling.Ignore
        };
        public async Task<PdfDataResponseModel> PostDataPdf(string extURl, object sendData, bool authHeaders = true)
        {
            var result = new PdfDataResponseModel();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURl);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                HttpContent content;
                if (sendData != null)
                {
                    var json = JsonConvert.SerializeObject(sendData);
                    content = new StringContent(json, Encoding.UTF8, "application/json");
                }
                else
                {
                    content = new StringContent(string.Empty);
                }

                var postresult = await client.PostAsync(url, content);
                HttpHeaders headers = postresult.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }
                if (postresult.IsSuccessStatusCode)
                {
                    var response = await postresult.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<PdfDataResponseModel>(response);
                }

                else if (postresult.StatusCode == HttpStatusCode.Unauthorized)
                {
                    result.message = "Session expired!";
                    result.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(result.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (postresult.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    result.message = "Service Unavailable";
                    result.statusCode = 503;
                }
                else if (postresult.StatusCode == HttpStatusCode.InternalServerError)
                {
                    result.message = "Something went wrong. Please try again later.";
                    result.statusCode = 503;
                }
            }
            catch (Exception)
            {

            }
            return result;
        }

        public async Task<ResponseModel<T>> PostData<T>(string extURl, object sendData, bool authHeaders = true)
        {
            ResponseModel<T> data = new ResponseModel<T>();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURl);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                HttpContent content;
                if (sendData != null)
                {
                    var json = JsonConvert.SerializeObject(sendData);
                    content = new StringContent(json, Encoding.UTF8, "application/json");
                }
                else
                {
                    content = new StringContent(string.Empty);
                }

                var result = await client.PostAsync(url, content);
                HttpHeaders headers = result.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    data.message = "Session expired!";
                    data.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(data.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (result.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    data.message = "Service Unavailable";
                    data.statusCode = 503;
                }
                else if (result.StatusCode == HttpStatusCode.InternalServerError)
                {
                    data.message = "Something went wrong. Please try again later.";
                    data.statusCode = 503;
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }
            }
            catch (Exception)
            {
                data = default(ResponseModel<T>);
            }
            return data;
        }

        public async Task<ResponseModelNew<T>> PostDataNew<T>(string extURl, object sendData, bool authHeaders = true)
        {
            ResponseModelNew<T> data = new ResponseModelNew<T>();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURl);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                HttpContent content;
                if (sendData != null)
                {
                    var json = JsonConvert.SerializeObject(sendData);
                    content = new StringContent(json, Encoding.UTF8, "application/json");
                }
                else
                {
                    content = new StringContent(string.Empty);
                }

                var result = await client.PostAsync(url, content);
                HttpHeaders headers = result.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModelNew<T>>(response);
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    data.message = "Session expired!";
                    data.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(data.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (result.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    data.message = "Service Unavailable";
                    data.statusCode = 503;
                }
                else if (result.StatusCode == HttpStatusCode.InternalServerError)
                {
                    data.message = "Something went wrong. Please try again later.";
                    data.statusCode = 503;
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModelNew<T>>(response);
                }
            }
            catch (Exception)
            {
                data = default(ResponseModelNew<T>);
            }
            return data;
        }
        public async Task<ResponseModel<T>> GetData<T>(string extURL, bool authHeaders = true)
        {
            ResponseModel<T> data = new ResponseModel<T>();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURL);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                var result = await client.GetAsync(url);
                HttpHeaders headers = result.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }
                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    data.message = "Session expired!";
                    data.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(data.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (result.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    data.message = "Service Unavailable";
                    data.statusCode = 503;
                }
                else if (result.StatusCode == HttpStatusCode.InternalServerError)
                {
                    data.message = "Something went wrong. Please try again later.";
                    data.statusCode = 500;
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }

            }
            catch (Exception)
            {
                data = default(ResponseModel<T>);
            }
            return data;
        }

        public async Task<ResponseModelNew<T>> GetDataNew<T>(string extURL, bool authHeaders = true)
        {
            ResponseModelNew<T> data = new ResponseModelNew<T>();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURL);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                var result = await client.GetAsync(url);

                HttpHeaders headers = result.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }

                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModelNew<T>>(response);
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    data.message = "Session expired!";
                    data.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(data.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (result.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    data.message = "Service Unavailable";
                    data.statusCode = 503;
                }
                else if (result.StatusCode == HttpStatusCode.InternalServerError)
                {
                    data.message = "Something went wrong. Please try again later.";
                    data.statusCode = 500;
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModelNew<T>>(response);
                }
            }
            catch (Exception ex)
            {
                data = default(ResponseModelNew<T>);
            }
            return data;
        }
        public async Task<ResponseModel<T>> PutData<T>(string extURL, object sendData, bool authHeaders = true)
        {
            ResponseModel<T> data = new ResponseModel<T>();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURL);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                HttpContent content;
                if (sendData != null)
                {
                    var json = JsonConvert.SerializeObject(sendData);
                    content = new StringContent(json, Encoding.UTF8, "application/json");
                }
                else
                {
                    content = new StringContent(string.Empty);
                }

                var result = await client.PutAsync(url, content);

                HttpHeaders headers = result.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }

                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    data.message = "Session expired!";
                    data.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(data.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (result.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    data.message = "Service Unavailable";
                    data.statusCode = 503;
                }
                else if (result.StatusCode == HttpStatusCode.InternalServerError)
                {
                    data.message = "Something went wrong. Please try again later.";
                    data.statusCode = 500;
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }
            }
            catch (Exception)
            {
                data = default(ResponseModel<T>);
            }
            return data;
        }
        public async Task<ResponseModel<T>> DeleteData<T>(string extURL, bool authHeaders = true)
        {
            ResponseModel<T> data = new ResponseModel<T>();
            string url = string.Format("{0}{1}", ApiUrlConstant.BASE_URL, extURL);
            try
            {
                HttpClient client = new HttpClient();
                if (authHeaders)
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", await User_secrets.GetAccessToken());
                var result = await client.DeleteAsync(url);

                HttpHeaders headers = result.Headers;
                IEnumerable<string> values;
                if (headers.TryGetValues("set-authorization", out values))
                {
                    User_secrets.SetAccessToken(values.First());
                }

                if (result.IsSuccessStatusCode)
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }
                else if (result.StatusCode == HttpStatusCode.Unauthorized)
                {
                    data.message = "Session expired!";
                    data.statusCode = 401;
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    toast.ShortAlert(data.message);
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
                else if (result.StatusCode == HttpStatusCode.ServiceUnavailable)
                {
                    data.message = "Service Unavailable";
                    data.statusCode = 503;
                }
                else if (result.StatusCode == HttpStatusCode.InternalServerError)
                {
                    data.message = "Something went wrong. Please try again later.";
                    data.statusCode = 500;
                }
                else
                {
                    var response = await result.Content.ReadAsStringAsync();
                    data = JsonConvert.DeserializeObject<ResponseModel<T>>(response);
                }

            }
            catch (Exception)
            {
                data = default(ResponseModel<T>);
            }
            return data;
        }

    }
}
