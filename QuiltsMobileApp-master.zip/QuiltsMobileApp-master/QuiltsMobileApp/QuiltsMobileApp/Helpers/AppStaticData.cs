﻿namespace QuiltsMobileApp.Helpers
{
    public static class AppStaticData
    {
        public static bool RunMethod { get; set; }
        public static bool IsPallet { get; set; }
        public static bool StatusUpdated { get; set; }

        public static bool IsMockPalletCreated { get; set; }   
        public static string PalletSerialnumber { get; set; } 
    }
}
