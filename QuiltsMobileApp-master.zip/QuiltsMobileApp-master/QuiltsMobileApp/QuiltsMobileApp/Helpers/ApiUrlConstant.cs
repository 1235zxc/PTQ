﻿namespace QuiltsMobileApp.Helpers
{
    public class ApiUrlConstant
    {

        //QA
        //public const string BASE_URL = "https://quilttracker-qa-backend.azurewebsites.net";

        //Development
        public const string BASE_URL = "https://quilttracker-development-backend.azurewebsites.net";

        //Production
        //public const string BASE_URL = "https://quilttracker-production-backend.azurewebsites.net";

    }
}
