﻿
using Xamarin.Forms;

namespace QuiltsMobileApp.Style
{
    public partial class SmallDevicesStyle : ResourceDictionary
    {
        public static SmallDevicesStyle SharedInstance { get; } = new SmallDevicesStyle();

        public SmallDevicesStyle()
        {
            InitializeComponent();
        }
    }
}
