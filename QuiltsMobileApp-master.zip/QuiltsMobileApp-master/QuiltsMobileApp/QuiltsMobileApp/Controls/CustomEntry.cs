﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Controls
{
    public class CustomEntry : Entry
    {
    }
}
