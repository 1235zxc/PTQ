﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Controls
{
    public class CustomSearchBar : SearchBar
    {
        public CustomSearchBar()
        {
        }
    }
}
