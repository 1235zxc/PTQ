﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using ZXing;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class AssignQuiltQRCodePageViewModel : ObservableObjects
    {
        #region Constructor
        public AssignQuiltQRCodePageViewModel(INavigation navigation, OrderOpenResponseModel orderdetails, CustomerListModel customerListModel)
        {

            Navigation = navigation;
            SelectAndClear = "Select All";
            if (orderdetails != null && customerListModel != null)
            {
                OrderDetails = orderdetails;
                CustomerDetails = customerListModel;
            }
        }

        public AssignQuiltQRCodePageViewModel()
        {
            IsUpdatePalletCode = true;
        }

        #endregion

        #region Methods

        public ObservableCollection<PalletQuiltDataResponseModel> qlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public async void AddQuiltPallet(string serialNumber)
        {
            try
            {
                if (IsQuiltAdd && !string.IsNullOrEmpty(serialNumber))
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        string textTrimmed = String.Concat(serialNumber.Where(c => !Char.IsWhiteSpace(c)));
                        List<string> stringlist = textTrimmed.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        var model = new QuiltPalletRequestModel
                        {
                            serialNumbers = stringlist,
                            individualQuiltsOnly = false,
                            customerDetailsRequired = false,
                            individualQuiltPallets = false
                        };
                        var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                        var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);

                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                var listdata = response.data;
                                for (int i = 0; i < listdata.Count; i++)
                                {

                                    bool containsItemP = qlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                    if (containsItemP == false && listdata[i].statusId == 4)

                                    {
                                        if (listdata[i].quilts == null)
                                        {
                                            listdata[i].PlusIconVisibleOrNot = false;

                                        }
                                        else
                                        {
                                            listdata[i].PlusIconVisibleOrNot = true;
                                        }
                                        qlist.Add(listdata[i]);
                                        EnteredQuiltOrPalletSrlNumber = String.Empty;
                                        IsQuiltAdd = false;
                                    }
                                    else
                                    {
                                        if (listdata[i].statusId != 4)
                                        {
                                            toast.LongAlert(listdata[i].serialNumber + "is not On Hand");
                                        }
                                        else
                                        {
                                            toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                        }
                                    }
                                }
                                PalletGetListforAssign = qlist;
                            }
                            else
                            {
                                toast.LongAlert(response.message);
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                        IsBusy = false;
                    }
                    else
                    {
                        toast.ShortAlert("No internet access!");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        }

        #endregion

        #region Properties

        public OrderOpenResponseModel OrderDetails { get; set; }
        public CustomerListModel CustomerDetails { get; set; }
        public INavigation Navigation { get; set; }

        private string _slctOrdrnum;
        public string SelectedOrderNumber
        {
            get { return _slctOrdrnum; }
            set
            {
                _slctOrdrnum = value;
                OnPropertyChanged(nameof(SelectedOrderNumber));
            }
        }

        private bool _isAssignQuilt;
        public bool IsAssignQuilt
        {
            get { return _isAssignQuilt; }
            set
            {
                _isAssignQuilt = value;
                OnPropertyChanged();
            }
        }

        private bool _isQuiltAdd;
        public bool IsQuiltAdd
        {
            get { return _isQuiltAdd; }
            set
            {
                _isQuiltAdd = value;
                OnPropertyChanged();
            }
        }

        private bool _isReprintCode;
        public bool IsReprintCode
        {
            get { return _isReprintCode; }
            set
            {
                _isReprintCode = value;
                OnPropertyChanged();
            }
        }

        private bool _isReprintQRCodePopupIsVisible;
        public bool IsReprintQRCodePopupIsVisible
        {
            get { return _isReprintQRCodePopupIsVisible; }
            set
            {
                _isReprintQRCodePopupIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isUpdatePalletCode;
        public bool IsUpdatePalletCode
        {
            get { return _isUpdatePalletCode; }
            set
            {
                _isUpdatePalletCode = value;
                OnPropertyChanged();
            }
        }

        private bool _isUpdatePalletPopupIsVisible;
        public bool IsUpdatePalletPopupIsVisible
        {
            get { return _isUpdatePalletPopupIsVisible; }
            set
            {
                _isUpdatePalletPopupIsVisible = value;
                OnPropertyChanged();
            }
        }

        private string _entrquiltpalletSrlNumb;
        public string EnteredQuiltOrPalletSrlNumber
        {
            get { return _entrquiltpalletSrlNumb; }
            set
            {
                _entrquiltpalletSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltOrPalletSrlNumber));
            }
        }

        private ObservableCollection<PalletQuiltDataResponseModel> _quiltGetlist;
        public ObservableCollection<PalletQuiltDataResponseModel> QuiltGetListforAssign
        {
            get { return _quiltGetlist; }
            set
            {
                _quiltGetlist = value;
                OnPropertyChanged(nameof(QuiltGetListforAssign));
            }
        }

        private ObservableCollection<PalletQuiltDataResponseModel> _palletGetlist;
        public ObservableCollection<PalletQuiltDataResponseModel> PalletGetListforAssign
        {
            get { return _palletGetlist; }
            set
            {
                _palletGetlist = value;
                OnPropertyChanged(nameof(PalletGetListforAssign));
            }
        }

        private ObservableCollection<QultTypsebyOrderResponse> _quilttyplist;
        public ObservableCollection<QultTypsebyOrderResponse> QuiltTypeListForOrder
        {
            get { return _quilttyplist; }
            set
            {
                _quilttyplist = value;
                OnPropertyChanged(nameof(QuiltTypeListForOrder));
            }
        }

        private Result bcScanResult;
        public Result BcScanResult
        {
            get => bcScanResult;
            set
            {
                bcScanResult = value;
                OnPropertyChanged(nameof(bcScanResult));
            }
        }

        private bool _ischecked;
        public bool IsChecked
        {
            get { return _ischecked; }
            set
            {
                _ischecked = value;
                OnPropertyChanged(nameof(IsChecked));
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private int _qrowHeight;
        public int QListRowHeight
        {
            get { return _qrowHeight; }
            set
            {
                _qrowHeight = value;
                OnPropertyChanged();
            }
        }

        private bool _isScanning;
        public bool IsScanning
        {
            get { return _isScanning; }
            set { _isScanning = value; OnPropertyChanged(); }
        }

        private bool _isScanQRCodeVisible;
        public bool ScannQRCodeVisible
        {
            get { return _isScanQRCodeVisible; }
            set { _isScanQRCodeVisible = value; OnPropertyChanged(); }
        }

        private bool _isAssignEnable;
        public bool IsAssignButtonEnable
        {
            get { return _isAssignEnable; }
            set { _isAssignEnable = value; OnPropertyChanged(); }
        }

        private string _selectAndclr;
        public string SelectAndClear
        {
            get { return _selectAndclr; }
            set { _selectAndclr = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }

        #endregion

        #region Command
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand SelectAllItemsCommand => new Command(() =>
        {
            if (SelectAndClear == "Select All")
            {
                if (PalletGetListforAssign != null && PalletGetListforAssign.Count != 0)
                {
                    for (int i = 0; i < PalletGetListforAssign.Count; i++)
                    {
                        PalletGetListforAssign[i].IsCheckboxChecked = true;
                    }
                    SelectAndClear = "Clear All";
                }
                else
                {
                    toast.LongAlert("Please Add quilts/pallets first");
                }
            }
            else
            {
                if (PalletGetListforAssign != null && PalletGetListforAssign.Count != 0)
                {
                    for (int i = 0; i < PalletGetListforAssign.Count; i++)
                    {
                        PalletGetListforAssign[i].IsCheckboxChecked = false;
                    }
                    SelectAndClear = "Select All";
                }
                else
                {
                    SelectAndClear = "Select All";
                }
            }

        });



        QuiltPalletforAssign quiltPalletforAssign = new QuiltPalletforAssign();
        List<int> listofintegerQuilt = new List<int>();
        List<int> listofintegerPallet = new List<int>();
        public ICommand AssignQuiltCommand => new Command(async () =>
        {
            try
            {
                if (IsAssignQuilt)
                {
                    quiltPalletforAssign.orderNumber = OrderDetails.orderNumber;
                    listofintegerQuilt.Clear();
                    listofintegerPallet.Clear();
                    var list = PalletGetListforAssign;
                    int l = 0;
                    if (list != null && list.Count > 0)
                    {
                        for (int i = 0; i < list.Count; i++)
                        {
                            if (list[i].quilts == null && list[i].IsCheckboxChecked)
                            {
                                listofintegerQuilt.Add(list[i].id);
                                quiltPalletforAssign.quiltIds = listofintegerQuilt;
                            }
                            else if (list[i].quilts != null)
                            {
                                var _allQuiltSelectedfromPallet = true;
                                for (int j = 0; j < list[i].quilts.Count; j++)
                                {
                                    if (list[i].quilts[j].IsCheckboxCheckedNew == false)
                                    {
                                        l++;
                                        _allQuiltSelectedfromPallet = false;
                                    }
                                }
                                if (_allQuiltSelectedfromPallet && list[i].IsCheckboxChecked)
                                {
                                    listofintegerPallet.Add(list[i].id);
                                    quiltPalletforAssign.palletIds = listofintegerPallet;
                                }
                                if (!_allQuiltSelectedfromPallet)
                                {
                                    for (int k = 0; k < list[i].quilts.Count; k++)
                                    {
                                        if (list[i].quilts[k].IsCheckboxCheckedNew)
                                        {
                                            listofintegerPallet.Remove((int)list[i].quilts[k].palletId);
                                            quiltPalletforAssign.palletIds = listofintegerPallet;

                                            listofintegerQuilt.Add(list[i].quilts[k].id);
                                            quiltPalletforAssign.quiltIds = listofintegerQuilt;
                                        }
                                    }
                                }
                            }
                        }
                        if (l > 0 && (quiltPalletforAssign.quiltIds != null || quiltPalletforAssign.palletIds != null))
                        {
                            bool parameter = false;
                            var page = new AssignPalletUpdateWarningPopupPage();
                            page.ActionUpdate += async (sender, boolparameter) =>
                            {
                                parameter = boolparameter;
                            };
                            await PopupNavigation.Instance.PushAsync(page);
                            page.Disappearing += async (c, d) =>
                            {
                                if (parameter)
                                {
                                    await Navigation.PushAsync(new AssignAndSaveQuiltPage(CustomerDetails, OrderDetails, quiltPalletforAssign));
                                }
                            };

                        }
                        else
                        {
                            if (quiltPalletforAssign.quiltIds != null || quiltPalletforAssign.palletIds != null)
                            {
                                if (quiltPalletforAssign.quiltIds == null)
                                {
                                    listofintegerQuilt.DefaultIfEmpty();
                                    quiltPalletforAssign.quiltIds = listofintegerQuilt;
                                }
                                else if (quiltPalletforAssign.palletIds == null)
                                {
                                    listofintegerPallet.DefaultIfEmpty();
                                    quiltPalletforAssign.palletIds = listofintegerPallet;
                                }
                                await Navigation.PushAsync(new AssignAndSaveQuiltPage(CustomerDetails, OrderDetails, quiltPalletforAssign));
                            }
                            else
                            {
                                toast.ShortAlert("Select Quilt or Pallet to assign");
                            }

                        }
                    }
                    else
                    {
                        toast.ShortAlert("Add Quilt/Pallet to assign");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }

        });

        public ICommand AddButtonCommand => new Command(() =>
        {
            AddQuiltPallet(EnteredQuiltOrPalletSrlNumber);
        });
        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    var page = new ScanQRCodePopupPage();
                    page.Action += async (sender, stringparameter) =>
                    {
                        if (!string.IsNullOrEmpty(stringparameter))
                        {
                            EnteredQuiltOrPalletSrlNumber = string.Empty;
                            IsQuiltAdd = true;
                            AddQuiltPallet(stringparameter);
                        }
                        else
                        {
                            IsQuiltAdd = false;
                        }
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        });

        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                }
            }
            return status;
        }

        public ICommand ToggleReprintPopupCommand => new Command(() =>
        {
            IsReprintQRCodePopupIsVisible = false;
        });
        public ICommand ReprintQRCodeCommand => new Command(() =>
        {
            IsReprintCode = true;
            IsReprintQRCodePopupIsVisible = false;
        });


        public ICommand ToggleUpdatePalletPopupCommand => new Command(async () =>
        {
            await PopupNavigation.Instance.PopAsync();
        });
        public ICommand CancelPopupCommand => new Command(async () =>
        {
            await PopupNavigation.Instance.PopAsync();
        });

        #endregion

    }

}

