﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class ReceiveQuiltsPageViewModel : ObservableObjects
    {
        #region Properties

        private bool _isNext;

        public bool IsNext
        {
            get { return _isNext; }
            set
            {
                _isNext = value;
                OnPropertyChanged();
            }
        }
        private string _customerName;
        public string CustomerName
        {
            get { return _customerName; }
            set { _customerName = value; OnPropertyChanged(); }
        }
        private int _customerId;
        public int CustomerId
        {
            get { return _customerId; }
            set { _customerId = value; OnPropertyChanged(); }
        }

        private string _OrderStatus;
        public string OrderStatus
        {
            get { return _OrderStatus; }
            set
            {
                _OrderStatus = value;
                OnPropertyChanged();
            }
        }
        private int _OrderListHeight;
        public int OrderListHeight
        {
            get { return _OrderListHeight; }
            set
            {
                _OrderListHeight = value;
                OnPropertyChanged(nameof(OrderListHeight));
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        public INavigation Navigation { get; set; }
        private ObservableCollection<OrderTypePageModel> _OrderTypesCollection;
        public ObservableCollection<OrderTypePageModel> OrderTypesCollection
        {
            get { return _OrderTypesCollection; }
            set { _OrderTypesCollection = value; OnPropertyChanged(); }
        }
        private bool _OrderTypeListIsVisible;
        public bool OrderTypeListIsVisible
        {
            get { return _OrderTypeListIsVisible; }
            set
            {
                _OrderTypeListIsVisible = value;
                OnPropertyChanged();
            }
        }
        private OrderTypePageModel _OrderType;
        private List<string> receiveQPlist;
        private ObservableCollection<PalletQuiltDataResponseModel> receiveQPModellist;

        public OrderTypePageModel OrderType
        {
            get { return _OrderType; }
            set
            {
                _OrderType = value;
                OnPropertyChanged();
            }
        }
        public int OrderId { get; private set; }
        #endregion

        #region Constructor

        public ReceiveQuiltsPageViewModel(INavigation navigation, List<string> receiveQPlist, ObservableCollection<PalletQuiltDataResponseModel> receiveQPModellist)
        {
            Navigation = navigation;
            this.receiveQPlist = receiveQPlist;
            this.receiveQPModellist = receiveQPModellist;
            foreach (var item in receiveQPModellist)
            {
                CustomerName = item.customerName.ToString();
                OrderStatus = item.orderStatus.ToString();
                CustomerId = Convert.ToInt32(item.customerId);
                OrderId = Convert.ToInt32(item.orderId);
            }
            IsNext = true;
        }

        #endregion

        #region Methods
        public void GetOrderTypes()
        {
            OrderTypesCollection = new ObservableCollection<OrderTypePageModel>();
            OrderTypesCollection.Add(new OrderTypePageModel { id = 1, name = "Open" });
            OrderTypesCollection.Add(new OrderTypePageModel { id = 2, name = "Shipping" });
            OrderTypesCollection.Add(new OrderTypePageModel { id = 3, name = "Close" });
            OrderTypesCollection.Add(new OrderTypePageModel { id = 4, name = "On the way" });
            OrderTypesCollection.Add(new OrderTypePageModel { id = 5, name = "Deleiver" });
            OrderTypesCollection.Add(new OrderTypePageModel { id = 5, name = "Refund" });

            OrderTypeListIsVisible = true;
            var Order = OrderTypesCollection;
            if (Order != null && Order.Count != 0)
            {
                Order.Last().Seperator = false;
                OrderTypesCollection = Order;
                OrderListHeight = OrderTypesCollection.Count * 30;
                if (OrderTypesCollection.Count > 10)
                {
                    OrderListHeight = 70;
                }
            }
            else
            {
                OrderTypesCollection = Order;
                OrderListHeight = 35;
            }
        }
        #endregion

        #region Commands

        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        public ICommand ReceiveCommand => new Command(async () =>
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    var req = new ReceiveQuiltsRequestPageModel
                    {
                        orderId = OrderId,
                        customerId = CustomerId,
                        sendEmail = true,
                        inventories = receiveQPlist,

                    };
                    var QandPurl = "/api/Shipments/ReceiveShipment";
                    var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, req, true);
                    if (response != null)
                    {
                        if (response.statusCode == 200)
                        {
                            toast.LongAlert(response.message);

                            await Navigation.PopToRootAsync();
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.LongAlert(response.message);
                            }
                        }

                    }
                    else
                    {
                        toast.LongAlert("Something went wrong!");
                    }

                }
                catch (Exception ex)
                {

                }

            }
            else
            {
                toast.LongAlert("No internet access!");
            }

            //  await Navigation.PushAsync(new ReceiveQuiltQRCodePage());
        });
        public ICommand SelectOrderTypeCommand => new Command(async (obj) =>
        {
            OrderType = obj as OrderTypePageModel;
            OrderStatus = OrderType.name;
            OrderTypeListIsVisible = false;
        });
        public ICommand SelectOrderTypeTap => new Command(() =>
        {
            GetOrderTypes();
            if (OrderTypesCollection == null)
            {
                OrderTypeListIsVisible = false;
            }
            else
            {
                OrderTypeListIsVisible = true;

            }
        });
        #endregion

    }
}
