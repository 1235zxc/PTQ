﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class ShipQuiltsPageViewModel : ObservableObjects
    {
        #region Properties
        private ObservableCollection<ShipQuiltsPageModel> _shipQuilts;
        public ObservableCollection<ShipQuiltsPageModel> ShipQuilts
        {
            get
            {
                return _shipQuilts;

            }
            set
            {
                _shipQuilts = value;
                OnPropertyChanged();
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        public INavigation Navigation { get; set; }
        private bool _isRefreshing;
        public bool IsRefreshing
        {
            get { return _isRefreshing; }
            set { _isRefreshing = value; OnPropertyChanged(nameof(IsRefreshing)); }
        }

        #endregion

        #region Constructor
        public ShipQuiltsPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            AddQuiltShipsCollection();
        }

        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand GoToShipQuiltQRCodePageCommand => new Command(async (obj) =>
        {
            var type = obj as ShipQuiltsPageModel;
            if (type.quiltsAssigned == 0 || type.quiltsRemainingtoShip == 0)
            {
                var previousPage = Navigation.NavigationStack.LastOrDefault();
                await Navigation.PushAsync(new AssignQuiltsPage(type));
                Navigation.RemovePage(previousPage);
            }
            else
            {
                await Navigation.PushAsync(new ShipQuiltQRCodePage(type.orderNumber));
            }
        });


        public ICommand RefreshCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsRefreshing = true;
                    ShipQuilts = new ObservableCollection<ShipQuiltsPageModel>();
                    var response = await new ApiData().GetDataNew<ShipQuiltsPageModel>("/api/inventory/GetCustomerQuiltDistribution", true);
                    if (response.statusCode == 200 && response != null)
                    {
                        ShipQuilts = response.data;
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }

                }
                else
                {
                    toast.ShortAlert("No internet access!!");
                }
                IsRefreshing = false;
            }
            catch (Exception)
            {

            }
        });
        #endregion


        #region Methods
        private async void AddQuiltShipsCollection()
        {
            IsBusy = true;
            ShipQuilts = new ObservableCollection<ShipQuiltsPageModel>();
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    var response = await new ApiData().GetDataNew<ShipQuiltsPageModel>("/api/inventory/GetCustomerQuiltDistribution", true);
                    if (response != null)
                    {
                        if (response.statusCode == 200 && response.data != null && response.data.Count != 0)
                        {
                            ShipQuilts = response.data;
                        }
                        else if (response.data.Count == 0)
                        {
                            if (response.message != null)
                            {
                                toast.ShortAlert(response.message);
                            }
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.ShortAlert(response.message);
                            }
                        }
                    }
                    else
                    {
                        toast.ShortAlert("things went wrong!");
                    }

                }
                catch (Exception ex)
                {

                }

            }
            else
            {
                toast.ShortAlert("No internet access!");
            }
            IsBusy = false;
        }
        #endregion




    }
}
