﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Extensions;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class QuiltsMaintenancePageViewModel : ObservableObjects
    {
        #region Constructor
        public QuiltsMaintenancePageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            SelectAndClear = "Select All";
            OnStart();
        }


        public QuiltsMaintenancePageViewModel(INavigation navigation, QuiltPalletStatusUpdate quiltPalletStatusUpdate)
        {
            Navigation = navigation;
            this.quiltPalletStatusUpdate = quiltPalletStatusUpdate;
            toast = DependencyService.Get<IMessage>();
            IsUpdateStatusWarningPopUpVisible = false;
        }
        #endregion

        #region Methods
        private async void OnStart()
        {
            await GetStatusList();
        }
        private async Task<String> GetStatusList()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                var response = await new ApiData().GetDataNew<QuiltsMaintenancePageModels>("/api/Generic/quiltstatuses", true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        QuiltPalletStatusList = response.data;

                        ObservableCollection<QuiltsMaintenancePageModels> qpList = new ObservableCollection<QuiltsMaintenancePageModels>(QuiltPalletStatusList);
                        ObservableCollection<QuiltsMaintenancePageModels> qpListss = new ObservableCollection<QuiltsMaintenancePageModels>(QuiltPalletStatusList);
                        foreach (var item in qpListss)
                        {
                            if (item.id == 1 || item.id == 2 || item.id == 3)
                            {
                                qpList.Remove(item);
                            }
                        }
                        QuiltPalletStatusList = qpList;
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                    }

                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                }
            }
            else
            {
                toast.ShortAlert("No internet access!");
            }
            return string.Empty;
        }

        public async void AddQuiltPallet(string serialNumber)
        {
            try
            {
                if (IsQuiltAdd && !string.IsNullOrEmpty(serialNumber))
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        string textTrimmed = String.Concat(serialNumber.Where(c => !Char.IsWhiteSpace(c)));
                        List<string> stringlist = textTrimmed.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        var model = new QuiltPalletRequestModel
                        {
                            serialNumbers = stringlist,
                            individualQuiltsOnly = false,
                            customerDetailsRequired = false,
                            individualQuiltPallets = true
                        };
                        var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                        var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);

                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                var listdata = response.data;
                                for (int i = 0; i < listdata.Count; i++)
                                {
                                    bool containsItemP = QPlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                    if (containsItemP == false)
                                    {
                                        if (listdata[i].statusId == 1 || listdata[i].statusId == 2 || listdata[i].statusId == 3)
                                        {
                                            toast.ShortAlert($"You can not update {listdata[i].serialNumber} status!");
                                        }
                                        else
                                        {
                                            if (listdata[i].quilts == null)
                                            {
                                                listdata[i].PlusIconVisibleOrNot = false;

                                            }
                                            else
                                            {
                                                listdata[i].PlusIconVisibleOrNot = true;
                                            }
                                            QPlist.Add(listdata[i]);
                                            EnteredQuiltOrPalletSrlNumber = String.Empty;
                                            IsQuiltAdd = true;
                                        }
                                    }
                                    else
                                    {
                                        toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                    }
                                }
                                QuiltPalletforUpdate = QPlist;
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                        IsBusy = false;
                    }
                    else
                    {
                        toast.LongAlert("No internet access!");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }

        }
        #endregion

        #region Properties

        public ObservableCollection<PalletQuiltDataResponseModel> QPlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public INavigation Navigation { get; set; }
        public int SelectedStatusId { get; set; }

        private bool _isQuiltMaintenance;
        public bool IsQuiltMaintenance
        {
            get { return _isQuiltMaintenance; }
            set
            {
                _isQuiltMaintenance = value;
                OnPropertyChanged();
            }
        }

        private bool _isQuiltAdd;
        public bool IsQuiltAdd
        {
            get { return _isQuiltAdd; }
            set
            {
                _isQuiltAdd = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private string _lblSerialError;
        public string LblSerialError
        {
            get
            {
                return _lblSerialError;
            }
            set
            {
                _lblSerialError = value;
                OnPropertyChanged();
            }
        }

        private bool _isUpdateStatusEnbl;

        public bool IsUpdateStatusEnable
        {
            get { return _isUpdateStatusEnbl; }
            set { _isUpdateStatusEnbl = value; OnPropertyChanged(); }
        }

        private bool _isUpdateColor;

        public bool IsUpdateColor
        {
            get { return _isUpdateColor; }
            set { _isUpdateColor = value; OnPropertyChanged(); }
        }

        private string _entrquiltpalletSrlNumb;
        public string EnteredQuiltOrPalletSrlNumber
        {
            get { return _entrquiltpalletSrlNumb; }
            set
            {
                _entrquiltpalletSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltOrPalletSrlNumber));
            }
        }


        private ObservableCollection<PalletQuiltDataResponseModel> _quiltpalltlist;

        public ObservableCollection<PalletQuiltDataResponseModel> QuiltPalletforUpdate
        {
            get { return _quiltpalltlist; }
            set
            {
                _quiltpalltlist = value;
                OnPropertyChanged(nameof(QuiltPalletforUpdate));
            }
        }

        private ObservableCollection<QuiltsMaintenancePageModels> _qpStatuslist;
        public ObservableCollection<QuiltsMaintenancePageModels> QuiltPalletStatusList
        {
            get
            {
                return _qpStatuslist;
            }
            set
            {
                _qpStatuslist = value;
                OnPropertyChanged("QuiltPalletStatusList");
            }
        }

        private bool _IsUpdateQuiltMaintenancePopupIsVisible;
        public bool IsUpdateQuiltMaintenancePopupIsVisible
        {
            get { return _IsUpdateQuiltMaintenancePopupIsVisible; }
            set
            {
                _IsUpdateQuiltMaintenancePopupIsVisible = value;
                OnPropertyChanged();
            }
        }

        private string _selectAndclear;

        public string SelectAndClear
        {
            get { return _selectAndclear; }
            set { _selectAndclear = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }

        private bool _updateStatusWarning;

        public bool IsUpdateStatusWarningPopUpVisible
        {
            get { return _updateStatusWarning; }
            set { _updateStatusWarning = value; OnPropertyChanged(); }
        }

        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        QuiltPalletStatusUpdate quiltPalletStatusUpdate = new QuiltPalletStatusUpdate();
        List<string> quiltspalletSrlNumber = new List<string>();
        public ICommand QuiltMaintenanceCommand => new Command(async () =>
        {
            if (QuiltPalletforUpdate != null)
            {
                if (IsQuiltMaintenance)
                {
                    quiltspalletSrlNumber.Clear();
                    var list = QuiltPalletforUpdate;
                    for (int i = 0; i < list.Count; i++)
                    {
                        quiltspalletSrlNumber.Add(list[i].serialNumber);
                    }
                    quiltPalletStatusUpdate.serialNumbers = quiltspalletSrlNumber;

                    var popup = new QMUpdateStatusPopupPage(quiltPalletStatusUpdate, QuiltPalletStatusList);
                    await Navigation.PushPopupAsync(popup);

                    popup.Disappearing += (sender, e) => { this.OnAppearing(); };
                }
            }
        });

        private void OnAppearing()
        {
            if (AppStaticData.StatusUpdated)
            {
                QuiltPalletforUpdate.Clear();
                AppStaticData.StatusUpdated = false;
                EnteredQuiltOrPalletSrlNumber = string.Empty;
                IsQuiltMaintenance = false;
            }
        }

        public ICommand AddButtonCommand => new Command(async () =>
        {
            AddQuiltPallet(EnteredQuiltOrPalletSrlNumber);
        });

        public ICommand UpdateQuiltPalletStatusCommand => new Command(async () =>
        {
            if (IsUpdateColor)
            {
                IsUpdateStatusWarningPopUpVisible = true;
            }
        });

        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    var page = new ScanQRCodePopupPage();
                    page.Action += async (sender, stringparameter) =>
                    {
                        if (!string.IsNullOrEmpty(stringparameter))
                        {
                            EnteredQuiltOrPalletSrlNumber = string.Empty;
                            IsQuiltAdd = true;
                            AddQuiltPallet(stringparameter);
                        }
                        else
                        {
                            IsQuiltAdd = false;
                        }
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }
            }
            catch (Exception)
            {

            }
        });

        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                }
            }
            return status;
        }

        public ICommand SelectAllCommand => new Command(() =>
        {
            if (SelectAndClear == "Select All")
            {
                if (QuiltPalletforUpdate != null && QuiltPalletforUpdate.Count != 0)
                {
                    for (int i = 0; i < QuiltPalletforUpdate.Count; i++)
                    {
                        QuiltPalletforUpdate[i].IsCheckboxChecked = true;
                    }
                    SelectAndClear = "Clear All";
                }
                else
                {
                    toast.LongAlert("Please Add quilts/pallets first");
                }
            }
            else
            {
                if (QuiltPalletforUpdate != null && QuiltPalletforUpdate.Count != 0)
                {
                    for (int i = 0; i < QuiltPalletforUpdate.Count; i++)
                    {
                        QuiltPalletforUpdate[i].IsCheckboxChecked = false;
                    }
                    SelectAndClear = "Select All";
                }
                else
                {
                    SelectAndClear = "Select All";
                }
            }
        });
        public ICommand ToggleUpdateQuiltMaintenancePopupCommand => new Command(async () =>
        {
            await Navigation.PopPopupAsync();
        });


        public ICommand NoUpdateCommand => new Command(async () =>
        {
            IsUpdateStatusWarningPopUpVisible = false;
        });


        public ICommand YesUpdateCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    if (quiltPalletStatusUpdate.serialNumbers.Count > 0)
                    {
                        IsUpdateStatusWarningPopUpVisible = false;
                        quiltPalletStatusUpdate.statusId = SelectedStatusId;
                        var Updationnurl = "/api/inventory/UpdateInventoryStatus";

                        var response = await new ApiData().PostData<UpdatePalletResponse>(Updationnurl, quiltPalletStatusUpdate, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200)
                            {
                                AppStaticData.StatusUpdated = true;
                                IsUpdateColor = false;
                                await Navigation.PopPopupAsync();
                                toast.ShortAlert(response.message);
                            }
                            else
                            {
                                IsUpdateColor = false;
                                await Navigation.PopPopupAsync();
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                        else
                        {
                            IsUpdateColor = false;
                            await Navigation.PopPopupAsync();
                            toast.ShortAlert("Something went wrong!");
                        }


                    }

                }
                else
                {
                    toast.LongAlert("No internet access!");
                }

            }
            catch (Exception)
            {

            }
        });
        #endregion
    }
}
