﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class EditProfileViewModel : ObservableObjects
    {
        #region Contructor
        public EditProfileViewModel(INavigation navigation)
        {
            Navigation = navigation;
            AppStaticData.RunMethod = false;
            UserType = User_secrets.User_type;
            CompanyId = (int)User_secrets.Company_Id;
            if (CompanyId != 0)
            {
                GetAllLocations(CompanyId);
            }
            GetUserType();
        }

        #endregion


        #region Methods

        private void GetUserType()
        {
            if (UserType == "Master Admin")
            {
                IsLocationEnrtyVisible = false;
            }
            else if (UserType == "Company Admin")
            {
                IsLocationEnrtyVisible = true;
                IsLocationChangeEnable = true;
                IsChangeBorderColor = true;
            }
            else if (UserType == "Location User")
            {
                IsLocationEnrtyVisible = true;
                IsLocationChangeEnable = false;
                IsChangeBorderColor = false;
            }
        }
        public async void GetAllLocations(int companyid)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                var response = await new ApiData().GetDataNew<LocationListModel>("/api/Locations/GetLocationsByCustomerId/" + companyid, true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        var locationLists = response.data;
                        locationLists.Last().Seperator = false;
                        LocationList = locationLists;
                        LocationListHeight = LocationList.Count * 40;
                        if (LocationList.Count > 10)
                        {
                            LocationListHeight = 400;
                        }
                    }
                    else
                    {
                        toast.LongAlert(response.message);
                    }
                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                }
            }
            else
            {
                toast.ShortAlert("No internet access!!");
            }
        }

        internal void IsAllEntriesFilled()
        {
            if (!string.IsNullOrEmpty(UserFirstName) && !string.IsNullOrEmpty(UserPhoneNumber) && !string.IsNullOrEmpty(UserLastName))
            {
                if (IsPhoneValid)
                {
                    IsProfileUpdate = true;
                }
                else
                {
                    IsProfileUpdate = false;
                }
            }
            else
            {
                IsProfileUpdate = false;
            }
        }
        #endregion

        #region Properties
        private bool _isUpdate;
        public bool IsProfileUpdate
        {
            get
            {
                return _isUpdate;
            }
            set
            {
                _isUpdate = value;
                OnPropertyChanged();
            }
        }
        private bool isBusy;

        public bool IsBusy
        {
            get { return isBusy; }
            set { isBusy = value; OnPropertyChanged(); }
        }


        private bool _ischngBrdrClr;

        public bool IsChangeBorderColor
        {
            get { return _ischngBrdrClr; }
            set
            {
                _ischngBrdrClr = value;
                OnPropertyChanged();
            }
        }

        private bool _isLocationEnrtyVisible;
        public bool IsLocationEnrtyVisible
        {
            get
            {
                return _isLocationEnrtyVisible;
            }
            set
            {
                _isLocationEnrtyVisible = value;
            }
        }

        private bool _locListvsbl;

        public bool LocationListVisible
        {
            get { return _locListvsbl; }
            set
            {
                _locListvsbl = value;
                OnPropertyChanged(nameof(LocationListVisible));
            }
        }

        private bool _isLocenbl;

        public bool IsLocationChangeEnable
        {
            get { return _isLocenbl; }
            set
            {
                _isLocenbl = value;
                OnPropertyChanged(nameof(IsLocationChangeEnable));
            }
        }


        private string _userfirstname;
        public string UserFirstName
        {
            get
            {
                return _userfirstname;
            }
            set
            {
                _userfirstname = value;
                OnPropertyChanged(nameof(UserFirstName));
            }
        }
        private string _userlastname;
        public string UserLastName
        {
            get
            {
                return _userlastname;
            }
            set
            {
                _userlastname = value;
                OnPropertyChanged(nameof(UserLastName));
            }
        }
        private string _email;
        public string email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
                OnPropertyChanged();
            }
        }
        private string _location;
        public string location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
                OnPropertyChanged();
            }
        }

        private string _userphoneNumber;
        public string UserPhoneNumber
        {
            get
            {
                return _userphoneNumber;
            }
            set
            {
                _userphoneNumber = value;
                OnPropertyChanged(nameof(UserPhoneNumber));
            }
        }

        private int _locationid;
        public int locationId
        {
            get
            {
                return _locationid;
            }
            set
            {
                _locationid = value;
                OnPropertyChanged();
            }
        }

        private string _userType;
        public string UserType
        {
            get
            {
                return _userType;
            }
            set
            {
                _userType = value;
                OnPropertyChanged();
            }
        }

        private int _companyId;

        public int CompanyId
        {
            get { return _companyId; }
            set
            {
                _companyId = value;
                OnPropertyChanged(nameof(CompanyId));
            }
        }

        private int _locId;

        public int locationID
        {
            get { return _locId; }
            set
            {
                _locId = value;
                OnPropertyChanged(nameof(locationID));
            }
        }


        private ObservableCollection<LocationListModel> _locList;

        public ObservableCollection<LocationListModel> LocationList
        {
            get { return _locList; }
            set
            {
                _locList = value;
                OnPropertyChanged(nameof(LocationList));
            }
        }

        private bool _phoneValid;

        public bool IsPhoneValid
        {
            get { return _phoneValid; }
            set
            {
                _phoneValid = value;
                OnPropertyChanged();
            }
        }

        private int _loclistHeight;
        public int LocationListHeight
        {
            get { return _loclistHeight; }
            set
            {
                _loclistHeight = value;
                OnPropertyChanged(nameof(LocationListHeight));
            }
        }


        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand ChangeLocationCommand => new Command(() =>
        {
            if (LocationList != null)
            {
                LocationListVisible = !LocationListVisible;
            }

        });
        public ICommand TogglePopupCommand => new Command(() =>
        {
            LocationListVisible = false;
        });
        public ICommand SelectLocationCommand => new Command((obj) =>
        {
            var item = obj as LocationListModel;
            location = item.name;
            locationID = item.id;
            LocationListVisible = false;
        });
        public ICommand SaveEditProfileCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    if (!string.IsNullOrEmpty(UserFirstName) && !string.IsNullOrEmpty(UserLastName)
                        && !string.IsNullOrEmpty(email) && !string.IsNullOrEmpty(UserPhoneNumber) && IsProfileUpdate)
                    {
                        var userid = User_secrets.User_Id;
                        locationId = (int)User_secrets.Location_Id;
                        var model = new EditProfileRequestModel
                        {
                            id = userid,
                            firstName = UserFirstName,
                            lastName = UserLastName,
                            phoneNumber = UserPhoneNumber,
                            locationId = locationID
                        };
                        var response = await new ApiData().PostData<EditProfileResponseModel>("/api/User/profile", model, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                AppStaticData.RunMethod = true;
                                User_secrets.UserFull_Name = $"{UserFirstName} {UserLastName}";
                                await Navigation.PopAsync();
                                toast.ShortAlert(response.message);
                            }
                            else
                            {
                                toast.LongAlert(response.message);
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!!");
                }
            }
            catch (Exception)
            {

            }
        });
        #endregion


        public INavigation Navigation { get; set; }
    }
}
