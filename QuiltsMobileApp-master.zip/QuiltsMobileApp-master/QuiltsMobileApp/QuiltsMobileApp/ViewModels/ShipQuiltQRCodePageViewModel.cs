﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class ShipQuiltQRCodePageViewModel : ObservableObjects
    {

        #region Constructor
        public ShipQuiltQRCodePageViewModel(INavigation navigation, string orderNumber)
        {
            Navigation = navigation;
            if (!string.IsNullOrEmpty(orderNumber))
            {
                CreateCollection(orderNumber);
            }
            OrderNumber = orderNumber;

        }
        #endregion

        #region Properties
        private bool _IsScanQRCodePopupIsVisible;
        public bool IsScanQRCodePopupIsVisible
        {
            get
            {
                return _IsScanQRCodePopupIsVisible;

            }
            set
            {
                _IsScanQRCodePopupIsVisible = value;
                OnPropertyChanged();
            }
        }
        private bool _IsShipQuilt;
        public bool IsShipQuilt
        {
            get { return _IsShipQuilt; }
            set
            {
                _IsShipQuilt = value;
                OnPropertyChanged();
            }
        }
        private bool _isScan;
        public bool IsScanQRCode
        {
            get { return _isScan; }
            set
            {
                _isScan = value;
                OnPropertyChanged();
            }
        }
        private bool _isQuiltAdd;
        public bool IsQuiltAdd
        {
            get { return _isQuiltAdd; }
            set
            {
                _isQuiltAdd = value;
                OnPropertyChanged();
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        private ShipQuiltsPageModel _ShipQuilts;
        public ShipQuiltsPageModel ShipQuilts
        {
            get { return _ShipQuilts; }
            set { _ShipQuilts = value; OnPropertyChanged(nameof(ShipQuilts)); }
        }
        private ObservableCollection<ShipQuiltQRCodePageModel> _getShipQuiltsCollection;
        public ObservableCollection<ShipQuiltQRCodePageModel> GetShipQuiltsCollection
        {
            get { return _getShipQuiltsCollection; }
            set { _getShipQuiltsCollection = value; OnPropertyChanged(); }
        }
        private string _orderNumber;
        public string OrderNumber
        {
            get
            {
                return _orderNumber;
            }
            set
            {
                _orderNumber = value;
                OnPropertyChanged();
            }
        }
        public INavigation Navigation { get; set; }

        private bool _isSelect;
        public bool IsSelect
        {
            get { return _isSelect; }
            set
            {
                _isSelect = value;
                OnPropertyChanged();
            }
        }
        private string _selectAndclear = "Select All";

        public string SelectAndClear
        {
            get { return _selectAndclear; }
            set { _selectAndclear = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }
        public List<string> ShipQPlist = new List<string>();
        public ObservableCollection<ShipQuiltQRCodePageModel> QSlist = new ObservableCollection<ShipQuiltQRCodePageModel>();

        #endregion

        #region Methods
        private async void CreateCollection(string orderNumber)
        {
            IsBusy = true;
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    OrderNumber = orderNumber;
                    var url = "/api/Quilts/GetPalletandQuiltdetailsByOrderNumber?orderNumber=" + OrderNumber;
                    var response = await new ApiData().GetDataNew<ShipQuiltQRCodePageModel>(url, true);
                    if (response != null)
                    {
                        if (response.statusCode == 200 && response.data != null)
                        {
                            //  GetShipQuiltsCollection = response.data;
                            var listdata = response.data;
                            for (int i = 0; i < listdata.Count; i++)
                            {
                                if (listdata[i].quilts == null)
                                {
                                    listdata[i].PlusIconVisibleOrNot = false;

                                }
                                else
                                {
                                    listdata[i].PlusIconVisibleOrNot = true;
                                }
                                QSlist.Add(listdata[i]);

                            }
                            GetShipQuiltsCollection = QSlist;
                            IsScanQRCode = true;
                            IsSelect = true;
                        }
                        else if (response.data == null || response.data.Count == 0)
                        {
                            if (response.message != null)
                            {
                                toast.ShortAlert(response.message);
                            }
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.ShortAlert(response.message);
                            }
                        }
                    }
                    else
                    {
                        toast.ShortAlert("things went wrong!");
                    }

                }
                catch (Exception ex)
                {

                }

            }
            else
            {
                toast.ShortAlert("No internet access!");
            }
            IsBusy = false;
        }

        private async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        var popUppage = new AccessWarningPopupPage();
                        await PopupNavigation.Instance.PushAsync(popUppage);
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                }
            }
            return status;

        }

        #endregion

        #region Commands
        public ICommand GotoShipQuiltDetailPageCommand => new Command(async () =>
        {
            if (IsShipQuilt)
            {
                ShipQPlist.Clear();
                for (int i = 0; i < GetShipQuiltsCollection.Count; i++)
                {
                    if (GetShipQuiltsCollection[i].IsCheckboxChecked)
                    {
                        ShipQPlist.Add(GetShipQuiltsCollection[i].serialNumber);
                    }
                }
                await Navigation.PushAsync(new ShipQuiltDetailPage(ShipQPlist, OrderNumber));
            }
        });

        public ICommand AddButtonCommand => new Command(() =>
        {
            IsQuiltAdd = true;
        });



        public ICommand BackButtonCommand => new Command(async () =>
        {

            await Navigation.PopAsync();
        });
        public ICommand ToggleScanQRCodePopupCommand => new Command(() =>
        {
            IsScanQRCodePopupIsVisible = false;
        });
        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            // IsScanQRCodePopupIsVisible = true;
            if (IsScanQRCode)
            {
                try
                {
                    string param = String.Empty;
                    var page = new ScanQRCodePopupPage();

                    var permissions = await CheckAndRequestCameraPermission();
                    if (permissions == PermissionStatus.Granted)
                    {
                        page.Action += async (sender, stringparameter) =>
                        {
                            param = stringparameter;
                        };
                        await PopupNavigation.Instance.PushAsync(page);
                    }

                    page.Disappearing += (c, d) =>
                    {
                        if (!string.IsNullOrEmpty(param))
                        {
                            IsQuiltAdd = true;
                            bool containsItemP = QSlist.Any(item => item.serialNumber.ToLower().Contains(param.ToLower()));
                            if (containsItemP)
                            {
                                try
                                {
                                    var res = QSlist.Where(x => x.serialNumber.ToLower().Contains(param.ToLower())).ToList();
                                    res[0].IsCheckboxChecked = true;

                                    QSlist = new ObservableCollection<ShipQuiltQRCodePageModel>(QSlist.OrderByDescending(i => i.IsCheckboxChecked));
                                    GetShipQuiltsCollection = QSlist;


                                }
                                catch (Exception ex)
                                {

                                }

                            }
                            else
                            {
                                toast.LongAlert("Scanned Quilt is not in the list");
                            }
                        }
                        else
                        {
                            IsQuiltAdd = false;
                        }
                    };
                }
                catch (Exception)
                {
                    toast.ShortAlert("Things went wrong!");
                }

            }

        });
        public ICommand SelectAllCommand => new Command(() =>
        {
            if (IsSelect)
            {
                if (SelectAndClear == "Select All")
                {
                    if (GetShipQuiltsCollection != null && GetShipQuiltsCollection.Count != 0)
                    {
                        for (int i = 0; i < GetShipQuiltsCollection.Count; i++)
                        {
                            GetShipQuiltsCollection[i].IsCheckboxChecked = true;
                        }
                        SelectAndClear = "Clear All";
                    }
                    else
                    {
                        toast.LongAlert("No quilts/pallets first");
                    }
                }
                else
                {
                    if (GetShipQuiltsCollection != null && GetShipQuiltsCollection.Count != 0)
                    {
                        for (int i = 0; i < GetShipQuiltsCollection.Count; i++)
                        {
                            GetShipQuiltsCollection[i].IsCheckboxChecked = false;
                        }
                        SelectAndClear = "Select All";
                    }
                    else
                    {
                        SelectAndClear = "Select All";
                    }
                }
            }
        });
        #endregion


    }
}
