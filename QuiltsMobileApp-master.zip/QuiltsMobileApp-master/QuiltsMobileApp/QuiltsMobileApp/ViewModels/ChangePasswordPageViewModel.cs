﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class ChangePasswordPageViewModel : ObservableObjects
    {
        #region Contructor
        public ChangePasswordPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            IsOldPasswordVisible = true;
            IsNewPasswordVisible = true;
            IsCfmPasswordVisible = true;
        }
        #endregion

        #region Properties
        private string _imageOldPassVisible = "Eye.png";
        public string ImageOldPassVisible
        {
            get { return _imageOldPassVisible; }
            set { _imageOldPassVisible = value; OnPropertyChanged(); }
        }
        private string _imageNewPassVisible = "Eye.png";
        public string ImageNewPassVisible
        {
            get { return _imageNewPassVisible; }
            set { _imageNewPassVisible = value; OnPropertyChanged(); }
        }
        private string _imageCfmPassVisible = "Eye.png";
        public string ImageCfmPassVisible
        {
            get { return _imageCfmPassVisible; }
            set { _imageCfmPassVisible = value; OnPropertyChanged(); }
        }
        private bool _isSetOldPassword;
        public bool IsSetOldPassword
        {
            get { return _isSetOldPassword; }
            set
            {
                _isSetOldPassword = value;
                OnPropertyChanged();
            }
        }
        private bool _isSetNewPassword;
        public bool SaveButtonBackgroundColorChange
        {
            get { return _isSetNewPassword; }
            set
            {
                _isSetNewPassword = value;
                OnPropertyChanged();
            }
        }

        private bool _isOldPasswordVisible = false;
        public bool IsOldPasswordVisible
        {
            get { return _isOldPasswordVisible; }
            set { _isOldPasswordVisible = value; OnPropertyChanged(); }
        }
        private bool _isNewPasswordVisible = false;
        public bool IsNewPasswordVisible
        {
            get { return _isNewPasswordVisible; }
            set { _isNewPasswordVisible = value; OnPropertyChanged(); }
        }
        private bool _isCfmPasswordVisible = false;
        public bool IsCfmPasswordVisible
        {
            get { return _isCfmPasswordVisible; }
            set { _isCfmPasswordVisible = value; OnPropertyChanged(); }
        }
        private bool _ispassValid;
        public bool IsPasswordValid
        {
            get { return _ispassValid; }
            set { _ispassValid = value; OnPropertyChanged(nameof(IsPasswordValid)); }
        }
        private string _oldPassword;

        public string OldPassword
        {
            get { return _oldPassword; }
            set
            {
                _oldPassword = value;
                OnPropertyChanged();
            }
        }
        private bool _Oldpassfrmbrdrclr;

        public bool OldPasswordFrameBorderColor
        {
            get { return _Oldpassfrmbrdrclr; }
            set { _Oldpassfrmbrdrclr = value; OnPropertyChanged(); }
        }
        private string _lblOldPasswordError;
        public string LblOldPasswordError
        {
            get
            {
                return _lblOldPasswordError;
            }
            set
            {
                _lblOldPasswordError = value;
                OnPropertyChanged();
            }
        }
        private string _lblNewPasswordError;
        public string LblNewPasswordError
        {
            get
            {
                return _lblNewPasswordError;
            }
            set
            {
                _lblNewPasswordError = value;
                OnPropertyChanged();
            }
        }
        private string _lblCfmPasswordError;
        public string LblCfmPasswordError
        {
            get
            {
                return _lblCfmPasswordError;
            }
            set
            {
                _lblCfmPasswordError = value;
                OnPropertyChanged();
            }
        }

        private string _nNewPassword;

        public string NewPassword
        {
            get { return _nNewPassword; }
            set
            {
                _nNewPassword = value;
                OnPropertyChanged();
            }
        }
        private bool _Newpassfrmbrdrclr;

        public bool NewPasswordFrameBorderColor
        {
            get { return _Newpassfrmbrdrclr; }
            set { _Newpassfrmbrdrclr = value; OnPropertyChanged(); }
        }

        private string _confrmNewPassword;

        public string ConfrmNewPassword
        {
            get { return _confrmNewPassword; }
            set
            {
                _confrmNewPassword = value;
                OnPropertyChanged();
            }
        }
        private bool _Conpassfrmbrdrclr;

        public bool ConPasswordFrameBorderColor
        {
            get { return _Conpassfrmbrdrclr; }
            set { _Conpassfrmbrdrclr = value; OnPropertyChanged(); }
        }

        private bool _savePassEnbl;

        public bool SaveButtonEnabled
        {
            get { return _savePassEnbl; }
            set
            {
                _savePassEnbl = value;
                OnPropertyChanged(nameof(SaveButtonEnabled));
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        private bool _isChangePass;
        public bool IsChangePassWord
        {
            get
            {
                return _isChangePass;
            }
            set
            {
                _isChangePass = value;
                OnPropertyChanged();

            }
        }
        internal void IsAllEntriesFilled()
        {
            if (!string.IsNullOrEmpty(OldPassword) && !string.IsNullOrEmpty(NewPassword) && !string.IsNullOrEmpty(ConfrmNewPassword))
            {
                if (IsPasswordValid && IsConfirmPassValid && IsOldPassWordValid)
                {
                    IsChangePassWord = true;
                }
                else
                {
                    IsChangePassWord = false;
                }
            }
            else
            {
                IsChangePassWord = false;
            }
        }

        private bool _isSetNewvvalid;

        public bool IsConfirmPassValid
        {
            get { return _isSetNewvvalid; }
            set { _isSetNewvvalid = value; OnPropertyChanged(nameof(IsConfirmPassValid)); }
        }

        private bool _isoldpaasvalid;

        public bool IsOldPassWordValid
        {
            get { return _isoldpaasvalid; }
            set { _isoldpaasvalid = value; OnPropertyChanged(nameof(IsOldPassWordValid)); }
        }

        #endregion

        #region Commands
        public ICommand ConfirmPasswordShowHideCommand => new Command(() =>
        {

            if (IsCfmPasswordVisible)
            {
                IsCfmPasswordVisible = false;
                ImageCfmPassVisible = "Hide.png";

            }
            else
            {
                IsCfmPasswordVisible = true;
                ImageCfmPassVisible = "Eye.png";
            }
        });
        public ICommand NewPasswordShowHideCommand => new Command(() =>
        {
            if (IsNewPasswordVisible)
            {
                IsNewPasswordVisible = false;
                ImageNewPassVisible = "Hide.png";
            }
            else
            {
                IsNewPasswordVisible = true;
                ImageNewPassVisible = "Eye.png";
            }

        });
        public ICommand OldPasswordShowHideCommand => new Command(() =>
        {
            if (IsOldPasswordVisible)
            {
                IsOldPasswordVisible = false;
                ImageOldPassVisible = "Hide.png";
            }
            else
            {
                IsOldPasswordVisible = true;
                ImageOldPassVisible = "Eye.png";
            }

        });
        public ICommand UpdatePasswordCommand => new Command(async () =>
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                if (IsOldPassWordValid && IsPasswordValid == IsConfirmPassValid && IsChangePassWord)
                {
                    var model = new PasswordUpdateRequestModel
                    {
                        currentPassword = OldPassword,
                        newPassword = NewPassword
                    };
                    var response = await new ApiData().PostData<PasswordUpdateResponseModel>("/api/change-password", model, true);
                    if (response != null)
                    {
                        if (response.statusCode == 200)
                        {
                            toast.ShortAlert(response.message);
                            Preferences.Clear();
                            Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                        }
                        else
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                }
                IsBusy = false;
            }
            else
            {
                toast.LongAlert("No internet access!!");
            }
        });
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        #endregion

        public INavigation Navigation { get; set; }
    }
}
