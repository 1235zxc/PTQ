﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class PalletDetailsPageViewModel : ObservableObjects
    {
        #region Constructor
        public PalletDetailsPageViewModel(INavigation navigation, int palletId)
        {
            Navigation = navigation;
            if (palletId != 0)
            {
                GetEditPalletDetails(palletId);
            }
        }
        #endregion

        #region Methods
        public async void GetEditPalletDetails(int palletId)
        {
            IsBusy = true;
            IsEditPopupupVisible = false;

            PalletCollection = new ObservableCollection<PalletDetailListModel>();
            var response = await new ApiData().GetData<PalletDetailListModel>("/api/Pallets/" + palletId, true);
            if (response != null)
            {
                if (response.statusCode == 200 && response.data != null)
                {
                    var palletlist = response.data;
                    if (string.IsNullOrEmpty(palletlist.description))
                    {
                        palletlist.description = "NA";
                    }
                    PalletList = palletlist;
                    QuiltCollection = response.data.quilts;
                }
                else
                {
                    if (response.message != null)
                    {
                        toast.LongAlert(response.message);
                    }
                }
            }
            else
            {
                toast.ShortAlert("Something went wrong!");
            }
            IsBusy = false;
        }

        #endregion

        #region Properties
        public INavigation Navigation { get; set; }

        private bool _isEditPopupVisible;
        public bool IsEditPopupupVisible
        {
            get
            {
                return _isEditPopupVisible;
            }
            set
            {
                _isEditPopupVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isPrintQRCode;
        public bool IsPrintQRCode
        {
            get
            {
                return _isPrintQRCode;
            }
            set
            {
                _isPrintQRCode = value;
                OnPropertyChanged();
            }
        }

        private int _palletsId;
        public int PalletID
        {
            get
            {
                return _palletsId;
            }
            set
            {
                _palletsId = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<PalletDetailListModel> _palletCollection;
        public ObservableCollection<PalletDetailListModel> PalletCollection
        {
            get
            {
                return _palletCollection;

            }
            set
            {
                _palletCollection = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<QuiltDetailListModel> _quiltCollection;
        public ObservableCollection<QuiltDetailListModel> QuiltCollection
        {
            get
            {
                return _quiltCollection;

            }
            set
            {
                _quiltCollection = value;
                OnPropertyChanged();
            }
        }

        private PalletDetailListModel _palletList;
        public PalletDetailListModel PalletList
        {
            get
            {
                return _palletList;

            }
            set
            {
                _palletList = value;
                OnPropertyChanged();
            }
        }

        private bool _isShowPdf;

        public bool IsVisibleShowpdf
        {
            get { return _isShowPdf; }
            set { _isShowPdf = value; OnPropertyChanged(); }
        }

        private string _path;

        public string FilePath
        {
            get { return _path; }
            set { _path = value; OnPropertyChanged(); }
        }

        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();


        });
        public ICommand TogglePopupCommand => new Command(() =>
        {
            IsEditPopupupVisible = false;
        });

        public ICommand EditPalletThreeDotCommand => new Command(() =>
        {
            IsEditPopupupVisible = !IsEditPopupupVisible;
        });
        public ICommand GoToEditPalletPageCommand => new Command(async () =>
        {
            IsEditPopupupVisible = false;
            if (PalletList != null && PalletList.id != 0)
            {
                await Navigation.PushAsync(new EditPalletPage(PalletList.id));
            }
        });
        public ICommand GoToAddMergePalletPageCommand => new Command(async () =>
        {
            IsEditPopupupVisible = false;
            if (PalletList != null)
            {
                await Navigation.PushAsync(new AddMergePage(PalletList));
            }
        });
        public ICommand DeletePopupCommand => new Command(async () =>
        {
            try
            {
                IsBusy = true;
                IsEditPopupupVisible = false;
                var response = await new ApiData().DeleteData<PalletDetailListModel>("/api/Pallets/" + PalletList.id, true);
                if (response != null)
                {
                    if (response.statusCode == 200)
                    {
                        AppStaticData.IsPallet = true;
                        toast.ShortAlert(response.message);
                        await Navigation.PopAsync();
                    }
                    else
                    {
                        toast.LongAlert(response.message);
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                }
            }
            catch (Exception)
            {

            }
        });

        List<string> strings = new List<string>();
        public ICommand PrintQRCodeCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    strings.Add(PalletList.serialNumber);
                    var url = "/api/Codes/GenratePalletQRCodesPdf";
                    var response = await new ApiData().PostDataPdf(url, strings, true);
                    if (response != null)
                    {
                        if (response.data != null)
                        {
                            var result = response.data;
                            var bytes = Convert.FromBase64String(result);

                            Stream stream = new MemoryStream(bytes);

                            DependencyService.Get<IPrintService>().PrintPdfFile(stream);
                        }
                        else
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!!");
                }
            }
            catch (Exception)
            {
                IsBusy = false;
            }
            strings.Clear();
        });

        #endregion
    }
}
