﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class CAorLUCreatePalletPageViewModel : ObservableObjects
    {
        #region Constructor
        public CAorLUCreatePalletPageViewModel(Xamarin.Forms.INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion

        #region Methods

        public ObservableCollection<PalletQuiltDataResponseModel> qlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public async void AddQuiltPallet(string serialNumber)
        {
            if (IsQuiltsAdd && !string.IsNullOrEmpty(serialNumber))
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    string textTrimmed = String.Concat(serialNumber.Where(c => !Char.IsWhiteSpace(c)));
                    List<string> stringlist = textTrimmed.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    var model = new QuiltPalletRequestModel
                    {
                        serialNumbers = stringlist,
                        individualQuiltsOnly = true,
                        customerDetailsRequired = false,
                        individualQuiltPallets = false
                    };
                    var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                    var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);
                    if (response != null)
                    {
                        var listdata = response.data;
                        StackIsVisible = false;

                        if (response.statusCode == 200 && response.data != null)
                        {
                            for (int i = 0; i < listdata.Count; i++)
                            {
                                bool containsItemP = qlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                if (containsItemP == false)
                                {
                                    qlist.Add(listdata[i]);

                                }
                                else
                                {
                                    toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                }
                            }
                            QuiltListForCreate = qlist;
                            EnteredQuiltSrlNumber = string.Empty;
                            IsQuiltsAdd = false;
                        }
                        else
                        {

                            toast.LongAlert(response.message);

                        }

                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }

        }
        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        var popUppage = new AccessWarningPopupPage();
                        await PopupNavigation.Instance.PushAsync(popUppage);
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                }
            }
            return status;
        }

        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        public int palletstatusid { get; set; }
        public int masterQuiltTypeId { get; set; }

        private bool _isCreatePalletButtonColorVisible;
        public bool IsCreatePallet
        {
            get
            {
                return _isCreatePalletButtonColorVisible;
            }
            set
            {
                _isCreatePalletButtonColorVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isquiltsAdd;
        public bool IsQuiltsAdd
        {
            get
            {
                return _isquiltsAdd;
            }
            set
            {
                _isquiltsAdd = value;
                OnPropertyChanged();
            }
        }

        private bool _isAnotherPalletAdd;
        public bool IsAnotherPalletAdd
        {
            get
            {
                return _isAnotherPalletAdd;
            }
            set
            {
                _isAnotherPalletAdd = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }


        private string _entrquiltSrlNumb;
        public string EnteredQuiltSrlNumber
        {
            get { return _entrquiltSrlNumb; }
            set
            {
                _entrquiltSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltSrlNumber));
            }
        }

        private ObservableCollection<CreatePalletPageModel> _createPallets;
        public ObservableCollection<CreatePalletPageModel> CreatePallets
        {
            get
            {
                return _createPallets;
            }
            set
            {
                _createPallets = value;
                OnPropertyChanged();
            }
        }

        private string _description = String.Empty;
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
                OnPropertyChanged();
            }
        }

        private string _checkBoxImages = "Deselected.png";
        public string CheckBoxImages
        {
            get
            {
                return _checkBoxImages;
            }
            set
            {
                _checkBoxImages = value;
                OnPropertyChanged();
            }

        }

        private bool _IsSearchNotFoundIsVisible;
        public bool IsSearchNotFoundIsVisible
        {
            get { return _IsSearchNotFoundIsVisible; }
            set { _IsSearchNotFoundIsVisible = value; OnPropertyChanged(); }
        }

        private string _numberofQuilts;
        public string NumberofQuilts
        {
            get
            {
                return _numberofQuilts;
            }
            set
            {
                _numberofQuilts = value;
                OnPropertyChanged();
            }
        }



        private ObservableCollection<PalletQuiltDataResponseModel> _quiltGetlist;
        public ObservableCollection<PalletQuiltDataResponseModel> QuiltListForCreate
        {
            get { return _quiltGetlist; }
            set
            {
                _quiltGetlist = value;
                OnPropertyChanged(nameof(QuiltListForCreate));
            }
        }

        private CreatepalletResponseModel _lst;
        public CreatepalletResponseModel Lst
        {
            get { return _lst; }
            set
            {
                _lst = value;
                OnPropertyChanged(nameof(Lst));
            }
        }

        private bool _stackIsVisible = true;
        public bool StackIsVisible
        {
            get { return _stackIsVisible; }
            set { _stackIsVisible = value; OnPropertyChanged(); }
        }

        private bool _lblOrIsviible = true;
        public bool LblOrIsviible
        {
            get { return _lblOrIsviible; }
            set { _lblOrIsviible = value; OnPropertyChanged(); }
        }

        private bool _SerialStackIsVisible = true;
        public bool SerialStackIsVisible
        {
            get { return _SerialStackIsVisible; }
            set { _SerialStackIsVisible = value; OnPropertyChanged(); }
        }
        private MockPalletResponsePageModel _mockPallets;
        public MockPalletResponsePageModel MockPallets
        {
            get { return _mockPallets; }
            set { _mockPallets = value; OnPropertyChanged(); }

        }
        private bool _lblPalletSerialNoIsVisible;
        public bool LblPalletSerialNoIsVisible
        {
            get { return _lblPalletSerialNoIsVisible; }
            set { _lblPalletSerialNoIsVisible = value; OnPropertyChanged(); }
        }
        private bool _lblTotalQuiltsIsVisible;
        public bool LblTotalQuiltsIsVisible
        {
            get { return _lblTotalQuiltsIsVisible; }
            set { _lblTotalQuiltsIsVisible = value; OnPropertyChanged(); }
        }
        private bool _PrintQrCodeVisible;
        public bool PrintQrCodeVisible
        {
            get { return _PrintQrCodeVisible; }
            set { _PrintQrCodeVisible = value; OnPropertyChanged(); }
        }
        private bool _ScanQrCodeVisible = true;
        public bool ScanQrCodeVisible
        {
            get { return _ScanQrCodeVisible; }
            set { _ScanQrCodeVisible = value; OnPropertyChanged(); }
        }


        #endregion

        #region Commands

        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        public ICommand AddButtonCommand => new Command((obj) =>
        {
            AddQuiltPallet(EnteredQuiltSrlNumber);
        });

        List<string> list = new List<string>();
        public ICommand CreatePalletPageCommand => new Command(async () =>
        {
            if (IsCreatePallet)
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    if (StackIsVisible)
                    {
                        var response = await new ApiData().PostData<MockPalletResponsePageModel>("/api/Pallets/MockPallet?quiltsQuantity=" + NumberofQuilts, true);
                        if (response != null)
                        {
                            if (response.statusCode == 201)
                            {
                                //Success
                                SerialStackIsVisible = false;
                                LblOrIsviible = false;
                                LblTotalQuiltsIsVisible = true;
                                LblPalletSerialNoIsVisible = true;
                                PrintQrCodeVisible = true;
                                ScanQrCodeVisible = false;
                                MockPallets = response.data;
                                AppStaticData.IsMockPalletCreated = true;
                                AppStaticData.PalletSerialnumber = MockPallets.serialNumber;
                            }
                            else
                            {
                                toast.LongAlert(response.message);
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                    }
                    if (SerialStackIsVisible)
                    {
                        for (int i = 0; i < QuiltListForCreate.Count; i++)
                        {
                            if (QuiltListForCreate[i].IsCheckboxChecked)
                            {
                                list.Add(QuiltListForCreate[i].serialNumber);
                                palletstatusid = QuiltListForCreate[i].statusId;
                                masterQuiltTypeId = Convert.ToInt32(QuiltListForCreate[i].masterQuiltTypeId);
                            }
                        }
                        if (list != null)
                        {
                            var model = new CreatePalletRequestModel()
                            {
                                palletStatusId = palletstatusid,
                                masterQuiltTypeId = masterQuiltTypeId,
                                quiltSerialNumbers = list,
                                description = Description

                            };
                            var response = await new ApiData().PostData<CreatepalletResponseModel>("/api/Pallets", model, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200)
                                {
                                    //Success
                                    Lst = response.data;
                                    AppStaticData.IsPallet = true;
                                    AppStaticData.PalletSerialnumber = Lst.serialNumber;
                                    PrintQrCodeVisible = false;

                                    await Navigation.PopAsync();

                                }
                                else
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                            else
                            {
                                toast.ShortAlert("Something went wrong!");
                            }
                        }

                    }

                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }

        });

        public ICommand AddAnotherButtonCommand => new Command(() =>
        {
            IsAnotherPalletAdd = true;
        });
        public ICommand PrintQRCodeCommand => new Command(() =>
        {
        });

        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                string param = String.Empty;
                var page = new ScanQRCodePopupPage();

                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    page.Action += async (sender, stringparameter) =>
                    {
                        param = stringparameter;
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }

                page.Disappearing += (c, d) =>
                {
                    if (!string.IsNullOrEmpty(param))
                    {
                        EnteredQuiltSrlNumber = string.Empty;
                        IsQuiltsAdd = true;
                        AddQuiltPallet(param);
                    }
                    else
                    {
                        IsQuiltsAdd = false;
                        //toast.LongAlert("No scan result found");
                    }
                };
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        });

        public ICommand ToggleSearchNotFoundPopupCommand => new Command(() =>
       {
           IsSearchNotFoundIsVisible = false;
       });

        #endregion

    }
}
