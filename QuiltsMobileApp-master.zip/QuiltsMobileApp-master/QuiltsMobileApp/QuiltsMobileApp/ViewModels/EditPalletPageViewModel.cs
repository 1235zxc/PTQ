﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class EditPalletPageViewModel : ObservableObjects
    {
        #region Constructor
        public EditPalletPageViewModel(INavigation navigation, int palletId)
        {
            Navigation = navigation;
            if (palletId != 0)
            {
                GetEditPalletDetails(palletId);
            }
        }
        #endregion

        #region Methods
        private async void GetEditPalletDetails(int PalletID)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                var response = await new ApiData().GetData<PalletDetailListModel>("/api/Pallets/" + PalletID, true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        PalletList = response.data;
                        if (string.IsNullOrEmpty(PalletList.description))
                        {
                            Description = string.Empty;
                        }
                        else
                        {
                            Description = PalletList.description;
                        }

                        QuiltCollection = response.data.quilts;
                        masterquiltid = QuiltCollection[0].masterQuiltTypeId;
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                }
                else
                {
                    toast.LongAlert("Something went wrong!");
                }
                IsBusy = false;
            }
            else
            {
                toast.LongAlert("No internet access!");
            }
        }

        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        public int masterquiltid { get; set; }

        private bool _IsAddMerge;
        public bool IsAddMerge
        {
            get { return _IsAddMerge; }
            set
            {
                _IsAddMerge = value;
                OnPropertyChanged();
            }
        }

        private bool _IsPalletSaved;
        public bool IsPalletSaved
        {
            get
            {
                return _IsPalletSaved;
            }
            set
            {
                _IsPalletSaved = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        public ObservableCollection<PalletDetailListModel> PalletCollection { get; private set; }

        private string _description = string.Empty;
        public string Description
        {
            get
            {
                return _description;

            }
            set
            {
                _description = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<QuiltDetailListModel> _quiltCollection;
        public ObservableCollection<QuiltDetailListModel> QuiltCollection
        {
            get
            {
                return _quiltCollection;

            }
            set
            {
                _quiltCollection = value;
                OnPropertyChanged();
            }
        }

        private PalletDetailListModel _palletList;
        public PalletDetailListModel PalletList
        {
            get
            {
                return _palletList;

            }
            set
            {
                _palletList = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        List<string> list = new List<string>();
        public ICommand SavePalletCommand => new Command(async () =>
        {
            try
            {
                list.Clear();
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    if (IsPalletSaved)
                    {
                        IsBusy = true;
                        if (QuiltCollection != null)
                        {
                            foreach (var item in QuiltCollection)
                            {
                                list.Add(item.serialNumber);
                            }
                            var model = new CreatePalletRequestModel()
                            {
                                id = PalletList.id,
                                palletStatusId = PalletList.palletStatusId,
                                masterQuiltTypeId = masterquiltid,
                                description = Description,
                                quiltSerialNumbers = list
                            };
                            var response = await new ApiData().PostData<CreatepalletResponseModel>("/api/Pallets", model, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200)
                                {
                                    AppStaticData.IsPallet = true;
                                    toast.ShortAlert(response.message);
                                    await Navigation.PopAsync();
                                }
                                else
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                            else
                            {
                                toast.ShortAlert("Something went wrong!");
                            }
                        }
                        else
                        {
                            toast.ShortAlert("No items in pallet!");
                        }
                        IsBusy = false;
                    }
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }
            catch (Exception)
            {

            }

        });

        public bool quiltDeleted { get; set; }
        public ICommand QuiltDeleteCommand => new Command((obj) =>
        {
            var type = obj as QuiltDetailListModel;
            if (QuiltCollection != null)
            {
                if (QuiltCollection.Count > 1)
                {
                    QuiltCollection.Remove(type);
                    quiltDeleted = true;
                    IsPalletSaved = true;
                }
                else
                {
                    toast.LongAlert("A pallet with a single quilt can't be edited, Please add one more for editing.");
                }
            }
        });

        #endregion
    }
}
