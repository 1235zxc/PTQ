﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class AssignQuiltsPageViewModel : ObservableObjects
    {

        public ShipQuiltsPageModel detailsType { get; private set; }
        #region Constructor
        public AssignQuiltsPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            CustomerName = "Customer Name";
            CustomerNumber = "Customer Number";
            OrderNumber = "Order Number";
            CustNameTextColor = CustNumTextColor = OrderNumTextColor = "#8FABC9";
            OnStart();
        }

        public AssignQuiltsPageViewModel(INavigation navigation, ShipQuiltsPageModel type)
        {
            Navigation = navigation;
            toast = DependencyService.Get<IMessage>();
            detailsType = type;
            CustomerName = type.customerName;
            CustomerNumber = type.customerNumber;
            OrderNumber = type.orderNumber;
            CustNameTextColor = CustNumTextColor = OrderNumTextColor = "#444444";

            IsNext = true;
            DataFromShipQuilt();
        }

        #endregion

        #region Methods
        private async void OnStart()
        {
            await GetAllCustomers();
        }

        private async void DataFromShipQuilt()
        {
            await GetAllCustomers();
            await GetOrderdetails(detailsType.customerId);
            GetQuiltTypeAndRemaining(detailsType.customerId, detailsType.orderId);
        }
        private void InternetConnectivity()
        {
            // Connectivity.ConnectivityChanged += Connectivity_ConnectivityChanged;
        }

        private async void Connectivity_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            await GetAllCustomers();
        }

        public async Task<string> GetAllCustomers()
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    var response = await new ApiData().GetDataNew<CustomerListModel>("/api/Customers/GetAllCustomers?onlyOpenOrdersRequired=true", true);
                    if (response != null)
                    {
                        if (response.statusCode == 200 && response.data != null)
                        {
                            var Custlist = response.data;
                            if (Custlist != null && Custlist.Count != 0)
                            {
                                Custlist.Last().Seperator = false;
                                CustomerList = Custlist;
                                CustomerListHeight = CustomerList.Count * 42;
                                if (CustomerList.Count > 10)
                                {
                                    CustomerListHeight = 400;
                                }
                            }
                            else
                            {
                                CustomerList = Custlist;
                                CustomerListHeight = 35;
                            }
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.LongAlert(response.message);
                            }
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!!");
                }
            }
            catch (Exception)
            {

            }
            return string.Empty;
        }

        public async Task<string> GetOrderdetails(int custid)
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    var response = await new ApiData().GetDataNew<OrderOpenResponseModel>("/api/customers/" + custid + "/Orders/open", true);
                    if (response != null)
                    {
                        if (response.statusCode == 200 && response.data != null)
                        {
                            var Orderres = new ObservableCollection<OrderOpenResponseModel>(response.data);
                            if (Orderres != null && Orderres.Count != 0)
                            {
                                Orderres.Last().Seperator = false;
                                OrderDetailsList = Orderres;
                                OrderlistRowHeight = OrderDetailsList.Count * 42;
                                if (OrderDetailsList.Count > 7)
                                {
                                    OrderlistRowHeight = 350;
                                }
                            }
                            else
                            {
                                OrderDetailsList = Orderres;
                                OrderlistRowHeight = 35;
                            }
                        }
                        else
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }

                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!!");
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
            return string.Empty;
        }

        public async void GetQuiltTypeAndRemaining(int customerid, int orderid)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                //var customerid = Customerdetails.id;
                //var orderid = Orderdetails.id;
                var Url = "/api/customers/" + customerid + "/Orders/QuiltTypeCountsByOrderId/" + orderid;
                var response = await new ApiData().GetDataNew<QultTypsebyOrderResponse>(Url, true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        var datalist = response.data;

                        if (datalist != null && datalist.Count != 0)
                        {
                            datalist.Last().Seperator = false;
                            QuiltTypeListForOrder = datalist;
                            OrderInfoRowHeight = QuiltTypeListForOrder.Count * 50 + 60;
                            if (QuiltTypeListForOrder.Count > 11)
                            {
                                OrderInfoRowHeight = 300;
                            }
                            IsOrderinfoVisible = true;
                        }
                        else
                        {
                            IsOrderinfoVisible = true;
                            QuiltTypeListForOrder = datalist;
                        }
                    }
                    else
                    {
                        toast.LongAlert(response.message);
                    }
                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                }
                IsBusy = false;
            }
            else
            {
                toast.LongAlert("No internet access!!");
            }
        }
        #endregion

        #region Properties

        private bool _isNext;
        public bool IsNext
        {
            get { return _isNext; }
            set
            {
                _isNext = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private bool _custListVsbl;
        public bool CustomerListVisible
        {
            get { return _custListVsbl; }
            set
            {
                _custListVsbl = value;
                OnPropertyChanged(nameof(CustomerListVisible));
            }
        }

        private bool _ordrListVsbl;
        public bool OrderListVisible
        {
            get { return _ordrListVsbl; }
            set
            {
                _ordrListVsbl = value;
                OnPropertyChanged(nameof(OrderListVisible));
            }
        }

        private string _custName;
        public string CustomerName
        {
            get { return _custName; }
            set
            {
                _custName = value;
                OnPropertyChanged(nameof(CustomerName));
            }
        }

        private string _custNameColor;
        public string CustNameTextColor
        {
            get { return _custNameColor; }
            set
            {
                _custNameColor = value;
                OnPropertyChanged();
            }
        }

        private string _cusnumColor;
        public string CustNumTextColor
        {
            get { return _cusnumColor; }
            set { _cusnumColor = value; OnPropertyChanged(); }
        }

        private string _ordrNumColor;
        public string OrderNumTextColor
        {
            get { return _ordrNumColor; }
            set { _ordrNumColor = value; OnPropertyChanged(); }
        }

        private ObservableCollection<CustomerListModel> _cusList;
        public ObservableCollection<CustomerListModel> CustomerList
        {
            get { return _cusList; }
            set
            {
                _cusList = value;
                OnPropertyChanged(nameof(CustomerList));
            }
        }

        private ObservableCollection<OrderOpenResponseModel> _ordrDetailsList;
        public ObservableCollection<OrderOpenResponseModel> OrderDetailsList
        {
            get { return _ordrDetailsList; }
            set
            {
                _ordrDetailsList = value;
                OnPropertyChanged(nameof(OrderDetailsList));
            }
        }

        private string _custNum;
        public string CustomerNumber
        {
            get { return _custNum; }
            set
            {
                _custNum = value;
                OnPropertyChanged(nameof(CustomerNumber));
            }
        }

        private string _ordrNum;
        public string OrderNumber
        {
            get { return _ordrNum; }
            set
            {
                _ordrNum = value;
                OnPropertyChanged(nameof(OrderNumber));
            }
        }

        private ObservableCollection<QultTypsebyOrderResponse> _quilttyplist;
        public ObservableCollection<QultTypsebyOrderResponse> QuiltTypeListForOrder
        {
            get { return _quilttyplist; }
            set
            {
                _quilttyplist = value;
                OnPropertyChanged(nameof(QuiltTypeListForOrder));
            }
        }

        private bool _isOrderInfovsbl;
        public bool IsOrderinfoVisible
        {
            get { return _isOrderInfovsbl; }
            set { _isOrderInfovsbl = value; OnPropertyChanged(); }
        }

        private int _inforowheight;
        public int OrderInfoRowHeight
        {
            get { return _inforowheight; }
            set { _inforowheight = value; OnPropertyChanged(); }
        }

        private int _ordrListheight;
        public int OrderlistRowHeight
        {
            get { return _ordrListheight; }
            set { _ordrListheight = value; OnPropertyChanged(nameof(OrderlistRowHeight)); }
        }

        private bool _isRefreshing;
        public bool IsRefreshing
        {
            get { return _isRefreshing; }
            set { _isRefreshing = value; OnPropertyChanged(nameof(IsRefreshing)); }
        }

        private int _customerlistHight;

        public int CustomerListHeight
        {
            get { return _customerlistHight; }
            set { _customerlistHight = value; OnPropertyChanged(nameof(CustomerListHeight)); }
        }


        #endregion

        #region Commands
        public ICommand TogglePopupCommand => new Command(() =>
        {
            CustomerListVisible = false;
        });
        public ICommand TogglePopupCommand1 => new Command(() =>
        {
            OrderListVisible = false;
        });
        public ICommand SelectCustomerTap => new Command(() =>
        {
            if (CustomerList == null)
            {
                CustomerListVisible = false;
            }
            else
            {
                CustomerListVisible = true;
                OrderListVisible = false;
            }
        });
        public ICommand SelectOrderTap => new Command(() =>
        {
            if (OrderDetailsList == null)
            {
                OrderListVisible = false;
            }
            else
            {
                OrderListVisible = true;
            }
        });
        public CustomerListModel Customerdetails { get; set; }
        public ICommand SelectCustomerNameCommand => new Command(async (obj) =>
        {
            try
            {
                Customerdetails = obj as CustomerListModel;
                CustomerName = Customerdetails.name;
                CustNameTextColor = "#444444";
                CustNumTextColor = "#AAAAAA";
                var cusid = Customerdetails.id;
                CustomerNumber = Customerdetails.customerNumber;
                await GetOrderdetails(cusid);
                OrderNumber = "Order Number";
                IsNext = false;
                IsOrderinfoVisible = false;
                CustomerListVisible = false;
            }
            catch (Exception)
            {

            }
        });
        public OrderOpenResponseModel Orderdetails { get; set; }
        public ICommand SelectOrderNameCommand => new Command((obj) =>
        {
            try
            {
                Orderdetails = obj as OrderOpenResponseModel;
                OrderNumber = Orderdetails.orderNumber;
                OrderNumTextColor = "#444444";
                OrderListVisible = false;
                IsNext = true;
                GetQuiltTypeAndRemaining(Customerdetails.id, Orderdetails.id);
            }
            catch (Exception)
            {

            }

        });
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand GoToNextCommand => new Command(async () =>
        {
            if (IsNext)
            {
                await Navigation.PushAsync(new AssignQuiltQRCodePage(Orderdetails, Customerdetails));
            }
        });

        public ICommand RefreshCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsRefreshing = true;
                    var response = await new ApiData().GetDataNew<CustomerListModel>("/api/Customers/GetAllCustomers", true);
                    if (response != null)
                    {
                        if (response.statusCode == 200 && response.data != null)
                        {
                            var Custlist = response.data;
                            if (Custlist != null && Custlist.Count != 0)
                            {
                                Custlist.Last().Seperator = false;
                                CustomerList = Custlist;
                                CustomerListHeight = CustomerList.Count * 45;
                                if (CustomerList.Count > 10)
                                {
                                    CustomerListHeight = 400;
                                }
                            }
                            else
                            {
                                CustomerList = Custlist;
                                CustomerListHeight = 35;
                            }

                            CustomerName = "Customer Name";
                            CustomerNumber = "Customer Number";
                            OrderNumber = "Order Number";
                            CustNameTextColor = CustNumTextColor = OrderNumTextColor = "#8FABC9";
                            CustomerListVisible = false;
                            OrderListVisible = false;
                            OrderDetailsList = null;
                            QuiltTypeListForOrder = null;
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.LongAlert(response.message);
                            }
                        }
                    }
                }
                else
                {
                    toast.ShortAlert("No internet access!!");
                }
                IsRefreshing = false;
            }
            catch (Exception)
            {

            }
        });
        #endregion
        public INavigation Navigation { get; set; }
    }
}
