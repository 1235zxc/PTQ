﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class QuiltsPageViewModel : ObservableObjects
    {
        #region Constructor
        public QuiltsPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        private bool _isQuiltLookUp;
        public bool IsQuiltLookUp
        {
            get { return _isQuiltLookUp; }
            set
            {
                _isQuiltLookUp = value;
                OnPropertyChanged();
            }
        }

        private bool _isQuiltAdd;
        public bool IsQuiltAdd
        {
            get { return _isQuiltAdd; }
            set
            {
                _isQuiltAdd = value;
                OnPropertyChanged();
            }
        }

        private string _serialNumber;
        public string QuiltSerialNumber
        {
            get { return _serialNumber; }
            set
            {
                _serialNumber = value;
                OnPropertyChanged(nameof(QuiltSerialNumber));
            }
        }


        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<QuiltsPageModel> _quiltsCollection;
        public ObservableCollection<QuiltsPageModel> QuiltsCollection
        {
            get { return _quiltsCollection; }
            set
            {
                _quiltsCollection = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region Command
        public ICommand QuiltLookUpCommand => new Command(async () =>
        {
            if (IsQuiltLookUp)
            {
                await QuiltLookUpList(QuiltSerialNumber);
            }

        });

        public ObservableCollection<QuiltsPageModel> Quilts = new ObservableCollection<QuiltsPageModel>();
        private async Task<string> QuiltLookUpList(string SerialNumber)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                var response = await new ApiData().GetData<QuiltsPageModel>("/api/Quilts/GetQuiltLookUp?serialNumber=" + SerialNumber, true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        var listdata = response.data;
                        bool containsItemP = Quilts.Any(item => item.quiltSerialNumber.ToLower().Contains(listdata.quiltSerialNumber.ToLower()));
                        if (containsItemP == false)
                        {
                            listdata.PalletSrlNumb = listdata.palletSerialNumber == null ? "--" : listdata.palletSerialNumber;
                            listdata.CurrentLocation = listdata.currentLocation == null ? "--" : listdata.currentLocation;
                            listdata.LastKnownLocation = listdata.lastKnownLocation == null ? "--" : listdata.lastKnownLocation;
                            listdata.Origin = listdata.origin == null ? "--" : listdata.origin;
                            listdata.Destination = listdata.destination == null ? "--" : listdata.destination;


                            Quilts.Add(listdata);
                            QuiltsCollection = Quilts;
                            QuiltSerialNumber = String.Empty;
                            IsQuiltLookUp = false;
                        }
                        else
                        {
                            toast.ShortAlert("Already in lookuplist");
                        }

                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);

                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                    }
                }
                IsBusy = false;
            }
            else
            {
                toast.ShortAlert("No internet access!");
            }
            return string.Empty;
        }

        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                PermissionStatus permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    var page = new ScanQRCodePopupPage();
                    page.Action += async (sender, stringparameter) =>
                    {
                        if (!string.IsNullOrEmpty(stringparameter))
                        {
                            QuiltSerialNumber = string.Empty;
                            IsQuiltLookUp = true;
                            await QuiltLookUpList(stringparameter);
                        }
                        else
                        {
                            IsQuiltLookUp = false;
                        }
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        });

        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                }
            }
            return status;
        }

        public ICommand ToggleCrossCommand => new Command((obj) =>
        {
            var type = obj as QuiltsPageModel;
            QuiltsCollection.Remove(type);
        });
        #endregion
    }

}
