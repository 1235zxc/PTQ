﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Views;
using System.Windows.Input;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class HomePageViewModel : ObservableObjects
    {
        public HomePageViewModel(INavigation navigation)
        {
            UserType = User_secrets.User_type;
            UserFullName = User_secrets.UserFull_Name;
            Navigation = navigation;
            if (UserType == "Master Admin" || UserType == "Warehouse User")
            {
                MasterAdminHomeIsVisible = true;
            }
            else
            {
                CompanyAdminHomeIsVisible = true;
            }
        }
        private bool isBusy;

        public bool IsBusy
        {
            get { return isBusy; }
            set { isBusy = value; OnPropertyChanged(); }
        }
        public ICommand GotoAssignQuiltsPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new AssignQuiltsPage());

        });
        public ICommand GotoShipQuiltsPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ShipQuiltsPage());

        });
        public ICommand GotoReceiveQuiltsPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ReceiveQuiltQRCodePage());

        });
        public ICommand GotoQuiltsMaintenancePageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new QuiltsMaintenancePage());

        });
        public ICommand GotoCompanyAdminShipQuiltsPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new CAorLUShipQuiltQRCodePage());

        });
        public ICommand GotoCompanyAdminReceiveQuiltsPageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ReceiveQuiltQRCodePage());

        });
        private bool _masterAdminHomeIsVisible;
        public bool MasterAdminHomeIsVisible
        {
            get
            {
                return _masterAdminHomeIsVisible;
            }
            set
            {
                _masterAdminHomeIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _companyAdminHomeIsVisible;
        public bool CompanyAdminHomeIsVisible
        {
            get
            {
                return _companyAdminHomeIsVisible;
            }
            set
            {
                _companyAdminHomeIsVisible = value;
                OnPropertyChanged();
            }
        }

        private string _userType;
        public string UserType
        {
            get
            {
                return _userType;
            }
            set
            {
                _userType = value;
                OnPropertyChanged();
            }
        }

        private string _userFullName;

        public string UserFullName
        {
            get
            {
                return _userFullName;
            }
            set
            {
                _userFullName = value;
                OnPropertyChanged();
            }
        }

        public INavigation Navigation { get; set; }
    }
}
