﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class AssignAndSaveQuiltViewModel : ObservableObjects
    {
        #region Constructor
        public AssignAndSaveQuiltViewModel(INavigation navigation, CustomerListModel customerListModel, OrderOpenResponseModel orderdetails, QuiltPalletforAssign quiltPalletforAssign)
        {
            Navigation = navigation;
            IsBusy = false;

            try
            {
                CustomerName = customerListModel.name;
                Customerid = customerListModel.id;
                CustomerNumber = customerListModel.customerNumber;
                OrderNumber = orderdetails.orderNumber;
                Orderid = orderdetails.id;
                QuiltandPalletforAssign = quiltPalletforAssign;
                GetQuiltTypeAndRemaining();
            }
            catch (Exception)
            {

            }
        }
        #endregion

        #region Methods
        public async void GetQuiltTypeAndRemaining()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                var Url = "/api/customers/" + Customerid + "/Orders/QuiltTypeCountsByOrderId/" + Orderid;
                var response = await new ApiData().GetDataNew<QultTypsebyOrderResponse>(Url, true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        var datalist = response.data;
                        datalist.Last().Seperator = false;

                        QuiltTypeListForOrder = datalist;
                        OrderInfoRowHeight = QuiltTypeListForOrder.Count * 50 + 60;
                        if (QuiltTypeListForOrder.Count > 11)
                        {
                            OrderInfoRowHeight = 300;
                        }
                        IsOrderinfoVisible = true;
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                }
                IsBusy = false;
            }
            else
            {
                toast.LongAlert("No internet access!!");
            }
        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        public QuiltPalletforAssign QuiltandPalletforAssign { get; set; }

        public int Customerid { get; set; }
        public int Orderid { get; set; }
        private string _cusName;
        public string CustomerName
        {
            get { return _cusName; }
            set { _cusName = value; OnPropertyChanged(); }
        }

        private string _ordrNum;

        public string OrderNumber
        {
            get { return _ordrNum; }
            set { _ordrNum = value; OnPropertyChanged(); }
        }
        private string _custNum;

        public string CustomerNumber
        {
            get { return _custNum; }
            set { _custNum = value; OnPropertyChanged(); }
        }

        private bool _isBusy;

        public bool IsBusy
        {
            get { return _isBusy; }
            set { _isBusy = value; OnPropertyChanged(); }
        }
        private ObservableCollection<QultTypsebyOrderResponse> _quilttyplist;
        public ObservableCollection<QultTypsebyOrderResponse> QuiltTypeListForOrder
        {
            get { return _quilttyplist; }
            set
            {
                _quilttyplist = value;
                OnPropertyChanged(nameof(QuiltTypeListForOrder));
            }
        }
        private bool _isOrderInfovsbl;
        public bool IsOrderinfoVisible
        {
            get { return _isOrderInfovsbl; }
            set { _isOrderInfovsbl = value; OnPropertyChanged(); }
        }

        private int _inforowheight;
        public int OrderInfoRowHeight
        {
            get { return _inforowheight; }
            set { _inforowheight = value; OnPropertyChanged(); }
        }
        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        public ICommand SaveAndAssignCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    var Assignurl = "/api/inventory/AssignInventory";
                    var response = await new ApiData().PostData<AssignQuiltQRCodePageModel>(Assignurl, QuiltandPalletforAssign, true);
                    if (response != null)
                    {
                        if (response.statusCode == 200)
                        {
                            toast.ShortAlert(response.message);
                            await Navigation.PopToRootAsync();
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.LongAlert(response.message);
                            }
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!!");
                }
            }
            catch (Exception)
            {

            }
        });

        public ICommand SaveAndShipCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    var Assignurl = "/api/inventory/AssignInventory";
                    var response = await new ApiData().PostData<AssignQuiltQRCodePageModel>(Assignurl, QuiltandPalletforAssign, true);
                    if (response != null)
                    {
                        if (response.statusCode == 200)
                        {
                            toast.ShortAlert(response.message);
                            var existingPages = Navigation.NavigationStack.ToList();
                            await Navigation.PushAsync(new ShipQuiltsPage());
                            await Navigation.PushAsync(new ShipQuiltQRCodePage(QuiltandPalletforAssign.orderNumber));
                            for (int i = 0; i <= existingPages.Count; i++)
                            {
                                if (i != 0)
                                {
                                    Navigation.RemovePage(existingPages[i]);
                                }
                            }
                        }
                        else
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                }
                else
                {
                    toast.LongAlert("No internet access!!");
                }
            }
            catch (Exception ex)
            {

            }

        });
        #endregion
    }
}
