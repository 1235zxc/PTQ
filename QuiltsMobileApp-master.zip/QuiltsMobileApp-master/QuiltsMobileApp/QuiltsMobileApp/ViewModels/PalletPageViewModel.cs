﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class PalletPageViewModel : ObservableObjects
    {
        #region Constructor
        public PalletPageViewModel(INavigation navigation)
        {
            SearchOrResetSorce = "searchicon";
            UserType = User_secrets.User_type;
            GetUserType();
            OnStart();
            InternetConnectivity();
            Navigation = navigation;
        }

        #endregion

        #region Methods
        private async void OnStart()
        {
            await PalletsItemCollection(pageNumber, pageSize);
        }
        private void InternetConnectivity()
        {
            Connectivity.ConnectivityChanged += Connectivity_ConnectivityChanged;

        }
        private async void Connectivity_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                if (PalletCollection == null)
                {
                    await PalletsItemCollection(pageNumber, pageSize);
                }
            }
            else
            {
                NoInternetConnected = true;
                int _countSeconds = 3;
                Device.StartTimer(TimeSpan.FromSeconds(1), () =>
                {
                    _countSeconds--;
                    if (_countSeconds == 0)
                    {
                        NoInternetConnected = false;
                    }
                    return Convert.ToBoolean(_countSeconds);
                });
            }
        }

        public void GetUserType()
        {
            if (UserType == "Master Admin" || UserType == "Warehouse User")
            {
                IsCreatePallet = true;
                IsRefreshEnable = true;
            }
            else if (UserType == "Company Admin" || UserType == "Location User")
            {
                IsCreatePallet = true;
                IsRefreshEnable = true;
            }
            else
            {
                IsCreatePallet = false;
                IsRefreshEnable = false;
            }
        }
        public async Task<string> PalletsItemCollection(int PageNumber, int PageSize)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    if (UserType == "Master Admin" || UserType == "Warehouse User")
                    {
                        IsCAorLUuserVisible = false;
                        IsMAorWUuserVisible = true;

                        IsBusy = true;
                        var url = "/api/Pallets?PageNumber=" + PageNumber + "&PageSize=" + PageSize;
                        var response = await new ApiData().GetData<PalletPageModel>(url, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                pageNumber += 1;
                                PalletCollection = response.data.pallets;
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                                else
                                {
                                    toast.ShortAlert("Something went wrong!");
                                }
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                        IsBusy = false;
                    }
                    else
                    {
                        IsCAorLUuserVisible = true;
                        IsMAorWUuserVisible = false;


                        IsBusy = true;
                        var url = "/api/Pallets/GetPalletsForCompany?PageNumber=" + PageNumber + "&PageSize=" + PageSize;

                        var response = await new ApiData().GetData<CAorLuPalletPageModel>(url, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                pageNumber += 1;
                                CAorLuPalletCollection = response.data.palletList.pallets;
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                                else
                                {
                                    toast.ShortAlert("Something went wrong!");
                                }
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                        IsBusy = false;

                    }
                }
                catch (Exception)
                {
                    toast.ShortAlert("Things went wrong!");
                }
            }
            else
            {
                toast.ShortAlert("No internet access!");
            }

            return string.Empty;

        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }

        public int pageNumber = 1;
        public int pageSize = 15;
        public bool loadingComplete = false;

        private string _userType;
        public string UserType
        {
            get
            {
                return _userType;
            }
            set
            {
                _userType = value;
                OnPropertyChanged(nameof(UserType));
            }
        }

        private bool _isloading;
        public bool IsLoading
        {
            get { return _isloading; }
            set { _isloading = value; OnPropertyChanged(); }
        }

        private ObservableCollection<PalletDetailListModel> _palletCollection;
        public ObservableCollection<PalletDetailListModel> PalletCollection
        {
            get
            {
                return _palletCollection;
            }
            set
            {
                _palletCollection = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<CAorLuPallet> _cAorLuPalletCollection;
        public ObservableCollection<CAorLuPallet> CAorLuPalletCollection
        {
            get { return _cAorLuPalletCollection; }
            set { _cAorLuPalletCollection = value; OnPropertyChanged(); }
        }
        private CAorLuPalletPageModel _CAorLuPalletList;
        public CAorLuPalletPageModel CAorLuPalletList
        {
            get
            {
                return _CAorLuPalletList;
            }
            set
            {
                _CAorLuPalletList = value;
                OnPropertyChanged();
            }
        }

        private PalletPageModel _palletList;
        public PalletPageModel PalletList
        {
            get
            {
                return _palletList;
            }
            set
            {
                _palletList = value; OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private bool _isCreatepallet;
        public bool IsCreatePallet
        {
            get { return _isCreatepallet; }
            set { _isCreatepallet = value; OnPropertyChanged(); }
        }

        private bool _isSearch;
        public bool IsSearchPerform
        {
            get { return _isSearch; }
            set { _isSearch = value; OnPropertyChanged(); }
        }

        private string _palletSerialNum;
        public string PalletSerialNumber
        {
            get { return _palletSerialNum; }
            set { _palletSerialNum = value; OnPropertyChanged(); }
        }

        private string _searchOrreset;
        public string SearchOrResetSorce
        {
            get { return _searchOrreset; }
            set
            {
                _searchOrreset = value;
                OnPropertyChanged(nameof(SearchOrResetSorce));
            }
        }

        private bool _noInternet;
        public bool NoInternetConnected
        {
            get { return _noInternet; }
            set { _noInternet = value; OnPropertyChanged(nameof(NoInternetConnected)); }
        }

        private bool _isRefreshing;
        public bool IsRefreshing
        {
            get { return _isRefreshing; }
            set { _isRefreshing = value; OnPropertyChanged(nameof(IsRefreshing)); }
        }

        private bool _isRefreshEnable;
        public bool IsRefreshEnable
        {
            get { return _isRefreshEnable; }
            set { _isRefreshEnable = value; OnPropertyChanged(nameof(IsRefreshEnable)); }
        }
        private bool _isMAorWUuserVisible;
        public bool IsMAorWUuserVisible
        {
            get { return _isMAorWUuserVisible; }
            set { _isMAorWUuserVisible = value; OnPropertyChanged(); }
        }

        private bool _isCAorLUuserVisible;
        public bool IsCAorLUuserVisible
        {
            get { return _isCAorLUuserVisible; }
            set { _isCAorLUuserVisible = value; OnPropertyChanged(); }
        }
        #endregion

        #region Commands
        public ICommand GoToPalletDetailPageCommand => new Command(async (obj) =>
        {
            if (UserType == "Master Admin" || UserType == "Warehouse User")
            {
                var type = obj as PalletDetailListModel;
                if (type != null)
                {
                    await Navigation.PushAsync(new PalletDetailsPage(type.id));
                }
            }
            else
            {
                var type = obj as CAorLuPallet;
                if (type != null)
                {
                    await Navigation.PushAsync(new PalletDetailsPage(type.id));
                }
            }
        });

        public ICommand GotoCreatePalletPageCommand => new Command(async () =>
        {
            if (IsCreatePallet)
            {
                await Navigation.PushAsync(new CreatePalletPage());
            }
        });

        public ICommand LoadMoreDataCommand => new Command(async () =>
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    if (UserType == "Master Admin" || UserType == "Warehouse User")
                    {
                        IsCAorLUuserVisible = false;
                        IsMAorWUuserVisible = true;

                        if (PalletCollection.Count > 0 && !loadingComplete && SearchOrResetSorce != "ClearIcon")
                        {
                            IsLoading = true;

                            var url = "/api/Pallets?PageNumber=" + pageNumber + "&PageSize=" + pageSize;
                            var response = await new ApiData().GetData<PalletPageModel>(url, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200 && response.data != null)
                                {
                                    PalletList = response.data;
                                    if (PalletList.pallets.Count > 0)
                                    {
                                        pageNumber += 1;
                                        foreach (var record in PalletList.pallets)
                                        {
                                            PalletCollection.Add(record);
                                        }
                                    }
                                    else
                                    {
                                        loadingComplete = true;
                                    }
                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        toast.LongAlert(response.message);
                                    }
                                    else
                                    {
                                        toast.ShortAlert("Something went wrong!");
                                    }
                                }
                            }
                            IsLoading = false;
                        }
                    }
                    else
                    {
                        IsLoading = true;
                        IsCAorLUuserVisible = true;
                        IsMAorWUuserVisible = false;
                        //  CAorLuPalletCollection.Clear();
                        var url = "/api/Pallets/GetPalletsForCompany?PageNumber=" + pageNumber + "&PageSize=" + pageSize;
                        var response = await new ApiData().GetData<CAorLuPalletPageModel>(url, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                CAorLuPalletList = response.data;
                                if (CAorLuPalletList.palletList.pallets.Count > 0)
                                {
                                    pageNumber += 1;
                                    foreach (var record in CAorLuPalletList.palletList.pallets)
                                    {
                                        CAorLuPalletCollection.Add(record);
                                    }
                                }
                                else
                                {
                                    loadingComplete = true;
                                }
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                                else
                                {
                                    toast.ShortAlert("Something went wrong!");
                                }
                            }
                        }
                        IsLoading = false;
                    }
                }
                catch (Exception)
                {
                    toast.ShortAlert("Things went wrong!");
                }
            }
            else
            {
                toast.ShortAlert("No internet access!");
            }
        });


        public ICommand RefreshCommand => new Command(async () =>
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                try
                {
                    IsRefreshing = true;
                    pageNumber = 1;
                    pageSize = 15;
                    if (UserType == "Master Admin" || UserType == "Warehouse User")
                    {
                        IsCAorLUuserVisible = false;
                        IsMAorWUuserVisible = true;

                        var url = "/api/Pallets?PageNumber=" + pageNumber + "&PageSize=" + pageSize;
                        var response = await new ApiData().GetData<PalletPageModel>(url, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                pageNumber += 1;
                                PalletCollection = response.data.pallets;
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                    }
                    else
                    {
                        IsCAorLUuserVisible = true;
                        IsMAorWUuserVisible = false;
                        // CAorLuPalletCollection.Clear();
                        var url = "/api/Pallets/GetPalletsForCompany?PageNumber=" + pageNumber + "&PageSize=" + pageSize;
                        var response = await new ApiData().GetData<CAorLuPalletPageModel>(url, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                pageNumber += 1;
                                CAorLuPalletCollection = response.data.palletList.pallets;

                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    toast.ShortAlert("Things went wrong!");
                }
            }
            else
            {
                toast.ShortAlert("No internet access!");
            }
            IsRefreshing = false;
        });
        #endregion

    }
}
