﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class SetNewPasswordPageViewModel : ObservableObjects
    {

        #region Constructor
        public SetNewPasswordPageViewModel(INavigation navigation, string Token, string Email)
        {
            Navigation = navigation;
            resetToken = Token;
            userEmail = Email;
        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        private string _imageNewPassVisible = "Eye.png";
        public string ImageNewPassVisible
        {
            get { return _imageNewPassVisible; }
            set { _imageNewPassVisible = value; OnPropertyChanged(); }
        }
        private string _imageCfmPassVisible = "Eye.png";
        public string ImageCfmPassVisible
        {
            get { return _imageCfmPassVisible; }
            set { _imageCfmPassVisible = value; OnPropertyChanged(); }
        }

        private bool _isSetNewPassword;
        public bool IsSetNewPassword
        {
            get { return _isSetNewPassword; }
            set
            {
                _isSetNewPassword = value;
                OnPropertyChanged();
            }
        }

        private bool _isNewPasswordVisible = true;
        public bool IsNewPasswordVisible
        {
            get { return _isNewPasswordVisible; }
            set { _isNewPasswordVisible = value; OnPropertyChanged(); }
        }

        private bool _isCfmPasswordVisible = true;
        public bool IsCfmPasswordVisible
        {
            get { return _isCfmPasswordVisible; }
            set { _isCfmPasswordVisible = value; OnPropertyChanged(); }
        }

        private string _enterNewPwdTxt;
        public string EnterNewPwdTxt
        {
            get { return _enterNewPwdTxt; }
            set
            {
                _enterNewPwdTxt = value;

                OnPropertyChanged(nameof(EnterNewPwdTxt));
            }
        }

        private string _enterCfmNewPwdTxt;
        public string EnterCfmNewPwdTxt
        {
            get { return _enterCfmNewPwdTxt; }
            set
            {
                _enterCfmNewPwdTxt = value;

                OnPropertyChanged(nameof(EnterCfmNewPwdTxt));
            }
        }

        private bool _newpassfrmbrdrclr;
        public bool NewPasswordFrameBorderColor
        {
            get { return _newpassfrmbrdrclr; }
            set { _newpassfrmbrdrclr = value; OnPropertyChanged(); }
        }

        private bool _cfmpassfrmbrdrclr;
        public bool CfmPasswordFrameBorderColor
        {
            get { return _cfmpassfrmbrdrclr; }
            set { _cfmpassfrmbrdrclr = value; OnPropertyChanged(); }
        }

        private bool _isButtonEnabled;
        public bool IsButtonEnabled
        {
            get
            {
                return _isButtonEnabled;
            }
            set
            {
                _isButtonEnabled = value;
            }
        }

        private string _lblNewPasswordError;
        public string LblNewPasswordError
        {
            get
            {
                return _lblNewPasswordError;
            }
            set
            {
                _lblNewPasswordError = value;
                OnPropertyChanged();
            }
        }

        private string _lblCfmPasswordError;
        public string LblCfmPasswordError
        {
            get
            {
                return _lblCfmPasswordError;
            }
            set
            {
                _lblCfmPasswordError = value;
                OnPropertyChanged();
            }
        }

        private string _lblCfmPasswordAndPasswordError;
        public string LblCfmPasswordAndPasswordError
        {
            get
            {
                return _lblCfmPasswordAndPasswordError;
            }
            set
            {
                _lblCfmPasswordAndPasswordError = value;
                OnPropertyChanged();
            }
        }

        private bool _lblNewPasswordErrorIsVisible;
        public bool LblNewPasswordErrorIsVisible
        {
            get
            {
                return _lblNewPasswordErrorIsVisible;
            }
            set
            {
                _lblNewPasswordErrorIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _lblCfmPasswordErrorIsVisible;
        public bool LblCfmPasswordErrorIsVisible
        {
            get
            {
                return _lblCfmPasswordErrorIsVisible;
            }
            set
            {
                _lblCfmPasswordErrorIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _lblCfmPasswordAndPasswordErrorIsVisible;
        public bool LblCfmPasswordAndPasswordErrorIsVisible
        {
            get
            {
                return _lblCfmPasswordAndPasswordErrorIsVisible;
            }
            set
            {
                _lblCfmPasswordAndPasswordErrorIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }


        internal void IsAllEntriesFilled()
        {
            if (!string.IsNullOrEmpty(EnterNewPwdTxt) && !string.IsNullOrEmpty(EnterCfmNewPwdTxt))
            {
                if (PasswordValid && IsConfirmPassValid)
                {
                    IsSetNewPassword = true;
                }
                else
                {
                    IsSetNewPassword = false;
                }
            }
            else
            {
                IsSetNewPassword = false;
            }
        }

        private bool _passValid;
        public bool PasswordValid
        {
            get { return _passValid; }
            set
            {
                _passValid = value;
                OnPropertyChanged();
            }
        }

        public string resetToken { get; set; }
        public string userEmail { get; set; }


        private bool _isSetNewvvalid;
        public bool IsConfirmPassValid
        {
            get { return _isSetNewvvalid; }
            set { _isSetNewvvalid = value; OnPropertyChanged(nameof(IsConfirmPassValid)); }
        }
        #endregion

        #region Commands
        public ICommand ConfirmPasswordShowHideCommand => new Command(() =>
        {

            if (IsCfmPasswordVisible)
            {
                IsCfmPasswordVisible = false;
                ImageCfmPassVisible = "Hide.png";

            }
            else
            {
                IsCfmPasswordVisible = true;
                ImageCfmPassVisible = "Eye.png";
            }
        });
        public ICommand NewPasswordShowHideCommand => new Command(() =>
        {
            if (IsNewPasswordVisible)
            {
                IsNewPasswordVisible = false;
                ImageNewPassVisible = "Hide.png";
            }
            else
            {
                IsNewPasswordVisible = true;
                ImageNewPassVisible = "Eye.png";
            }

        });
        public ICommand SetNewPasswordCommand => new Command(async () =>
        {
            try
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    if (!string.IsNullOrEmpty(EnterNewPwdTxt) && !string.IsNullOrEmpty(EnterCfmNewPwdTxt) && PasswordValid == IsConfirmPassValid && IsSetNewPassword)
                    {
                        IsBusy = true;
                        var resetPwdModel = new SetNewPasswordRequestPageModel()
                        {
                            email = userEmail,
                            token = resetToken,
                            password = EnterNewPwdTxt
                        };
                        var response = await new ApiData().PostData<SetNewPasswordPageModel>("/api/reset-password", resetPwdModel, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200)
                            {
                                Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                                toast.ShortAlert(response.message);
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                                    await Navigation.PushAsync(new ForgotPasswordPage());
                                    toast.LongAlert(response.message);
                                }
                                else
                                {
                                    toast.LongAlert("Something went wrong! Please try again.");
                                }
                            }
                        }
                        else
                        {
                            toast.LongAlert("Something went wrong!");
                        }
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong");
            }
        });
        public ICommand GoToLoginCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new OnBoardingPage(), false);
        });

        #endregion
    }
}
