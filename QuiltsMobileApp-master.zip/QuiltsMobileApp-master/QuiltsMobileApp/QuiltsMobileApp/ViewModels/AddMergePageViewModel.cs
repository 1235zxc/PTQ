﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class AddMergePageViewModel : ObservableObjects
    {

        #region Constructor
        public AddMergePageViewModel(INavigation navigation, PalletDetailListModel palletlist)
        {
            if (palletlist != null)
            {
                PalletList = palletlist;
                PalletId = palletlist.id;
            }
            Navigation = navigation;
            SelectAndClear = "Select All";
        }
        #endregion

        #region Methods

        public ObservableCollection<PalletQuiltDataResponseModel> qlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public async void AddQuiltPallet(string serialNumber)
        {
            try
            {
                if (IsQuiltOrPalletAdd && !string.IsNullOrEmpty(serialNumber))
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        string text = serialNumber;
                        List<string> stringlist = text.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        var model = new QuiltPalletRequestModel
                        {
                            serialNumbers = stringlist,
                            individualQuiltsOnly = false,
                            customerDetailsRequired = false,
                            individualQuiltPallets = false
                        };
                        var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                        var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);
                        if (response != null)
                        {
                            var listdata = response.data;

                            if (response.statusCode == 200 && response.data != null)
                            {
                                for (int i = 0; i < listdata.Count; i++)
                                {
                                    bool containsItemP = qlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                    if (containsItemP == false && PalletList.palletStatusId == listdata[i].statusId)
                                    {
                                        if (listdata[i].quilts == null)
                                        {
                                            listdata[i].PlusIconVisibleOrNot = false;

                                        }
                                        else
                                        {
                                            listdata[i].PlusIconVisibleOrNot = true;
                                        }
                                        qlist.Add(listdata[i]);
                                        EnteredQuiltOrPalletSrlNumber = String.Empty;
                                        IsQuiltOrPalletAdd = false;
                                    }
                                    else
                                    {
                                        if (listdata[i].statusId != PalletList.palletStatusId)
                                        {
                                            toast.LongAlert("You can only Add/Merge with same status");
                                        }
                                        else
                                        {
                                            toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                        }
                                    }
                                }

                                QuiltPalletlistToMerge = qlist;
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                                else
                                {
                                    toast.ShortAlert("Things went wrong!");
                                }
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                        IsBusy = false;
                    }
                    else
                    {
                        toast.ShortAlert("No internet access!");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }

        public int PalletId { get; set; }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private bool _isquiltPalletAdd;
        public bool IsQuiltOrPalletAdd
        {
            get
            {
                return _isquiltPalletAdd;
            }
            set
            {
                _isquiltPalletAdd = value;
                OnPropertyChanged();
            }
        }

        private string _entrquiltpalletSrlNumb;
        public string EnteredQuiltOrPalletSrlNumber
        {
            get { return _entrquiltpalletSrlNumb; }
            set
            {
                _entrquiltpalletSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltOrPalletSrlNumber));
            }
        }

        private bool _isScanQRCodeVisible;
        public bool ScanQRCodeVisible
        {
            get { return _isScanQRCodeVisible; }
            set { _isScanQRCodeVisible = value; OnPropertyChanged(); }
        }

        private bool _isSavePalletButtonColorVisible;
        public bool IsSavePalletButtonColorVisible
        {
            get
            {
                return _isSavePalletButtonColorVisible;

            }
            set
            {
                _isSavePalletButtonColorVisible = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<PalletQuiltDataResponseModel> _quiltpalletGetlist;
        public ObservableCollection<PalletQuiltDataResponseModel> QuiltPalletlistToMerge
        {
            get { return _quiltpalletGetlist; }
            set
            {
                _quiltpalletGetlist = value;
                OnPropertyChanged(nameof(QuiltPalletlistToMerge));
            }
        }

        private CreatepalletResponseModel _lst;
        public CreatepalletResponseModel Lst
        {
            get { return _lst; }
            set
            {
                _lst = value;
                OnPropertyChanged(nameof(Lst));
            }
        }

        private PalletDetailListModel _palletList;
        public PalletDetailListModel PalletList
        {
            get
            {
                return _palletList;

            }
            set
            {
                _palletList = value;
                OnPropertyChanged();
            }
        }

        private string _selectAndClear;
        public string SelectAndClear
        {
            get { return _selectAndClear; }
            set { _selectAndClear = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }

        #endregion

        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand SelectAllCommand => new Command(async () =>
        {
            if (SelectAndClear == "Select All")
            {
                if (QuiltPalletlistToMerge != null && QuiltPalletlistToMerge.Count != 0)
                {
                    for (int i = 0; i < QuiltPalletlistToMerge.Count; i++)
                    {
                        QuiltPalletlistToMerge[i].IsCheckboxChecked = true;
                    }
                    SelectAndClear = "Clear All";
                }
                else
                {
                    toast.LongAlert("Please Add quilts/pallets first");
                }
            }
            else
            {
                if (QuiltPalletlistToMerge != null && QuiltPalletlistToMerge.Count != 0)
                {
                    for (int i = 0; i < QuiltPalletlistToMerge.Count; i++)
                    {
                        QuiltPalletlistToMerge[i].IsCheckboxChecked = false;
                    }
                    SelectAndClear = "Select All";
                }
                else
                {
                    SelectAndClear = "Select All";
                }
            }

        });
        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    var page = new ScanQRCodePopupPage();
                    page.Action += (sender, stringparameter) =>
                    {
                        if (!string.IsNullOrEmpty(stringparameter))
                        {
                            EnteredQuiltOrPalletSrlNumber = string.Empty;
                            IsQuiltOrPalletAdd = true;
                            AddQuiltPallet(stringparameter);
                        }
                        else
                        {
                            IsQuiltOrPalletAdd = false;
                        }
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        });

        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    await PopupNavigation.Instance.PushAsync(new AccessWarningPopupPage());
                }
            }
            return status;
        }
        public ICommand AddButtonCommand => new Command(() =>
        {
            AddQuiltPallet(EnteredQuiltOrPalletSrlNumber);
        });

        public int palletstatusid { get; set; }
        public int masterQuiltTypeId { get; set; }

        List<string> list = new List<string>();
        public ICommand AddMergePalletSaveCommand => new Command(async () =>
        {
            if (IsSavePalletButtonColorVisible)
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    for (int i = 0; i < QuiltPalletlistToMerge.Count; i++)
                    {
                        if (QuiltPalletlistToMerge[i].quilts != null)
                        {
                            for (int j = 0; j < QuiltPalletlistToMerge[i].quilts.Count; j++)
                            {
                                if (QuiltPalletlistToMerge[i].quilts[j].IsCheckboxCheckedNew)
                                {
                                    list.Add(QuiltPalletlistToMerge[i].quilts[j].serialNumber);
                                }
                            }
                        }
                        else
                        {
                            if (QuiltPalletlistToMerge[i].IsCheckboxChecked)
                            {
                                list.Add(QuiltPalletlistToMerge[i].serialNumber);
                            }
                        }

                    }
                    List<string> str = list.ToList();

                    if (str != null)
                    {
                        var model = new AddMergePageModel()
                        {
                            id = PalletId,
                            quiltSerialNumbers = str,

                        };
                        var response = await new ApiData().PostData<AddMergePalletResponseModel>("/api/Pallets/MergePallet", model, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200)
                            {
                                AppStaticData.IsPallet = true;
                                toast.ShortAlert(response.message);
                                await Navigation.PopAsync();
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                        else
                        {
                            toast.LongAlert("Something went wrong!");
                        }

                    }

                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }

        });
        #endregion
    }
}
