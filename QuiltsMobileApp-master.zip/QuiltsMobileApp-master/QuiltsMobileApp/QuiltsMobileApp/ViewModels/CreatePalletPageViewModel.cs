﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class CreatePalletPageViewModel : ObservableObjects
    {
        #region Constructor
        public CreatePalletPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            SelectAndClear = "Select All";
        }
        #endregion

        #region Methods

        public ObservableCollection<PalletQuiltDataResponseModel> qlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public async void AddQuiltPallet(string serialNumber)
        {
            if (IsQuiltsAdd && !string.IsNullOrEmpty(serialNumber))
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;
                    string textTrimmed = String.Concat(serialNumber.Where(c => !Char.IsWhiteSpace(c)));
                    List<string> stringlist = textTrimmed.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    var model = new QuiltPalletRequestModel
                    {
                        serialNumbers = stringlist,
                        individualQuiltsOnly = true,
                        customerDetailsRequired = false,
                        individualQuiltPallets = false
                    };
                    var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                    var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);
                    if (response != null)
                    {
                        var listdata = response.data;

                        if (response.statusCode == 200 && response.data != null)
                        {
                            for (int i = 0; i < listdata.Count; i++)
                            {
                                bool containsItemP = qlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                if (containsItemP == false)
                                {
                                    qlist.Add(listdata[i]);
                                }
                                else
                                {
                                    toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                }
                            }
                            QuiltListForCreate = qlist;
                            EnteredQuiltSrlNumber = string.Empty;
                            IsQuiltsAdd = false;
                        }
                        else
                        {
                            if (response.message != null)
                            {
                                toast.LongAlert(response.message);
                            }
                        }

                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }
                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }
            }

        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        public int palletstatusid { get; set; }
        public int masterQuiltTypeId { get; set; }

        private bool _isCreatePalletButtonColorVisible;
        public bool IsCreatePallet
        {
            get
            {
                return _isCreatePalletButtonColorVisible;
            }
            set
            {
                _isCreatePalletButtonColorVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isquiltsAdd;
        public bool IsQuiltsAdd
        {
            get
            {
                return _isquiltsAdd;
            }
            set
            {
                _isquiltsAdd = value;
                OnPropertyChanged();
            }
        }

        private bool _isAnotherPalletAdd;
        public bool IsAnotherPalletAdd
        {
            get
            {
                return _isAnotherPalletAdd;
            }
            set
            {
                _isAnotherPalletAdd = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private string _entrquiltSrlNumb;
        public string EnteredQuiltSrlNumber
        {
            get { return _entrquiltSrlNumb; }
            set
            {
                _entrquiltSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltSrlNumber));
            }
        }

        private ObservableCollection<CreatePalletPageModel> _createPallets;
        public ObservableCollection<CreatePalletPageModel> CreatePallets
        {
            get
            {
                return _createPallets;
            }
            set
            {
                _createPallets = value;
                OnPropertyChanged();
            }
        }

        private string _description = String.Empty;
        public string Description
        {
            get
            {
                return _description;
            }
            set
            {
                _description = value;
                OnPropertyChanged();
            }
        }

        private string _checkBoxImages = "Deselected.png";
        public string CheckBoxImages
        {
            get
            {
                return _checkBoxImages;
            }
            set
            {
                _checkBoxImages = value;
                OnPropertyChanged();
            }

        }

        private bool _IsSearchNotFoundIsVisible;
        public bool IsSearchNotFoundIsVisible
        {
            get { return _IsSearchNotFoundIsVisible; }
            set { _IsSearchNotFoundIsVisible = value; OnPropertyChanged(); }
        }

        private ObservableCollection<PalletQuiltDataResponseModel> _quiltGetlist;
        public ObservableCollection<PalletQuiltDataResponseModel> QuiltListForCreate
        {
            get { return _quiltGetlist; }
            set
            {
                _quiltGetlist = value;
                OnPropertyChanged(nameof(QuiltListForCreate));
            }
        }

        private CreatepalletResponseModel _lst;
        public CreatepalletResponseModel Lst
        {
            get { return _lst; }
            set
            {
                _lst = value;
                OnPropertyChanged(nameof(Lst));
            }
        }

        private string _selectAndclr;
        public string SelectAndClear
        {
            get { return _selectAndclr; }
            set { _selectAndclr = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }

        #endregion

        #region Commands
        public ICommand SelectAllItemsCommand => new Command(() =>
        {
            if (SelectAndClear == "Select All")
            {
                if (QuiltListForCreate != null && QuiltListForCreate.Count != 0)
                {
                    for (int i = 0; i < QuiltListForCreate.Count; i++)
                    {
                        QuiltListForCreate[i].IsCheckboxChecked = true;
                    }
                    SelectAndClear = "Clear All";
                }
                else
                {
                    toast.LongAlert("Please Add quilts/pallets first");
                }
            }
            else
            {
                if (QuiltListForCreate != null && QuiltListForCreate.Count != 0)
                {
                    for (int i = 0; i < QuiltListForCreate.Count; i++)
                    {
                        QuiltListForCreate[i].IsCheckboxChecked = false;
                    }
                    SelectAndClear = "Select All";
                }
                else
                {
                    SelectAndClear = "Select All";
                }
            }

        });
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });

        public ICommand AddButtonCommand => new Command((obj) =>
        {
            AddQuiltPallet(EnteredQuiltSrlNumber);
        });

        List<string> list = new List<string>();
        public ICommand CreatePalletPageCommand => new Command(async () =>
        {
            try
            {
                if (IsCreatePallet)
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        for (int i = 0; i < QuiltListForCreate.Count; i++)
                        {
                            if (QuiltListForCreate[i].IsCheckboxChecked)
                            {
                                list.Add(QuiltListForCreate[i].serialNumber);
                                palletstatusid = QuiltListForCreate[i].statusId;
                                masterQuiltTypeId = Convert.ToInt32(QuiltListForCreate[i].masterQuiltTypeId);
                            }
                        }
                        if (list != null)
                        {
                            var model = new CreatePalletRequestModel()
                            {
                                palletStatusId = palletstatusid,
                                masterQuiltTypeId = masterQuiltTypeId,
                                quiltSerialNumbers = list,
                                description = Description

                            };
                            var response = await new ApiData().PostData<CreatepalletResponseModel>("/api/Pallets", model, true);
                            if (response != null)
                            {
                                if (response.statusCode == 201)
                                {
                                    AppStaticData.IsPallet = true;
                                    toast.ShortAlert(response.message);
                                    Lst = response.data;
                                    var previousPage = Navigation.NavigationStack.LastOrDefault();

                                    await Navigation.PushAsync(new PalletDetailsPage(Lst.id));
                                    Navigation.RemovePage(previousPage);

                                }
                                else
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                            else
                            {
                                toast.ShortAlert("Something went wrong!");
                            }
                        }
                        IsBusy = false;
                    }
                    else
                    {
                        toast.LongAlert("No internet access!");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        });

        public ICommand AddAnotherButtonCommand => new Command(() =>
        {
            IsAnotherPalletAdd = true;
        });

        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                string param = String.Empty;
                var page = new ScanQRCodePopupPage();

                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    page.Action += async (sender, stringparameter) =>
                    {
                        param = stringparameter;
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }

                page.Disappearing += (c, d) =>
                {
                    if (!string.IsNullOrEmpty(param))
                    {
                        EnteredQuiltSrlNumber = string.Empty;
                        IsQuiltsAdd = true;
                        AddQuiltPallet(param);
                    }
                    else
                    {
                        IsQuiltsAdd = false;
                        //toast.LongAlert("No scan result found");
                    }
                };
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        });

        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        var popUppage = new AccessWarningPopupPage();
                        await PopupNavigation.Instance.PushAsync(popUppage);
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                }
            }
            return status;
        }
        public ICommand ToggleSearchNotFoundPopupCommand => new Command(() =>
        {
            IsSearchNotFoundIsVisible = false;
        });

        #endregion
    }
}
