﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class ForgotPasswordPageViewModel : ObservableObjects
    {
        #region Constructor
        public ForgotPasswordPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }
        private bool _isForgotPassword;
        public bool IsForgotPassword
        {
            get { return _isForgotPassword; }
            set
            {
                _isForgotPassword = value;
                OnPropertyChanged();
            }
        }
        private string _email;
        public string Email
        {
            get { return _email; }
            set
            {
                _email = value;

                OnPropertyChanged(nameof(Email));
            }
        }
        private string _message;
        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value;
                OnPropertyChanged();
            }
        }
        private bool _isButtonEnabled;
        public bool IsButtonEnabled
        {
            get
            {
                return _isButtonEnabled;
            }
            set
            {
                _isButtonEnabled = value;
            }
        }
        internal void IsAllEntriesFilled()
        {
            if (!string.IsNullOrEmpty(Email) && EmailValid)
            {
                IsForgotPassword = true;
            }
            else
            {
                IsForgotPassword = false;
            }
        }
        private bool _isForgotPasswordPopupIsVisible;
        public bool IsForgotPasswordPopupIsVisible
        {
            get { return _isForgotPasswordPopupIsVisible; }
            set
            {
                _isForgotPasswordPopupIsVisible = value;
                OnPropertyChanged();
            }
        }
        private string _lblEmailError;
        public string LblEmailError
        {
            get
            {
                return _lblEmailError;
            }
            set
            {
                _lblEmailError = value;
                OnPropertyChanged();
            }
        }
        private bool _lblEmailErrorIsVisible;
        public bool LblEmailErrorIsVisible
        {
            get { return _lblEmailErrorIsVisible; }
            set
            {
                _lblEmailErrorIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _emailValid;

        public bool EmailValid
        {
            get
            { return _emailValid; }
            set
            {
                _emailValid = value;
                OnPropertyChanged();
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }


        #endregion
        #region Commands
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync(false);
        });
        public ICommand SendVerificationEmailCommand => new Command(async () =>
        {
            IsBusy = true;
            try
            {
                if (EmailValid && !string.IsNullOrEmpty(Email))
                {
                    var Details = new ForgotPasswordPageModel()
                    {
                        email = Email.Trim(),

                    };
                    var forgotpassword = "/api/forgot-password?email=" + Details.email;
                    var response = await new ApiData().PostData<ForgotPasswordPageResponseModel>(forgotpassword, true);
                    if (response != null)
                    {
                        if (response.statusCode == 200 && response != null)
                        {
                            var page = new ForgotPasswordPagePopup();
                            await PopupNavigation.Instance.PushAsync(page);
                            await Task.Delay(2000);
                            await App.Current.MainPage.Navigation.PopAsync();
                            await PopupNavigation.Instance.PopAsync();
                        }
                        else
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                    else
                    {
                        toast.ShortAlert("Something went wrong!");
                    }

                }
            }
            catch (Exception)
            {
                toast.LongAlert("Things went wrong!");
            }
            IsBusy = false;
        });

        public ICommand ToggleForgotPopupCommand => new Command(async () =>
        {
            await PopupNavigation.Instance.PopAsync();

        });
        #endregion
    }
}
