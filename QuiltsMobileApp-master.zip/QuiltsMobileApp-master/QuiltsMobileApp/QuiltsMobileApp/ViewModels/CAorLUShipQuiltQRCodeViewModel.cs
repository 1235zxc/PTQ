﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class CAorLUShipQuiltQRCodeViewModel : ObservableObjects
    {

        #region Constructor
        public CAorLUShipQuiltQRCodeViewModel(Xamarin.Forms.INavigation navigation)
        {
            Navigation = navigation;
            SelectAndClear = "Select All";
        }

        #endregion

        #region Methods
        public async Task<string> AddQuiltPallet(string serialNumber)
        {
            try
            {
                if (IsQuiltAdd && !string.IsNullOrEmpty(serialNumber))
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        string textTrimmed = String.Concat(serialNumber.Where(c => !Char.IsWhiteSpace(c)));
                        List<string> stringlist = textTrimmed.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        var model = new QuiltPalletRequestModel
                        {
                            serialNumbers = stringlist,
                            individualQuiltsOnly = false,
                            customerDetailsRequired = false,
                            individualQuiltPallets = false
                        };
                        var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                        if (AppStaticData.IsMockPalletCreated)
                        {
                            var response = await new ApiData().PostDataNew<MockPalletDataResponseModel>(QandPurl, model, true);

                            if (response != null)
                            {
                                if (response.statusCode == 200 && response.data != null)
                                {
                                    var listdata = response.data;
                                    for (int i = 0; i < listdata.Count; i++)
                                    {

                                        bool containsItemP = MockPlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                        if (containsItemP == false)
                                        {
                                            MockPlist.Add(listdata[i]);
                                            EnteredQuiltOrPalletSrlNumber = String.Empty;
                                            IsQuiltAdd = false;
                                        }
                                        else
                                        {
                                            toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                        }
                                    }
                                    MockPalletforUpdate = MockPlist;
                                    AppStaticData.IsMockPalletCreated = false;
                                    IsSelect = true;
                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        toast.LongAlert(response.message);
                                    }
                                }
                            }
                            else
                            {
                                toast.ShortAlert("Something went wrong!");
                            }
                        }
                        else
                        {
                            var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);

                            if (response != null)
                            {
                                if (response.statusCode == 200 && response.data != null)
                                {
                                    var listdata = response.data;
                                    for (int i = 0; i < listdata.Count; i++)
                                    {

                                        bool containsItemP = QPlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                        if (containsItemP == false)
                                        {
                                            if (listdata[i].quilts == null)
                                            {
                                                listdata[i].PlusIconVisibleOrNot = false;

                                            }
                                            else
                                            {
                                                listdata[i].PlusIconVisibleOrNot = true;
                                            }
                                            QPlist.Add(listdata[i]);
                                            EnteredQuiltOrPalletSrlNumber = String.Empty;
                                        }
                                        else
                                        {
                                            toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                        }
                                    }
                                    QuiltPalletforUpdate = QPlist;
                                    IsSelect = true;
                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        toast.LongAlert(response.message);
                                    }
                                }
                            }
                            else
                            {
                                toast.ShortAlert("Something went wrong!");
                            }
                        }

                        IsBusy = false;
                    }
                    else
                    {
                        toast.LongAlert("No internet access!");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }

            return string.Empty;
        }
        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        var popUppage = new AccessWarningPopupPage();
                        await PopupNavigation.Instance.PushAsync(popUppage);
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                }
            }
            return status;
        }

        #endregion

        #region Properties
        public INavigation Navigation { get; set; }

        private bool _IsScanQRCodePopupIsVisible;
        public bool IsScanQRCodePopupIsVisible
        {
            get
            {
                return _IsScanQRCodePopupIsVisible;

            }
            set
            {
                _IsScanQRCodePopupIsVisible = value;
                OnPropertyChanged();
            }
        }



        private bool _isSelect;
        public bool IsSelect
        {
            get { return _isSelect; }
            set
            {
                _isSelect = value;
                OnPropertyChanged();
            }
        }
        private bool _IsShipQuilt;
        public bool IsShipQuilt
        {
            get { return _IsShipQuilt; }
            set
            {
                _IsShipQuilt = value;
                OnPropertyChanged();
            }
        }
        private bool _isQuiltAdd;
        public bool IsQuiltAdd
        {
            get { return _isQuiltAdd; }
            set
            {
                _isQuiltAdd = value;
                OnPropertyChanged();
            }
        }
        private string _entrquiltpalletSrlNumb;
        public string EnteredQuiltOrPalletSrlNumber
        {
            get { return _entrquiltpalletSrlNumb; }
            set
            {
                _entrquiltpalletSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltOrPalletSrlNumber));
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        private ObservableCollection<PalletQuiltDataResponseModel> _quiltpalltlist;

        public ObservableCollection<PalletQuiltDataResponseModel> QuiltPalletforUpdate
        {
            get { return _quiltpalltlist; }
            set
            {
                _quiltpalltlist = value;
                OnPropertyChanged(nameof(QuiltPalletforUpdate));
            }
        }

        private ObservableCollection<MockPalletDataResponseModel> _mockpalltlist;
        public ObservableCollection<MockPalletDataResponseModel> MockPalletforUpdate
        {
            get { return _mockpalltlist; }
            set
            {
                _mockpalltlist = value;
                OnPropertyChanged(nameof(MockPalletforUpdate));
            }
        }
        public List<string> ShipQPlist = new List<string>();
        public ObservableCollection<PalletQuiltDataResponseModel> QPlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public ObservableCollection<MockPalletDataResponseModel> MockPlist = new ObservableCollection<MockPalletDataResponseModel>();

        private string _selectAndclear = "Select All";
        public string SelectAndClear
        {
            get { return _selectAndclear; }
            set { _selectAndclear = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }
        private ObservableCollection<ShipQuiltListDetailPageModel> _shipQuiltLists;
        public ObservableCollection<ShipQuiltListDetailPageModel> ShipQuiltLists
        {
            get { return _shipQuiltLists; }
            set { _shipQuiltLists = value; OnPropertyChanged(); }
        }
        ShipQuiltListDetailPageModel shipQuiltListDetail = new ShipQuiltListDetailPageModel();
        #endregion

        #region Commands
        public ICommand AddButtonCommand => new Command(async () =>
        {
            await AddQuiltPallet(EnteredQuiltOrPalletSrlNumber);
        });
        public ICommand GotoShipQuiltDetailPageCommand => new Command(async () =>
        {
            if (IsShipQuilt)
            {
                ShipQPlist.Clear();
                if (QuiltPalletforUpdate != null)
                {
                    for (int i = 0; i < QuiltPalletforUpdate.Count; i++)
                    {
                        if (QuiltPalletforUpdate[i].IsCheckboxChecked)
                        {
                            ShipQPlist.Add(QuiltPalletforUpdate[i].serialNumber);
                        }
                    }
                    await Navigation.PushAsync(new ShipQuiltDetailPage(ShipQPlist));
                }
                else
                {
                    toast.LongAlert("Please add quilts/pallets first");
                }

            }

        });
        public ICommand GotoCreateQRCodePageCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new CAorLUCreatePalletPage());
        });
        public ICommand ToggleScanQRCodePopupCommand => new Command(() =>
        {
            IsScanQRCodePopupIsVisible = false;
        });
        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                string param = String.Empty;
                var page = new ScanQRCodePopupPage();

                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    page.Action += async (sender, stringparameter) =>
                    {
                        param = stringparameter;
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }

                page.Disappearing += async (c, d) =>
                {
                    if (!string.IsNullOrEmpty(param))
                    {
                        EnteredQuiltOrPalletSrlNumber = string.Empty;
                        IsQuiltAdd = true;
                        await AddQuiltPallet(param);
                    }
                    else
                    {
                        IsQuiltAdd = false;
                    }
                };
            }
            catch (Exception)
            {

            }
        });



        public ICommand SelectAllCommand => new Command(() =>
        {
            if (IsSelect)
            {
                try
                {
                    if (SelectAndClear == "Select All")
                    {
                        if (QuiltPalletforUpdate != null || MockPalletforUpdate != null)
                        {
                            try
                            {
                                if (QuiltPalletforUpdate != null)
                                {
                                    if (QuiltPalletforUpdate.Count != 0)
                                    {
                                        for (int i = 0; i < QuiltPalletforUpdate.Count; i++)
                                        {
                                            QuiltPalletforUpdate[i].IsCheckboxChecked = true;
                                        }

                                    }

                                }
                                if (MockPalletforUpdate != null)
                                {
                                    if (MockPalletforUpdate.Count != 0)
                                    {
                                        for (int i = 0; i < MockPalletforUpdate.Count; i++)
                                        {
                                            MockPalletforUpdate[i].IsCheckboxChecked = true;
                                        }
                                    }

                                }
                                SelectAndClear = "Clear All";

                            }
                            catch (Exception ex)
                            {

                            }

                        }
                        else
                        {
                            toast.LongAlert("Please Add quilts/pallets first");
                        }
                    }
                    else
                    {
                        if (QuiltPalletforUpdate != null && QuiltPalletforUpdate.Count != 0)
                        {
                            for (int i = 0; i < QuiltPalletforUpdate.Count; i++)
                            {
                                QuiltPalletforUpdate[i].IsCheckboxChecked = false;
                            }
                            for (int i = 0; i < MockPalletforUpdate.Count; i++)
                            {
                                MockPalletforUpdate[i].IsCheckboxChecked = false;
                            }
                            IsSelect = false;
                            SelectAndClear = "Select All";
                        }
                        else
                        {
                            IsSelect = false;
                            SelectAndClear = "Select All";
                        }
                    }

                }
                catch (Exception ex)
                {

                }
            }
        });
        public ICommand BackButtonCommand => new Command(async () =>
        {

            await Navigation.PopAsync();
        });

        #endregion

    }

}
