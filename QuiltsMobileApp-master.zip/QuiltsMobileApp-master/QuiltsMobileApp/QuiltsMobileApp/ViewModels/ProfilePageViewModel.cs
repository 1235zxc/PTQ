﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;


namespace QuiltsMobileApp.ViewModels
{
    public class ProfilePageViewModel : ObservableObjects
    {
        #region Constructor
        public ProfilePageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            UserType = User_secrets.User_type;
            GetUserType();
            OnStart();
            InternetConnectivity();
        }

        #endregion

        #region methods
        private async void OnStart()
        {
            await GetProfileDetail();
        }
        private void InternetConnectivity()
        {
            Connectivity.ConnectivityChanged += Connectivity_ConnectivityChanged;
        }
        private async void Connectivity_ConnectivityChanged(object sender, ConnectivityChangedEventArgs e)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                if (User == null)
                {
                    await GetProfileDetail();
                }
            }
            else
            {
                NoInternetConnected = true;
                int _countSeconds = 3;
                Device.StartTimer(TimeSpan.FromSeconds(1), () =>
                {
                    _countSeconds--;
                    if (_countSeconds == 0)
                    {
                        NoInternetConnected = false;
                    }
                    return Convert.ToBoolean(_countSeconds);
                });
            }
        }

        public async Task<string> GetProfileDetail()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                var response = await new ApiData().GetData<ProfilePageModel>("/api/User/profile", true);
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        User = response.data;

                        if (string.IsNullOrEmpty(User.location.name))
                        {
                            Location = "Location not availble";
                        }
                        else
                        {
                            Location = response.data.location.name;
                        }
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                    }
                }
                else
                {
                    toast.ShortAlert("Something went wrong!");
                }
                IsBusy = false;
            }
            else
            {
                toast.LongAlert("No internet access!");
            }

            return string.Empty;
        }

        public void GetUserType()
        {
            IsBusy = true;
            if (UserType == "Master Admin" || UserType == "Warehouse Admin")
            {
                IsLocationVisible = false;
            }
            else if (UserType == "Company Admin" || UserType == "Location User")
            {
                IsLocationVisible = true;
            }
            else
            {
                IsLocationVisible = false;
            }
            IsBusy = false;

        }
        #endregion

        #region Properties
        public INavigation Navigation { get; set; }

        private ProfilePageModel _user;
        public ProfilePageModel User
        {
            get
            {
                return _user;
            }
            set
            {
                _user = value;
                OnPropertyChanged("User");
            }
        }

        private bool isBusy;
        public bool IsBusy
        {
            get { return isBusy; }
            set { isBusy = value; OnPropertyChanged(); }
        }

        private string _location;
        public string Location
        {
            get
            {
                return _location;
            }
            set
            {
                _location = value;
                OnPropertyChanged();
            }

        }

        private bool _isEditPopupVisible;
        public bool IsEditPopupbupVisible
        {
            get
            {
                return _isEditPopupVisible;
            }
            set
            {
                _isEditPopupVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isLogoutPopupIsVisible;
        public bool IsLogoutPopupIsVisible
        {
            get
            {
                return _isLogoutPopupIsVisible;
            }
            set
            {
                _isLogoutPopupIsVisible = value;
                OnPropertyChanged();
            }
        }

        private string _userType;
        public string UserType
        {
            get
            {
                return _userType;
            }
            set
            {
                _userType = value;
                OnPropertyChanged(nameof(UserType));
            }
        }

        private bool _isLocVisible;
        public bool IsLocationVisible
        {
            get
            {
                return _isLocVisible;
            }
            set
            {
                _isLocVisible = value;
            }
        }

        private bool _noInternet;
        public bool NoInternetConnected
        {
            get { return _noInternet; }
            set { _noInternet = value; OnPropertyChanged(nameof(NoInternetConnected)); }
        }

        #endregion

        #region Commands

        public ICommand EditProfileThreeDotCommand => new Command(() =>
        {
            IsEditPopupbupVisible = !IsEditPopupbupVisible;
        });

        public ICommand GoToEditProfilePageCommand => new Command(async () =>
        {
            IsEditPopupbupVisible = false;
            if (User != null)
            {
                await Navigation.PushAsync(new EditProfilePage(User));
            }
        });
        public ICommand GoToChangePasswordPageCommand => new Command(async () =>
        {
            IsEditPopupbupVisible = false;
            await Navigation.PushAsync(new ChangepasswordPage());
        });
        public ICommand LogoutPopupCommand => new Command(async () =>
        {
            IsEditPopupbupVisible = false;

            bool param = false;
            var page = new LogoutPopupPage();
            page.LogoutAction += async (sender, boolparameter) =>
            {
                param = boolparameter;
            };
            await PopupNavigation.Instance.PushAsync(page);

            page.Disappearing += (c, d) =>
            {
                if (param)
                {
                    SecureStorage.RemoveAll();
                    Preferences.Clear();
                    Application.Current.MainPage = new NavigationPage(new OnBoardingPage());
                }
            };

        });

        public ICommand ToggleLogoutCancelPopupCommand => new Command(async () =>
        {
            await PopupNavigation.Instance.PopAsync();
        });
        public ICommand TogglePopupCommand => new Command(() =>
        {
            IsEditPopupbupVisible = false;
        });

        #endregion


    }
}
