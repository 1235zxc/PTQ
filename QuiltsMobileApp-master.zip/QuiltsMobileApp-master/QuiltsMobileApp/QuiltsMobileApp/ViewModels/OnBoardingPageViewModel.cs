﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using System;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class OnBoardingPageViewModel : ObservableObjects
    {
        #region Constructor
        public OnBoardingPageViewModel(INavigation navigation)
        {
            Navigation = navigation;
        }
        #endregion

        #region Methods

        #endregion

        #region Properties
        public INavigation Navigation { get; set; }

        private string _email;
        public string emailId
        {
            get { return _email; }
            set
            {
                _email = value;
                ImageVisibleEmail = "BlueUser";
                OnPropertyChanged(nameof(emailId));
            }
        }

        private string _password;
        public string password
        {
            get { return _password; }
            set
            {
                _password = value;
                ImageVisiblePassword = "BlueLock";
                OnPropertyChanged(nameof(password));
            }
        }

        private string _imageVisibleemail = "grayUser";
        public string ImageVisibleEmail
        {
            get { return _imageVisibleemail; }
            set { _imageVisibleemail = value; OnPropertyChanged(); }
        }

        private string _imageVisiblepassword = "grayLock";
        public string ImageVisiblePassword
        {
            get { return _imageVisiblepassword; }
            set { _imageVisiblepassword = value; OnPropertyChanged(); }
        }

        private string _imageVisible = "Eye.png";
        public string ImageVisible
        {
            get { return _imageVisible; }
            set { _imageVisible = value; OnPropertyChanged(); }
        }

        private bool _isLoggedIn;
        public bool IsLoggedIn
        {
            get { return _isLoggedIn; }
            set
            {
                _isLoggedIn = value;
                OnPropertyChanged();
            }
        }

        private bool isBusy;
        public bool IsBusy
        {
            get { return isBusy; }
            set { isBusy = value; OnPropertyChanged(); }
        }

        private bool _isButtonEnabled;
        public bool IsButtonEnabled
        {
            get
            {
                return _isButtonEnabled;
            }
            set
            {
                _isButtonEnabled = value;
            }
        }

        private bool _isemailValid;
        public bool IsEmailValid
        {
            get { return _isemailValid; }
            set { _isemailValid = value; OnPropertyChanged(nameof(IsEmailValid)); }
        }

        private bool _ispassValid;
        public bool IsPasswordValid
        {
            get { return _ispassValid; }
            set { _ispassValid = value; OnPropertyChanged(nameof(IsPasswordValid)); }
        }

        private bool _emailfrbrdrclr;
        public bool EmailFrameBorderColor
        {
            get { return _emailfrbrdrclr; }
            set { _emailfrbrdrclr = value; OnPropertyChanged(); }
        }

        private bool _passfrmbrdrclr;

        public bool PasswordFrameBorderColor
        {
            get { return _passfrmbrdrclr; }
            set { _passfrmbrdrclr = value; OnPropertyChanged(); }
        }

        internal void IsAllEntriesFilled()
        {
            if (!string.IsNullOrEmpty(emailId) && !string.IsNullOrEmpty(password))
            {
                if (IsEmailValid && IsPasswordValid)
                {
                    IsLoggedIn = true;
                }
                else
                {
                    IsLoggedIn = false;
                }
            }
            else
            {
                IsLoggedIn = false;
            }
        }

        private bool _isPasswordVisible = true;
        public bool IsPasswordVisible
        {
            get { return _isPasswordVisible; }
            set { _isPasswordVisible = value; OnPropertyChanged(); }
        }

        private string _lblEmailError;
        public string LblEmailError
        {
            get
            {
                return _lblEmailError;
            }
            set
            {
                _lblEmailError = value;
                OnPropertyChanged();
            }
        }

        private string _lblPasswordError;
        public string LblPasswordError { get { return _lblPasswordError; } set { _lblPasswordError = value; OnPropertyChanged(); } }


        #endregion

        #region Commands
        public ICommand PasswordShowHideCommand => new Command(() =>
        {
            if (IsPasswordVisible)
            {
                IsPasswordVisible = false;

                ImageVisible = "Hide.png";
            }
            else
            {
                IsPasswordVisible = true;
                ImageVisible = "Eye.png";
            }
        });
        public ICommand ForgotPasswordCommand => new Command(async () =>
        {
            await Navigation.PushAsync(new ForgotPasswordPage(), false);
            // await RichNavigationService.PushAsync(new ForgotPasswordPage(), typeof(ForgotPasswordPage));

        });
        public ICommand LoginCommand => new Command(async () =>
        {
            try
            {
                if (IsEmailValid && IsPasswordValid && !string.IsNullOrEmpty(emailId) && !string.IsNullOrEmpty(password))
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        var loginDetails = new LoginPageModel()
                        {
                            emailId = emailId.Trim(),
                            password = password,
                        };

                        var response = await new ApiData().PostData<UserResponseModel>("/api/login", loginDetails, false);

                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                User_secrets.User_Id = response.data.userId;
                                if (response.data.locationId != null)
                                {
                                    User_secrets.Location_Id = (int)response.data.locationId;
                                }
                                User_secrets.SetAccessToken(response.data.token);
                                User_secrets.User_type = response.data.roles[0];
                                User_secrets.User_Email = response.data.email;
                                User_secrets.UserFull_Name = response.data.userFullName;
                                if (response.data.companyId != null && response.data.companyId != 0)
                                {
                                    User_secrets.Company_Id = (int)response.data.companyId;
                                }
                                if (!string.IsNullOrEmpty(User_secrets.User_type))
                                {
                                    Application.Current.MainPage = new NavigationPage(new TabbedPage1());
                                }
                            }
                            else
                            {
                                IsBusy = false;
                                if (Device.RuntimePlatform == Device.Android)
                                {
                                    toast.CustomLongAlert(response.message);
                                }
                                else
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                        else
                        {
                            IsBusy = false;
                            toast.ShortAlert("Something went wrong.");
                        }
                    }
                    else
                    {
                        toast.ShortAlert("No internet access!!");
                    }
                }
            }
            catch (Exception ex)
            {
                IsBusy = false;
                toast.ShortAlert("Things went wrong!");
            }

        });
        #endregion

    }

}
