﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace QuiltsMobileApp.ViewModels
{
    public class ShipQuiltDetailPageViewModel : ObservableObjects
    {
        #region Constructor

        //MasterAdmin

        public ShipQuiltDetailPageViewModel(INavigation navigation, List<string> shipQPlist, string orderNumber)
        {
            Navigation = navigation;
            UserType = User_secrets.User_type;
            OrderNumber = orderNumber;
            ShipQPList = shipQPlist;
            LocationName = "Location";
            ETAName = "ETA";
            Carrier = "Carrier";
            ShipmentName = "Shipment Type";
            LocationColor = "#8FABC9";
            ShipmentColor = "#8FABC9";
            CarrierColor = "#8FABC9";
            EtaColor = "#8FABC9";
            MAorLUOrderNumberVisible = true;
            ShipmentNumberInputFieldVisible = true;
        }
        //CompanyAdmin

        public ShipQuiltDetailPageViewModel(INavigation navigation, List<string> shipQPlist)
        {
            Navigation = navigation;
            ShipQPList = shipQPlist;
            UserType = User_secrets.User_type;
            CompanyId = (int)User_secrets.Company_Id;
            LocationName = "Location";
            ETAName = "ETA";
            Carrier = "Carrier";
            ShipmentName = "Shipment Type";
            LocationColor = "#8FABC9";
            ShipmentColor = "#8FABC9";
            CarrierColor = "#8FABC9";
            EtaColor = "#8FABC9";
            MAorLUOrderNumberVisible = false;
            ShipmentNumberInputFieldVisible = true;
        }
        #endregion

        #region Properties
        private ObservableCollection<ShipQuiltLocationPageModel> _locatonCollection;
        public ObservableCollection<ShipQuiltLocationPageModel> LocatonCollection
        {
            get
            {
                return _locatonCollection;
            }
            set
            {
                _locatonCollection = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<ShipmentETAResponsePageModel> _eTACollection;
        public ObservableCollection<ShipmentETAResponsePageModel> ETACollection
        {
            get
            {
                return _eTACollection;
            }
            set
            {
                _eTACollection = value;
                OnPropertyChanged();
            }
        }

        private ObservableCollection<ShipmentTypeModel> _shipmentTypesCollection;
        public ObservableCollection<ShipmentTypeModel> ShipmentTypesCollection
        {
            get { return _shipmentTypesCollection; }
            set { _shipmentTypesCollection = value; OnPropertyChanged(); }
        }

        private ObservableCollection<ShipQuiltCarrierPageModel> _carrierCollection;
        public ObservableCollection<ShipQuiltCarrierPageModel> CarrierCollection
        {
            get
            {
                return _carrierCollection;
            }
            set
            {
                _carrierCollection = value;
                OnPropertyChanged();
            }
        }

        private int _locationListHeight;
        public int LocationListHeight
        {
            get { return _locationListHeight; }
            set
            {
                _locationListHeight = value;
                OnPropertyChanged(nameof(LocationListHeight));
            }
        }

        private int _carrierListHeight;
        public int CarrierListHeight
        {
            get { return _carrierListHeight; }
            set
            {
                _carrierListHeight = value;
                OnPropertyChanged(nameof(CarrierListHeight));
            }
        }

        private int _shipmentListHeight;
        public int ShipmentListHeight
        {
            get { return _shipmentListHeight; }
            set
            {
                _shipmentListHeight = value;
                OnPropertyChanged(nameof(ShipmentListHeight));
            }
        }

        private int _eTAListHeight;
        public int ETAListHeight
        {
            get { return _eTAListHeight; }
            set
            {
                _eTAListHeight = value;
                OnPropertyChanged(nameof(ETAListHeight));
            }
        }

        private bool _isShip;
        public bool IsShip
        {
            get { return _isShip; }
            set
            {
                _isShip = value;
                OnPropertyChanged();
            }
        }

        private bool _locationListIsVisible;
        public bool LocationListIsVisible
        {
            get { return _locationListIsVisible; }
            set
            {
                _locationListIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _eTAListIsVisible;
        public bool ETAListIsVisible
        {
            get { return _eTAListIsVisible; }
            set
            {
                _eTAListIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _shipmentTypeListIsVisible;
        public bool ShipmentTypeListIsVisible
        {
            get { return _shipmentTypeListIsVisible; }
            set
            {
                _shipmentTypeListIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _carrierIsVisible;
        public bool CarrierIsVisible
        {
            get { return _carrierIsVisible; }
            set
            {
                _carrierIsVisible = value;
                OnPropertyChanged();
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }

        private ShipQuiltLocationPageModel _shipQuilt;
        public ShipQuiltLocationPageModel ShipQuilt
        {
            get { return _shipQuilt; }
            set
            {
                _shipQuilt = value; OnPropertyChanged();
            }
        }

        private ShipmentETAResponsePageModel _eTA;
        public ShipmentETAResponsePageModel ETA
        {
            get { return _eTA; }
            set
            {
                _eTA = value; OnPropertyChanged();
            }
        }

        private ShipmentTypeModel _shipmentType;
        public ShipmentTypeModel ShipmentType
        {
            get { return _shipmentType; }
            set
            {
                _shipmentType = value;
                OnPropertyChanged();
            }
        }

        private ShipQuiltCarrierPageModel _carrierPage;
        public ShipQuiltCarrierPageModel CarrierPage
        {
            get { return _carrierPage; }
            set
            {
                _carrierPage = value; OnPropertyChanged();
            }
        }

        private string _locationName;
        public string LocationName
        {
            get
            {
                return _locationName;
            }
            set
            {
                _locationName = value; OnPropertyChanged();
            }
        }

        private string _shipmentName;
        public string ShipmentName
        {
            get { return _shipmentName; }
            set
            {
                _shipmentName = value;
                OnPropertyChanged();
            }
        }

        private string _shipmentNum;
        public string ShipmentNumber
        {
            get { return _shipmentNum; }
            set { _shipmentNum = value; OnPropertyChanged(); }
        }


        private string _eTAName;
        public string ETAName
        {
            get
            {
                return _eTAName;
            }
            set
            {
                _eTAName = value; OnPropertyChanged();
            }
        }

        private string _carrier;
        public string Carrier
        {
            get
            {
                return _carrier;
            }
            set
            {
                _carrier = value; OnPropertyChanged();
            }
        }

        private string _proNumber;
        public string ProNumber
        {
            get { return _proNumber; }
            set { _proNumber = value; OnPropertyChanged(nameof(ProNumber)); }
        }

        private bool _maOrdervisible;

        public bool MAorLUOrderNumberVisible
        {
            get { return _maOrdervisible; }
            set { _maOrdervisible = value; OnPropertyChanged(); }
        }
        private bool _shipmentInputvisible;

        public bool ShipmentNumberInputFieldVisible
        {
            get { return _shipmentInputvisible; }
            set { _shipmentInputvisible = value; OnPropertyChanged(); }
        }

        public string UserType { get; set; }
        public string OrderNumber { get; set; }
        public int CompanyId { get; set; }
        private List<string> ShipQPList { get; set; }

        public ResponseModelNew<ShipQuiltCarrierPageModel> response { get; private set; }
        public ResponseModelNew<ShipQuiltLocationPageModel> LocationRsp { get; private set; }

        public INavigation Navigation { get; set; }

        private string _LocColor;
        public string LocationColor
        {
            get { return _LocColor; }
            set { _LocColor = value; OnPropertyChanged(); }
        }

        private string _shipMentColor;
        public string ShipmentColor
        {
            get { return _shipMentColor; }
            set { _shipMentColor = value; OnPropertyChanged(); }
        }

        private string _carrierColor;
        public string CarrierColor
        {
            get { return _carrierColor; }
            set { _carrierColor = value; OnPropertyChanged(); }
        }

        private string _etaColor;
        public string EtaColor
        {
            get { return _etaColor; }
            set { _etaColor = value; OnPropertyChanged(); }
        }

        private string _ortherCrName;
        public string OrtherCarrierName
        {
            get { return _ortherCrName; }
            set { _ortherCrName = value; OnPropertyChanged(nameof(OrtherCarrierName)); }
        }

        private bool _isOthercrNameVsbl;
        public bool IsOtherCarrierNameEntryVisible
        {
            get { return _isOthercrNameVsbl; }
            set { _isOthercrNameVsbl = value; OnPropertyChanged(); }
        }


        #endregion

        #region Methods
        public async void GetCarrier()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;

                if (UserType == "Master Admin" || UserType == "Warehouse User")
                {
                    response = await new ApiData().GetDataNew<ShipQuiltCarrierPageModel>("/api/Carrier/preferred?orderNumber=" + OrderNumber, true);

                }
                else
                {
                    response = await new ApiData().GetDataNew<ShipQuiltCarrierPageModel>("/api/Carrier/preferred/" + CompanyId, true);
                    var modelcarrier = new ShipQuiltCarrierPageModel()
                    {
                        id = 0,
                        name = "Other",
                        phoneNumber = null,
                        additionalNotes = null,
                        isPreferred = false,
                        customerId = 0
                    };
                    response.data.Add(modelcarrier);
                }
                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        CarrierIsVisible = true;
                        var Carrier = response.data;
                        if (Carrier != null && Carrier.Count != 0)
                        {
                            Carrier.Last().Seperator = false;
                            CarrierCollection = Carrier;

                            CarrierListHeight = CarrierCollection.Count * 40;
                            if (CarrierCollection.Count > 10)
                            {
                                CarrierListHeight = 200;
                            }
                        }
                        else
                        {
                            CarrierCollection = Carrier;
                            CarrierListHeight = 35;
                        }
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                    }

                }

                IsBusy = false;
            }
        }
        public async void GetLocations()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;

                if (UserType == "Master Admin" || UserType == "Warehouse User")
                {
                    LocationRsp = await new ApiData().GetDataNew<ShipQuiltLocationPageModel>("/api/Locations/GetLocationsByOrderNumber?orderNumber=" + OrderNumber, true);

                }
                else
                {
                    LocationRsp = await new ApiData().GetDataNew<ShipQuiltLocationPageModel>("/api/Locations/GetLocationsByCustomerIdForCompanyUser/" + CompanyId, true);

                }
                if (LocationRsp != null)
                {
                    if (LocationRsp.statusCode == 200 && LocationRsp.data != null)
                    {
                        LocatonCollection = LocationRsp.data;
                        LocationListIsVisible = true;
                        var Loc = LocationRsp.data;
                        if (Loc != null && Loc.Count != 0)
                        {
                            Loc.Last().Seperator = false;
                            LocatonCollection = Loc;
                            LocationListHeight = LocatonCollection.Count * 40;
                            if (LocatonCollection.Count > 10)
                            {
                                LocationListHeight = 200;
                            }

                        }
                        else
                        {
                            LocatonCollection = Loc;
                            LocationListHeight = 35;
                        }
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                }
                IsBusy = false;
            }
        }

        public async void GetETAs()
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                IsBusy = true;
                var response = await new ApiData().GetDataNew<ShipmentETAResponsePageModel>("/api/Generic/shipmentETAs", true);

                if (response != null)
                {
                    if (response.statusCode == 200 && response.data != null)
                    {
                        ETACollection = response.data;
                        ETAListIsVisible = true;
                        var ETA = response.data;
                        if (ETA != null && ETA.Count != 0)
                        {
                            ETA.Last().Seperator = false;
                            ETACollection = ETA;
                            ETAListHeight = ETACollection.Count * 40;
                            if (ETACollection.Count > 10)
                            {
                                ETAListHeight = 200;
                            }
                        }
                        else
                        {
                            ETACollection = ETA;
                            ETAListHeight = 35;
                        }
                    }
                    else
                    {
                        if (response.message != null)
                        {
                            toast.LongAlert(response.message);
                        }
                    }
                }

                IsBusy = false;
            }
        }
        public void GetShipmentTypes()
        {
            IsBusy = true;
            ShipmentTypesCollection = new ObservableCollection<ShipmentTypeModel>();
            ShipmentTypesCollection.Add(new ShipmentTypeModel { id = 1, name = "Protected" });
            ShipmentTypesCollection.Add(new ShipmentTypeModel { id = 2, name = "Reverse" });
            ShipmentTypeListIsVisible = true;
            var shipment = ShipmentTypesCollection;
            if (shipment != null && shipment.Count != 0)
            {
                shipment.Last().Seperator = false;
                ShipmentTypesCollection = shipment;
                ShipmentListHeight = ShipmentTypesCollection.Count * 35;
            }
            else
            {
                ShipmentTypesCollection = shipment;
                ShipmentListHeight = 35;
            }
            IsBusy = false;
        }

        #endregion

        #region Commands
        public ICommand ShipCommand => new Command(async () =>
        {
            if (IsShip)
            {
                if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                {
                    IsBusy = true;

                    if (UserType == "Master Admin" || UserType == "Warehouse User")
                    {
                        var req = new ShipmentRequestPageModel
                        {
                            orderNumber = OrderNumber,
                            customerId = Convert.ToInt32(CompanyId),
                            shipmentTypeId = ShipmentType.id,
                            locationId = ShipQuilt.id,
                            shipmentETAId = ETA.id,
                            carrierId = CarrierPage.id,
                            carrierName = Carrier,
                            inventories = ShipQPList,
                            proNumber = ProNumber,
                            additionalNotes = " ",
                            shipmentNumber = ShipmentNumber
                        };
                        var response = await new ApiData().PostDataNew<ShipmentRequestPageModel>("/api/Shipments", req, true);
                        if (response != null)
                        {
                            if (response.statusCode == 200)
                            {
                                toast.LongAlert(response.message);
                                await Navigation.PopToRootAsync();
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }

                        }
                        else
                        {
                            toast.LongAlert("Something went wrong!");
                        }

                    }
                    else
                    {
                        try
                        {
                            var req = new ShipmentRequestPageModel
                            {
                                orderNumber = OrderNumber,
                                customerId = Convert.ToInt32(CompanyId),
                                shipmentTypeId = ShipmentType.id,
                                locationId = ShipQuilt.id,
                                shipmentETAId = ETA.id,
                                carrierId = CarrierPage.id,
                                carrierName = CarrierPage.name == "Other" ? OrtherCarrierName : Carrier,
                                inventories = ShipQPList,
                                proNumber = ProNumber,
                                additionalNotes = " ",
                                shipmentNumber = ShipmentNumber

                            };
                            var response = await new ApiData().PostDataNew<ShipmentRequestPageModel>("/api/Shipments", req, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200)
                                {
                                    toast.LongAlert(response.message);
                                    await Navigation.PopToRootAsync();

                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        toast.LongAlert(response.message);
                                    }
                                }
                            }

                        }
                        catch (Exception ex)
                        {

                        }
                    }

                    IsBusy = false;
                }
                else
                {
                    toast.LongAlert("No internet access!");
                }

            }

        });
        public ICommand CancelShipmentCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand BackButtonCommand => new Command(async () =>
        {
            await Navigation.PopAsync();
        });
        public ICommand TogglePopupCommand => new Command(async () =>
        {
            LocationListIsVisible = false;
            ETAListIsVisible = false;
            CarrierIsVisible = false;
            ShipmentTypeListIsVisible = false;
        });
        public ICommand SelectLocationNameCommand => new Command(async (obj) =>
        {
            ShipQuilt = obj as ShipQuiltLocationPageModel;
            LocationName = ShipQuilt.name;
            LocationListIsVisible = false;
            LocationColor = "#444444";
            if (LocationName != "Location" && ETAName != "ETA" && Carrier != "Carrier"
                 && ShipmentName != "Shipment Type" && !IsOtherCarrierNameEntryVisible)
            {
                IsShip = true;
            }
            else
            {
                IsShip = false;
            }
        });
        public ICommand SelectLocationTap => new Command(() =>
        {
            GetLocations();
            if (LocatonCollection == null)
            {
                LocationListIsVisible = false;
            }
            else
            {
                LocationListIsVisible = true;

            }
            ETAListIsVisible = false;
            CarrierIsVisible = false;
            ShipmentTypeListIsVisible = false;
        });

        public ICommand SelectETACommand => new Command(async (obj) =>
        {
            ETA = obj as ShipmentETAResponsePageModel;
            ETAName = ETA.name;
            ETAListIsVisible = false;
            EtaColor = "#444444";
            if (LocationName != "Location" && ETAName != "ETA" && Carrier != "Carrier"
                 && ShipmentName != "Shipment Type" && !IsOtherCarrierNameEntryVisible)
            {
                IsShip = true;
            }
            else
            {
                IsShip = false;
            }
        });
        public ICommand SelectETATap => new Command(() =>
        {
            GetETAs();
            if (ETACollection == null)
            {
                ETAListIsVisible = false;
            }
            else
            {
                ETAListIsVisible = true;

            }
            LocationListIsVisible = false;
            CarrierIsVisible = false;
            ShipmentTypeListIsVisible = false;

            if (LocationName != "Location" &&
                ETAName != "ETA" &&
                Carrier != "Carrier" &&
                ShipmentName != "Shipment Type")
            {
                if (IsOtherCarrierNameEntryVisible)
                {
                    if (!string.IsNullOrEmpty(OrtherCarrierName))
                    {
                        IsShip = true;
                    }
                    else
                    {
                        IsShip = false;
                    }
                }
                else
                {
                    IsShip = true;
                }
            }
        });

        public ICommand SelectShipmentTypeCommand => new Command(async (obj) =>
        {
            ShipmentType = obj as ShipmentTypeModel;
            ShipmentName = ShipmentType.name;
            ShipmentTypeListIsVisible = false;
            ShipmentColor = "#444444";
            if (LocationName != "Location" && ETAName != "ETA" && Carrier != "Carrier"
                  && ShipmentName != "Shipment Type" && !IsOtherCarrierNameEntryVisible)
            {
                IsShip = true;
            }
            else
            {
                IsShip = false;
            }
        });
        public ICommand SelectShipmentTypeTap => new Command(() =>
        {
            GetShipmentTypes();
            if (ShipmentTypesCollection == null)
            {
                ShipmentTypeListIsVisible = false;
            }
            else
            {
                ShipmentTypeListIsVisible = true;

            }
            LocationListIsVisible = false;
            ETAListIsVisible = false;
            CarrierIsVisible = false;
        });

        public ICommand SelectCarrierCommand => new Command(async (obj) =>
        {
            CarrierPage = obj as ShipQuiltCarrierPageModel;
            Carrier = CarrierPage.name;
            if (Carrier == "Other")
            {
                IsOtherCarrierNameEntryVisible = true;
            }
            else
            {
                IsOtherCarrierNameEntryVisible = false;
            }
            CarrierIsVisible = false;
            CarrierColor = "#444444";
            if (LocationName != "Location" && ETAName != "ETA" && Carrier != "Carrier"
                && ShipmentName != "Shipment Type" && !IsOtherCarrierNameEntryVisible)
            {
                IsShip = true;
            }
            else
            {
                IsShip = false;
            }
        });
        public ICommand SelectCarrierTap => new Command(() =>
        {
            GetCarrier();
            if (CarrierCollection == null)
            {
                CarrierIsVisible = false;
            }
            else
            {
                CarrierIsVisible = true;

            }
            LocationListIsVisible = false;
            ETAListIsVisible = false;
            ShipmentTypeListIsVisible = false;

        });

        #endregion

    }
}
