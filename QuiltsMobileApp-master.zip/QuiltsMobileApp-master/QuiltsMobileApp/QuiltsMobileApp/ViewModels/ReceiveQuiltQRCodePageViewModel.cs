﻿using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.Views;
using QuiltsMobileApp.Views.CustomViews;
using Rg.Plugins.Popup.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace QuiltsMobileApp.ViewModels
{
    public class ReceiveQuiltQRCodePageViewModel : ObservableObjects
    {

        #region Constructor
        public ReceiveQuiltQRCodePageViewModel(INavigation navigation)
        {
            Navigation = navigation;
            UserType = User_secrets.User_type;
        }

        #endregion

        #region Methods
        private async Task AddQuiltPallet(string enteredQuiltOrPalletSrlNumber)
        {
            try
            {
                if (IsQuiltAdd && !string.IsNullOrEmpty(enteredQuiltOrPalletSrlNumber))
                {
                    if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                    {
                        IsBusy = true;
                        string textTrimmed = String.Concat(enteredQuiltOrPalletSrlNumber.Where(c => !Char.IsWhiteSpace(c)));
                        List<string> stringlist = textTrimmed.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries).ToList();
                        var model = new QuiltPalletRequestModel
                        {
                            serialNumbers = stringlist,
                            individualQuiltsOnly = false,
                            customerDetailsRequired = true,
                            individualQuiltPallets = false
                        };
                        var QandPurl = "/api/Quilts/GetQuiltPalletDetailsBySerialNumber";
                        var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, model, true);

                        if (response != null)
                        {
                            if (response.statusCode == 200 && response.data != null)
                            {
                                var listdata = response.data;
                                for (int i = 0; i < listdata.Count; i++)
                                {
                                    OrderId = Convert.ToInt32(listdata[i].orderId);
                                    CustomerId = Convert.ToInt32(listdata[i].customerId);
                                    bool containsItemP = QPlist.Any(item => item.serialNumber.ToLower().Contains(listdata[i].serialNumber.ToLower()));
                                    if (containsItemP == false)
                                    {
                                        if (listdata[i].quilts == null)
                                        {
                                            listdata[i].PlusIconVisibleOrNot = false;

                                        }
                                        else
                                        {
                                            listdata[i].PlusIconVisibleOrNot = true;
                                        }
                                        QPlist.Add(listdata[i]);
                                        EnteredQuiltOrPalletSrlNumber = String.Empty;
                                        IsQuiltAdd = false;
                                    }
                                    else
                                    {
                                        toast.ShortAlert(listdata[i].serialNumber + " already added!");
                                    }
                                }
                                QuiltPalletforReceive = QPlist;
                                IsSelect = true;
                            }
                            else
                            {
                                if (response.message != null)
                                {
                                    toast.LongAlert(response.message);
                                }
                            }
                        }
                        else
                        {
                            toast.ShortAlert("Something went wrong!");
                        }
                        IsBusy = false;
                    }
                    else
                    {
                        toast.LongAlert("No internet access!");
                    }
                }
            }
            catch (Exception)
            {
                toast.ShortAlert("Things went wrong!");
            }
        }
        public async Task<PermissionStatus> CheckAndRequestCameraPermission()
        {
            PermissionStatus status;
            if (Device.RuntimePlatform == Device.Android)
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;

                bool shouldShow = await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Camera);
                if (shouldShow)
                {
                    status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                    if (status == PermissionStatus.Granted)
                        return status;
                    else if (status == PermissionStatus.Denied)
                    {
                        var popUppage = new AccessWarningPopupPage();
                        await PopupNavigation.Instance.PushAsync(popUppage);
                        return status;
                    }
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                    return status;
                }
            }
            else
            {
                status = await CrossPermissions.Current.CheckPermissionStatusAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                status = await CrossPermissions.Current.RequestPermissionAsync<CameraPermission>();
                if (status == PermissionStatus.Granted)
                    return status;
                else if (status == PermissionStatus.Denied)
                {
                    var popUppage = new AccessWarningPopupPage();
                    await PopupNavigation.Instance.PushAsync(popUppage);
                }
            }
            return status;
        }

        #endregion

        #region Properties
        private bool _isReceiveQuilt;
        public bool IsReceiveQuilt
        {
            get { return _isReceiveQuilt; }
            set
            {
                _isReceiveQuilt = value;
                OnPropertyChanged();
            }
        }
        private bool _isQuiltAdd;
        public bool IsQuiltAdd
        {
            get { return _isQuiltAdd; }
            set
            {
                _isQuiltAdd = value;
                OnPropertyChanged();
            }
        }
        private string _selectAndclear = "Select All";

        public string SelectAndClear
        {
            get { return _selectAndclear; }
            set { _selectAndclear = value; OnPropertyChanged(nameof(SelectAndClear)); }
        }
        private string _entrquiltpalletSrlNumb;
        public string EnteredQuiltOrPalletSrlNumber
        {
            get { return _entrquiltpalletSrlNumb; }
            set
            {
                _entrquiltpalletSrlNumb = value;
                OnPropertyChanged(nameof(EnteredQuiltOrPalletSrlNumber));
            }
        }

        private bool _isReceiveQuiltWarningPopupIsVisible;
        public bool IsReceiveQuiltWarningPopupIsVisible
        {
            get { return _isReceiveQuiltWarningPopupIsVisible; }
            set
            {
                _isReceiveQuiltWarningPopupIsVisible = value;
                OnPropertyChanged();
            }
        }
        private bool _IsCompanyAdminReceiveQuiltWarningPopupIsVisible;
        public bool IsCompanyAdminReceiveQuiltWarningPopupIsVisible
        {
            get { return _IsCompanyAdminReceiveQuiltWarningPopupIsVisible; }
            set { _IsCompanyAdminReceiveQuiltWarningPopupIsVisible = value; OnPropertyChanged(); }
        }
        public ICommand ToggleReceiveQuiltWarningPopupCommand => new Command(() =>
        {
            IsReceiveQuiltWarningPopupIsVisible = false;
        });
        private bool _isReceiveQuiltPopupIsVisible;
        public bool IsReceiveQuiltPopupIsVisible
        {
            get { return _isReceiveQuiltPopupIsVisible; }
            set
            {
                _isReceiveQuiltPopupIsVisible = value;
                OnPropertyChanged();
            }
        }
        private bool _isSelect;
        public bool IsSelect
        {
            get { return _isSelect; }
            set
            {
                _isSelect = value;
                OnPropertyChanged();
            }
        }
        private bool _isBusy;
        public bool IsBusy
        {
            get
            {
                return _isBusy;
            }
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        private int _customerId;
        public int CustomerId
        {
            get { return _customerId; }
            set { _customerId = value; OnPropertyChanged(); }
        }
        private int _orderId;
        public int OrderId
        {
            get { return _orderId; }
            set { _orderId = value; OnPropertyChanged(); }
        }


        private ObservableCollection<PalletQuiltDataResponseModel> _quiltpalltlist;

        public ObservableCollection<PalletQuiltDataResponseModel> QuiltPalletforReceive
        {
            get { return _quiltpalltlist; }
            set
            {
                _quiltpalltlist = value;
                OnPropertyChanged(nameof(QuiltPalletforReceive));
            }
        }
        public INavigation Navigation { get; set; }
        public string UserType { get; private set; }

        public ObservableCollection<PalletQuiltDataResponseModel> QPlist = new ObservableCollection<PalletQuiltDataResponseModel>();
        public List<string> receiveQPlist = new List<string>();
        public List<string> customerNamelist = new List<string>();

        public ObservableCollection<PalletQuiltDataResponseModel> ReceiveQPModellist = new ObservableCollection<PalletQuiltDataResponseModel>();

        #endregion

        #region Commands
        public ICommand ToggleReceiveQuiltPopupCommand => new Command(() =>
        {
            //  IsReceiveQuiltPopupIsVisible = false;

        });
        public ICommand ToggleCompanyAdminReceiveQuiltWarningPopupCommand => new Command(() =>
        {
            IsCompanyAdminReceiveQuiltWarningPopupIsVisible = false;

        });
        public ICommand ToggleReceiveQuiltCancelPopupCommand => new Command(() =>
        {
            IsReceiveQuiltPopupIsVisible = false;
        });
        public ICommand BackButtonCommand => new Command(async () =>
        {

            await Navigation.PopAsync();
        });
        public ICommand ReceiveQuiltPopupCommand => new Command(async () =>
        {
            if (IsReceiveQuilt)
            {
                receiveQPlist.Clear();

                if (QuiltPalletforReceive != null)
                {
                    for (int i = 0; i < QuiltPalletforReceive.Count; i++)
                    {
                        if (QuiltPalletforReceive[i].IsCheckboxChecked)
                        {
                            receiveQPlist.Add(QuiltPalletforReceive[i].serialNumber);
                            ReceiveQPModellist.Add(QuiltPalletforReceive[i]);
                        }

                    }
                }
                else
                {
                    toast.LongAlert("Please add quilts/pallets first");

                }
                IsReceiveQuiltPopupIsVisible = false;

                await Navigation.PushAsync(new ReceiveQuiltsPage(receiveQPlist, ReceiveQPModellist));

            }


        });
        public ICommand SelectAllCommand => new Command(() =>
        {
            if (IsSelect)
            {
                try
                {
                    if (SelectAndClear == "Select All")
                    {
                        if (QuiltPalletforReceive != null)
                        {
                            for (int i = 0; i < QuiltPalletforReceive.Count; i++)
                            {
                                QuiltPalletforReceive[i].IsCheckboxChecked = true;
                            }
                            SelectAndClear = "Clear All";

                        }
                        else
                        {
                            toast.LongAlert("Please Add quilts/pallets first");
                        }
                    }
                    else
                    {
                        if (QuiltPalletforReceive != null)
                        {
                            for (int i = 0; i < QuiltPalletforReceive.Count; i++)
                            {
                                QuiltPalletforReceive[i].IsCheckboxChecked = false;
                            }
                            SelectAndClear = "Select All";
                        }
                        else
                        {
                            SelectAndClear = "Select All";
                        }
                    }

                }
                catch (Exception ex)
                {

                }

            }
        });

        public ICommand GoToReceiveQuiltPageCommand => new Command(async () =>
        {
            if (IsReceiveQuilt)
            {
                if (UserType == "Master Admin" || UserType == "Warehouse User")
                {
                    if (QuiltPalletforReceive != null)
                    {
                        for (int i = 0; i < QuiltPalletforReceive.Count; i++)
                        {
                            if (QuiltPalletforReceive[i].IsCheckboxChecked)
                            {
                                receiveQPlist.Add(QuiltPalletforReceive[i].serialNumber);
                                ReceiveQPModellist.Add(QuiltPalletforReceive[i]);
                                customerNamelist.Add(QuiltPalletforReceive[i].customerName.ToString());
                            }

                        }
                        if (customerNamelist.Any(o => o != customerNamelist[0]))
                        {
                            IsReceiveQuiltPopupIsVisible = true;
                            IsReceiveQuilt = true;
                        }
                        else
                        {
                            await Navigation.PushAsync(new ReceiveQuiltsPage(receiveQPlist, ReceiveQPModellist));
                        }

                    }
                    else
                    {
                        toast.LongAlert("Please add quilts/pallets first");

                    }

                }
                else
                {
                    IsBusy = true;
                    receiveQPlist.Clear();

                    if (QuiltPalletforReceive != null)
                    {
                        for (int i = 0; i < QuiltPalletforReceive.Count; i++)
                        {
                            if (QuiltPalletforReceive[i].IsCheckboxChecked)
                            {
                                receiveQPlist.Add(QuiltPalletforReceive[i].serialNumber);

                            }
                        }
                        if (Connectivity.NetworkAccess == NetworkAccess.Internet)
                        {
                            var req = new ReceiveQuiltsRequestPageModel
                            {
                                orderId = OrderId,
                                customerId = CustomerId,
                                sendEmail = true,
                                inventories = receiveQPlist,

                            };
                            var QandPurl = "/api/Shipments/ReceiveShipment";
                            var response = await new ApiData().PostDataNew<PalletQuiltDataResponseModel>(QandPurl, req, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200)
                                {
                                    toast.LongAlert(response.message);
                                    await Navigation.PopToRootAsync();
                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        toast.LongAlert(response.message);
                                    }
                                }

                            }
                            else
                            {
                                toast.LongAlert("Something went wrong!");
                            }

                        }
                        else
                        {
                            toast.LongAlert("No internet access!");
                        }
                    }
                    else
                    {
                        toast.LongAlert("Please add quilts/pallets first");

                    }

                    IsBusy = false;
                }

            }


        });
        public ICommand AddButtonCommand => new Command(async () =>
        {
            await AddQuiltPallet(EnteredQuiltOrPalletSrlNumber);

        });



        public ICommand ScanQRCodeCommand => new Command(async () =>
        {
            try
            {
                string param = String.Empty;
                var page = new ScanQRCodePopupPage();

                var permissions = await CheckAndRequestCameraPermission();
                if (permissions == PermissionStatus.Granted)
                {
                    page.Action += async (sender, stringparameter) =>
                    {
                        param = stringparameter;
                    };
                    await PopupNavigation.Instance.PushAsync(page);
                }

                page.Disappearing += async (c, d) =>
                {
                    if (!string.IsNullOrEmpty(param))
                    {
                        EnteredQuiltOrPalletSrlNumber = string.Empty;
                        IsQuiltAdd = true;
                        await AddQuiltPallet(param);
                    }
                    else
                    {
                        IsQuiltAdd = false;
                    }
                };
            }
            catch (Exception)
            {

            }
        });

        #endregion


    }
}
