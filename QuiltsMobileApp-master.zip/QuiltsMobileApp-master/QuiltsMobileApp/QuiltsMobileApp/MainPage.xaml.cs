﻿using Xamarin.Forms;

namespace QuiltsMobileApp
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
