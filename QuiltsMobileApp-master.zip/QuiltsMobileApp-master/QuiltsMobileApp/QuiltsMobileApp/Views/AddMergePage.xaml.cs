﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using System;
using System.Drawing;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AddMergePage : ContentPage
    {
        private readonly AddMergePageViewModel viewModel;
        public AddMergePage(PalletDetailListModel palletlist)
        {
            InitializeComponent();
            var addMergePageViewModel = new AddMergePageViewModel(Navigation, palletlist);
            BindingContext = addMergePageViewModel;
            viewModel = addMergePageViewModel;
            if (palletlist != null)
            {
                masterTypeId = palletlist.quilts[0].masterQuiltTypeId;
            }
            _selectedcount = 0;
        }


        public int _selectedcount { get; set; }
        public int masterTypeId { get; set; }
        void checkbox_IsCheckedChanged(System.Object sender, Xamarin.Forms.TappedEventArgs e)
        {
            PalletQuiltDataResponseModel model = (PalletQuiltDataResponseModel)((IntelliAbb.Xamarin.Controls.Checkbox)sender).BindingContext;

            if (model.quilts != null)
            {
                if (model.IsCheckboxChecked)
                {
                    if (model.quilts[0].masterQuiltTypeId != masterTypeId)
                    {
                        model.IsCheckboxChecked = false;
                        viewModel.toast.LongAlert("You can only Add/Merge with same type");
                    }
                    else
                    {
                        for (int i = 0; i < model.quilts.Count; i++)
                        {
                            if (!model.quilts[i].IsCheckboxCheckedNew)
                            {
                                model.quilts[i].IsCheckboxCheckedNew = true;
                            }
                        }
                        viewModel.IsSavePalletButtonColorVisible = true;
                    }
                }
                else
                {
                    for (int i = 0; i < model.quilts.Count; i++)
                    {
                        if (model.quilts[i].IsCheckboxCheckedNew)
                        {
                            model.quilts[i].IsCheckboxCheckedNew = false;
                        }
                    }
                    if (_selectedcount == 0)
                    {
                        viewModel.IsSavePalletButtonColorVisible = false;
                        viewModel.SelectAndClear = "Select All";
                    }
                }
            }
            else
            {
                if (model.IsCheckboxChecked)
                {
                    if (Convert.ToInt32(model.masterQuiltTypeId) != masterTypeId)
                    {
                        model.IsCheckboxChecked = false;
                        viewModel.toast.LongAlert("You can only Add/Merge with same type");
                    }
                    else
                    {
                        _selectedcount += 1;
                        viewModel.IsSavePalletButtonColorVisible = true;
                    }
                }
                else
                {
                    _selectedcount -= 1;
                    if (_selectedcount == 0)
                    {
                        viewModel.IsSavePalletButtonColorVisible = false;
                        viewModel.SelectAndClear = "Select All";
                    }
                }
            }

        }

        private void Checkbox_IsCheckedChanged_1(object sender, TappedEventArgs e)
        {
            Quilt model1 = (Quilt)((IntelliAbb.Xamarin.Controls.Checkbox)sender).BindingContext;
            if (model1.IsCheckboxCheckedNew)
            {
                if (Convert.ToInt32(model1.masterQuiltTypeId) != masterTypeId)
                {
                    model1.IsCheckboxCheckedNew = false;
                    viewModel.toast.LongAlert("You can only Add/Merge with same type");
                }
                else
                {
                    _selectedcount += 1;
                    viewModel.IsSavePalletButtonColorVisible = true;
                }
            }
            else
            {
                _selectedcount -= 1;
                if (_selectedcount == 0)
                {
                    viewModel.IsSavePalletButtonColorVisible = false;
                    viewModel.SelectAndClear = "Select All";
                }
            }
        }

        private void Search_Unfocused(object sender, FocusEventArgs e)
        {
            string srchitem = Search.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                }
                else
                {
                    viewModel.IsQuiltOrPalletAdd = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                viewModel.IsQuiltOrPalletAdd = false;
                LblSerialError.IsVisible = false;
            }
        }

        private void Search_Focused(object sender, FocusEventArgs e)
        {
            viewModel.IsQuiltOrPalletAdd = false;
            LblSerialError.IsVisible = false;
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            string srchitem = Search.Text;
            LblSerialError.Text = string.Empty;
            LblSerialError.IsVisible = false;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    viewModel.IsQuiltOrPalletAdd = true;
                }
            }
            else
            {
                viewModel.IsQuiltOrPalletAdd = false;
            }
        }

        //private void SwipeandDelete(object sender, EventArgs e)
        //{
        //    PalletQuiltDataResponseModel deleteModel = (PalletQuiltDataResponseModel)((SwipeItem)sender).BindingContext;

        //    if (viewModel.QuiltPalletlistToMerge.Count == 1)
        //    {
        //        _selectedcount = 0;
        //        viewModel.IsSavePalletButtonColorVisible = false;
        //        viewModel.QuiltPalletlistToMerge.Remove(deleteModel);
        //    }
        //    else
        //    {
        //        if (deleteModel.IsCheckboxChecked)
        //        {
        //            _selectedcount -= 1;
        //            if (_selectedcount == 0)
        //            {
        //                viewModel.IsSavePalletButtonColorVisible = false;
        //            }
        //            viewModel.QuiltPalletlistToMerge.Remove(deleteModel);
        //        }
        //        else
        //        {
        //            viewModel.QuiltPalletlistToMerge.Remove(deleteModel);
        //        }
        //    }
        //}
    }

}