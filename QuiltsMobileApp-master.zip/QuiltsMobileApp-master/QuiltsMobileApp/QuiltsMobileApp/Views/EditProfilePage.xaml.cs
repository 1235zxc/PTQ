﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class EditProfilePage : ContentPage
    {
        private readonly EditProfileViewModel VMEdPf;
        public ProfilePageModel profile { get; set; }
        public EditProfilePage(ProfilePageModel user)
        {
            InitializeComponent();
            profile = user;
            var VmEditProfile = new EditProfileViewModel(Navigation);
            BindingContext = VmEditProfile;
            VMEdPf = VmEditProfile;
            VMEdPf.UserFirstName = profile.firstName;
            VMEdPf.UserLastName = profile.lastName;
            VMEdPf.email = profile.email;
            VMEdPf.location = profile.location.name;
            VMEdPf.UserPhoneNumber = profile.phoneNumber;
        }


        private void _firstName_Unfocused(object sender, FocusEventArgs e)
        {
            if (string.IsNullOrEmpty(_firstName.Text))
            {
                VMEdPf.IsProfileUpdate = false;
            }
            else
            {
                VMEdPf.IsAllEntriesFilled();
            }
        }

        private void _lastName_Unfocused(object sender, FocusEventArgs e)
        {
            if (string.IsNullOrEmpty(_lastName.Text))
            {
                VMEdPf.IsProfileUpdate = false;
            }
            else
            {
                VMEdPf.IsAllEntriesFilled();
            }
        }
        private void MobileNumber_Unfocused(object sender, FocusEventArgs e)
        {
            if (string.IsNullOrEmpty(_phoneNumber.Text))
            {
                VMEdPf.IsProfileUpdate = false;
            }
            else
            {
                VMEdPf.IsAllEntriesFilled();
            }
        }
    }
}
