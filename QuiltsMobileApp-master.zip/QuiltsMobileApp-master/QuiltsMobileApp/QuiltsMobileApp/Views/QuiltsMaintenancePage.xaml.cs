﻿using QuiltsMobileApp.ViewModels;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class QuiltsMaintenancePage : ContentPage
    {
        private readonly QuiltsMaintenancePageViewModel _viewModel;
        public QuiltsMaintenancePage()
        {
            InitializeComponent();
            BindingContext = _viewModel = new QuiltsMaintenancePageViewModel(Navigation);
        }


        private void OrderCollection_Scrolled(object sender, ItemsViewScrolledEventArgs e)
        {
            e.VerticalDelta = 0;
        }


        void Checkbox_IsCheckedChanged(System.Object sender, Xamarin.Forms.TappedEventArgs e)
        {
            var _isChecked = _viewModel.QuiltPalletforUpdate.Where(x => x.IsCheckboxChecked).Any();
            if (_isChecked)
            {
                _viewModel.IsQuiltMaintenance = true;
            }
            else
            {
                _viewModel.IsQuiltMaintenance = false;
            }

            int _selectedCount = _viewModel.QuiltPalletforUpdate.Where(x => x.IsCheckboxChecked).Count();
            var _isAllSelected = _selectedCount == _viewModel.QuiltPalletforUpdate.Count() ? true : false;
            if (_isAllSelected)
            {
                _viewModel.SelectAndClear = "Clear All";
            }
            else
            {
                _viewModel.SelectAndClear = "Select All";
            }
        }

        private void Search_Unfocused(object sender, FocusEventArgs e)
        {
            string srchitem = Search.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                }
                else
                {
                    _viewModel.IsQuiltAdd = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                _viewModel.IsQuiltAdd = false;
                LblSerialError.IsVisible = false;
            }
        }

        private void Search_Focused(object sender, FocusEventArgs e)
        {
            _viewModel.IsQuiltAdd = false;
            LblSerialError.IsVisible = false;
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            string srchitem = Search.Text;
            LblSerialError.Text = string.Empty;
            LblSerialError.IsVisible = false;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    _viewModel.IsQuiltAdd = true;
                }
            }
            else
            {
                _viewModel.IsQuiltAdd = false;
            }
        }
    }
}