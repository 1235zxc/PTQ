﻿using QuiltsMobileApp.Controls;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using System;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class AssignQuiltQRCodePage : ContentPage
    {
        private readonly AssignQuiltQRCodePageViewModel AsQrPageVM;
        public AssignQuiltQRCodePage(OrderOpenResponseModel orderdetails, CustomerListModel customerListModel)
        {
            InitializeComponent();
            var assignQuiltQRCodePageViewModel = new AssignQuiltQRCodePageViewModel(Navigation, orderdetails, customerListModel);
            BindingContext = assignQuiltQRCodePageViewModel;
            AsQrPageVM = assignQuiltQRCodePageViewModel;
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            var srNumber = Search.Text;
            LblSerialError.IsVisible = false;
            LblSerialError.Text = string.Empty;
            if (!string.IsNullOrEmpty(srNumber))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(srNumber, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    AsQrPageVM.IsQuiltAdd = true;
                }
            }
            else
            {
                AsQrPageVM.IsQuiltAdd = false;
            }
        }
        public int count = 0;
        private void CheckBox_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            PalletQuiltDataResponseModel model = (PalletQuiltDataResponseModel)((IntelliAbb.Xamarin.Controls.Checkbox)sender).BindingContext;

            if (model.quilts != null)
            {
                if (model.IsCheckboxChecked)
                {
                    for (int i = 0; i < model.quilts.Count; i++)
                    {
                        model.quilts[i].IsCheckboxCheckedNew = true;
                    }
                    AsQrPageVM.IsAssignQuilt = true;
                }
                else
                {
                    for (int i = 0; i < model.quilts.Count; i++)
                    {
                        model.quilts[i].IsCheckboxCheckedNew = false;

                    }

                    if (count == 0)
                    {
                        AsQrPageVM.IsAssignQuilt = false;
                        AsQrPageVM.SelectAndClear = "Select All";
                    }

                }
            }
            else
            {
                if (model.IsCheckboxChecked)
                {
                    AsQrPageVM.IsAssignQuilt = true;
                    count += 1;
                }
                else
                {
                    count -= 1;
                    if (count == 0)
                    {
                        AsQrPageVM.IsAssignQuilt = false;
                        AsQrPageVM.SelectAndClear = "Select All";
                    }
                }
            }

        }
        private void CheckBox_CheckedChanged_1(object sender, CheckedChangedEventArgs e)
        {
            Quilt model1 = (Quilt)((IntelliAbb.Xamarin.Controls.Checkbox)sender).BindingContext;
            if (model1.IsCheckboxCheckedNew)
            {
                AsQrPageVM.IsAssignQuilt = true;
                count += 1;
            }
            else
            {
                count -= 1;
                if (count == 0)
                {
                    AsQrPageVM.IsAssignQuilt = false;
                    AsQrPageVM.SelectAndClear = "Select All";
                }
            }

        }

        private void Search_Unfocused(object sender, FocusEventArgs e)
        {
            var srNumber = Search.Text;
            if (!string.IsNullOrEmpty(srNumber))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(srNumber, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                }
                else
                {
                    AsQrPageVM.IsQuiltAdd = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                AsQrPageVM.IsQuiltAdd = false;
                LblSerialError.IsVisible = false;
            }
        }

        private void Search_Focused(object sender, FocusEventArgs e)
        {
            AsQrPageVM.IsQuiltAdd = false;
            LblSerialError.IsVisible = false;
        }

    }
}
