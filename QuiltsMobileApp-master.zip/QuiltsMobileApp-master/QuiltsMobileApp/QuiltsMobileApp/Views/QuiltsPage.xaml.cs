﻿using QuiltsMobileApp.ViewModels;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class QuiltsPage : ContentPage
    {
        public QuiltsPageViewModel quiltsVM { get; set; }
        private bool _canClose = false;
        public QuiltsPage()
        {
            InitializeComponent();
            BindingContext = quiltsVM = new QuiltsPageViewModel(Navigation);
            _canClose = false;
        }
        protected override bool OnBackButtonPressed()
        {
            if (_canClose)
            {
                return base.OnBackButtonPressed();
            }
            else
            {
                quiltsVM.toast.ShortAlert("Press again to exit");
                _canClose = true;
                Task.Factory.StartNew(async () =>
                {
                    await Task.Delay(5000);
                    _canClose = false;
                });
                return true;
            }
        }

        void Search_TextChanged(System.Object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
            if (string.IsNullOrEmpty(Search.Text))
            {
                quiltsVM.IsQuiltLookUp = false;
            }
            else
            {
                var srNumber = Search.Text;

                if (System.Text.RegularExpressions.Regex.IsMatch(srNumber, @"^[a-zA-Z0-9_]*$"))
                {
                    quiltsVM.IsQuiltLookUp = true;

                }
            }


        }
    }

}
