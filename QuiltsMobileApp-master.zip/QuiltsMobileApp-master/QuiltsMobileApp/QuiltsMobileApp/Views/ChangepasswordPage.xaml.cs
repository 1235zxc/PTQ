﻿using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class ChangepasswordPage : ContentPage
    {
        private readonly ChangePasswordPageViewModel viewModel;
        public ChangepasswordPage()
        {
            InitializeComponent();
            var changePasswordPageViewModel = new ChangePasswordPageViewModel(Navigation);
            BindingContext = changePasswordPageViewModel;
            viewModel = changePasswordPageViewModel;
        }


        void OldPassword_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            OldPasswordLockIcon.Source = "BlueLock.png";
            viewModel.OldPasswordFrameBorderColor = true;
        }

        void OldPassword_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.OldPasswordFrameBorderColor = false;
            OldPasswordLockIcon.Source = "grayLock.png";
            if (string.IsNullOrEmpty(OldPassword.Text))
            {
                viewModel.LblOldPasswordError = string.Empty;
                LblOldPasswordError.IsVisible = false;
                viewModel.IsChangePassWord = false;
            }
            else
            {
                if (viewModel.IsOldPassWordValid)
                {
                    LblOldPasswordError.IsVisible = false;
                    viewModel.IsAllEntriesFilled();
                }
                else
                {
                    LblOldPasswordError.IsVisible = true;
                    viewModel.LblOldPasswordError = "Please enter valid password";
                    viewModel.IsChangePassWord = false;
                }
            }
        }


        void SetNewPassword_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            SetNewPasswordLockIcon.Source = "BlueLock.png";
            viewModel.NewPasswordFrameBorderColor = true;
        }

        void SetNewPassword_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.NewPasswordFrameBorderColor = false;
            SetNewPasswordLockIcon.Source = "grayLock.png";

            if (string.IsNullOrEmpty(SetNewPassword.Text))
            {
                LblNewPasswordError.IsVisible = false;
                viewModel.LblNewPasswordError = string.Empty;
                viewModel.IsChangePassWord = false;
            }
            else
            {
                if (viewModel.IsPasswordValid)
                {
                    LblNewPasswordError.IsVisible = false;
                    viewModel.IsAllEntriesFilled();
                }
                else
                {
                    LblNewPasswordError.IsVisible = true;
                    viewModel.LblNewPasswordError = "Password must be between 8 to 25 characters including upper case and lower case, at least one number and one special character";
                    viewModel.IsChangePassWord = false;
                }
            }
        }

        void SetConfirmPassword_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            SetConfirmPasswordLockIcon.Source = "BlueLock.png";
            viewModel.ConPasswordFrameBorderColor = true;
        }

        void SetCondfirmPassword_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.ConPasswordFrameBorderColor = false;
            SetConfirmPasswordLockIcon.Source = "grayLock.png";
            if (string.IsNullOrEmpty(SetConfirmPassword.Text))
            {
                LblCfmPasswordError.IsVisible = false;
                viewModel.LblCfmPasswordError = string.Empty;
                viewModel.IsChangePassWord = false;
            }
            else
            {
                if (SetConfirmPassword.Text != SetNewPassword.Text)
                {
                    LblCfmPasswordError.IsVisible = true;
                    viewModel.LblCfmPasswordError = "Your password and confirmation password do not match.";
                    viewModel.IsChangePassWord = false;
                }
                else if (SetConfirmPassword.Text == SetNewPassword.Text && viewModel.IsPasswordValid)
                {
                    LblCfmPasswordError.IsVisible = false;
                    viewModel.IsAllEntriesFilled();
                }
                else
                {
                    LblCfmPasswordError.IsVisible = false;
                    viewModel.LblCfmPasswordError = string.Empty;
                    viewModel.IsChangePassWord = false;
                }
            }
        }

        private void SetNewPassword_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(SetConfirmPassword.Text))
            {
                if (SetConfirmPassword.Text == SetNewPassword.Text)
                {
                    LblCfmPasswordError.IsVisible = false;
                    viewModel.LblCfmPasswordError = string.Empty;
                }
                else
                {
                    LblCfmPasswordError.IsVisible = true;
                    viewModel.LblCfmPasswordError = "Your password and confirmation password do not match.";
                    viewModel.IsChangePassWord = false;
                }
            }
        }
    }
}
