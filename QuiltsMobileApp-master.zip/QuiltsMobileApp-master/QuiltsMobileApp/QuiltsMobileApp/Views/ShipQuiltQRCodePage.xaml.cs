﻿using QuiltsMobileApp.ViewModels;
using System;
using System.Linq;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class ShipQuiltQRCodePage : ContentPage
    {
        private readonly ShipQuiltQRCodePageViewModel _viewModel;
        public ShipQuiltQRCodePage(string orderNumber)
        {
            InitializeComponent();
            BindingContext = _viewModel = new ShipQuiltQRCodePageViewModel(Navigation, orderNumber);
            
        }


        void Checkbox_IsCheckedChanged(System.Object sender, Xamarin.Forms.TappedEventArgs e)
        {
            try
            {
                var _isChecked = _viewModel.GetShipQuiltsCollection.Where(x => x.IsCheckboxChecked).Any();
                if (_isChecked)
                {
                    _viewModel.IsShipQuilt = true;
                }
                else
                {
                    _viewModel.IsShipQuilt = false;
                }

                int _selectedCount = _viewModel.GetShipQuiltsCollection.Where(x => x.IsCheckboxChecked).Count();
                var _isAllSelected = _selectedCount == _viewModel.GetShipQuiltsCollection.Count() ? true : false;
                if (_isAllSelected)
                {
                    _viewModel.SelectAndClear = "Clear All";
                }
                else
                {
                    _viewModel.SelectAndClear = "Select All";
                }
            }
            catch (Exception)
            {

            }
        }

    }
}
