﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PalletDetailsPage : ContentPage
    {
        private readonly PalletDetailsPageViewModel pageViewModel;
        public PalletDetailsPage(int Id)
        {
            PalletId = Id;
            InitializeComponent();
            var palletDetailsPageViewModel = new PalletDetailsPageViewModel(Navigation, Id);
            BindingContext = palletDetailsPageViewModel;
            pageViewModel = palletDetailsPageViewModel;

        }
        public int PalletId { get; set; }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (AppStaticData.IsPallet)
            {
                pageViewModel.GetEditPalletDetails(PalletId);
                //AppStaticData.IsPallet = false;
            }
        }
        protected override void OnDisappearing()
        {
            base.OnDisappearing();

        }

    }
}