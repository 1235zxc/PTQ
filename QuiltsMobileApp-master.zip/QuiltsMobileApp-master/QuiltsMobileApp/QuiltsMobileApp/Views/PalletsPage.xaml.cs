﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using System;
using System.Linq;
using System.Threading.Tasks;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PalletsPage : ContentPage
    {
        private readonly PalletPageViewModel palletPageVM;
        private bool _canClose = false;
        public PalletsPage()
        {
            InitializeComponent();
            BindingContext = palletPageVM = new PalletPageViewModel(Navigation);
            _canClose = false;
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();
            if (AppStaticData.IsPallet)
            {
                await palletPageVM.PalletsItemCollection(1, palletPageVM.pageSize * palletPageVM.pageNumber);
                AppStaticData.IsPallet = false;
            }
        }
        protected override bool OnBackButtonPressed()
        {
            if (_canClose)
            {
                return base.OnBackButtonPressed();
            }
            else
            {
                palletPageVM.toast.ShortAlert("Press again to exit");
                _canClose = true;
                Task.Factory.StartNew(async () =>
                {
                    await Task.Delay(5000);
                    _canClose = false;
                });
                return true;
            }
        }
        protected override void OnDisappearing()
        {
            base.OnDisappearing();

        }



        private async void SearchClickedCommand(object sender, System.EventArgs e)
        {
            if (Connectivity.NetworkAccess == NetworkAccess.Internet)
            {
                if (palletPageVM.IsSearchPerform)
                {
                    if (palletPageVM.SearchOrResetSorce == "searchicon")
                    {
                        if (palletPageVM.UserType == "Master Admin" || palletPageVM.UserType == "Warehouse User")
                        {
                            IsBusy = true;
                            string textTrimmed = String.Concat(palletPageVM.PalletSerialNumber.Where(c => !Char.IsWhiteSpace(c)));
                            var url = "/api/Pallets?SearchBy=" + textTrimmed;
                            var response = await new ApiData().GetData<PalletPageModel>(url, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200 && response.data != null)
                                {
                                    palletPageVM.PalletCollection = response.data.pallets;
                                    palletPageVM.SearchOrResetSorce = "ClearIcon";
                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        palletPageVM.toast.LongAlert(response.message);
                                    }
                                }
                            }
                            else
                            {
                                palletPageVM.toast.ShortAlert("Something went wrong!");
                            }
                            IsBusy = false;
                        }
                        else
                        {
                            IsBusy = true;
                            string textTrimmed = String.Concat(palletPageVM.PalletSerialNumber.Where(c => !Char.IsWhiteSpace(c)));
                            var url = "/api/Pallets/GetPalletsForCompany?PalletNumber=" + textTrimmed;
                            var response = await new ApiData().GetData<CAorLuPalletPageModel>(url, true);
                            if (response != null)
                            {
                                if (response.statusCode == 200 && response.data != null)
                                {
                                    palletPageVM.CAorLuPalletCollection = response.data.palletList.pallets;
                                    palletPageVM.SearchOrResetSorce = "ClearIcon";
                                }
                                else
                                {
                                    if (response.message != null)
                                    {
                                        palletPageVM.toast.LongAlert(response.message);
                                    }
                                }
                            }
                            else
                            {
                                palletPageVM.toast.ShortAlert("Something went wrong!");
                            }
                            IsBusy = false;

                        }
                    }
                    else
                    {
                        palletPageVM.SearchOrResetSorce = "searchicon";
                        palletPageVM.PalletSerialNumber = string.Empty;
                        palletPageVM.IsSearchPerform = false;
                        await palletPageVM.PalletsItemCollection(1, palletPageVM.pageSize * palletPageVM.pageNumber);
                    }

                }
            }
            else
            {
                palletPageVM.toast.LongAlert("No internet access!");
            }
        }

        private void Search_Unfocused(object sender, FocusEventArgs e)
        {

            string srchitem = Search.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(srchitem, @"^[a-zA-Z0-9\s,]*$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                    palletPageVM.IsSearchPerform = false;
                }
                else
                {
                    palletPageVM.IsSearchPerform = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                palletPageVM.IsSearchPerform = false;
                LblSerialError.IsVisible = false;
            }

        }

        private void Search_Focused(object sender, FocusEventArgs e)
        {
            palletPageVM.IsSearchPerform = false;
            LblSerialError.IsVisible = false;
        }
    }
}