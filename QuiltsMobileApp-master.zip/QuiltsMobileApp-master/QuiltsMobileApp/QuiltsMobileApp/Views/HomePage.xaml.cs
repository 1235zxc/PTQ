﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.ViewModels;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        private readonly HomePageViewModel homeVM;
        private bool _canClose = false;
        public HomePage()
        {
            InitializeComponent();
            BindingContext = homeVM = new HomePageViewModel(Navigation);
            _canClose = false;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            if (AppStaticData.RunMethod)
            {
                homeVM.UserFullName = User_secrets.UserFull_Name;
                AppStaticData.RunMethod = false;
            }
        }
        protected override bool OnBackButtonPressed()
        {
            if (_canClose)
            {
                return base.OnBackButtonPressed();
            }
            else
            {
                homeVM.toast.ShortAlert("Press again to exit");
                _canClose = true;
                Task.Factory.StartNew(async () =>
                {
                    await Task.Delay(5000);
                    _canClose = false;
                });
                return true;
            }
        }
    }
}