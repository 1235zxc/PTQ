﻿using QuiltsMobileApp.ViewModels;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Collections.Generic;
using QuiltsMobileApp.Models;

namespace QuiltsMobileApp.Views
{
    public partial class ReceiveQuiltsPage : ContentPage
    {
         private List<string> receiveQPlist;
        private ObservableCollection<PalletQuiltDataResponseModel> receiveQPModellist;

        public ReceiveQuiltsPage(List<string> receiveQPlist, ObservableCollection<PalletQuiltDataResponseModel> receiveQPModellist)
        {
             InitializeComponent();
            this.receiveQPlist = receiveQPlist;
            this.receiveQPModellist = receiveQPModellist;
            ReceiveQuiltsVM = new ReceiveQuiltsPageViewModel(Navigation, receiveQPlist,receiveQPModellist);
            BindingContext = ReceiveQuiltsVM;
        }

        public ReceiveQuiltsPageViewModel ReceiveQuiltsVM { get; set; }
       /* public ReceiveQuiltsPage(List<PalletQuiltDataResponseModel> receiveQPlist)
        {
            InitializeComponent();
            this.receiveQPlist = receiveQPlist;
            ReceiveQuiltsVM = new ReceiveQuiltsPageViewModel(Navigation, receiveQPlist);
            BindingContext = ReceiveQuiltsVM;


        }*/

       
    }
}