﻿using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.ViewModels;
using System.Threading.Tasks;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class OnBoardingPage : ContentPage
    {
        private readonly OnBoardingPageViewModel VmOnBoarding;
        private bool _canClose = false;
        public OnBoardingPage()
        {
            InitializeComponent();
            BindingContext = VmOnBoarding = new OnBoardingPageViewModel(Navigation);
            _canClose = false;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            DependencyService.Get<IDeviceOrientation>().DisableRotation();
        }

        protected override bool OnBackButtonPressed()
        {
            if (_canClose)
            {
                return base.OnBackButtonPressed();
            }
            else
            {
                VmOnBoarding.toast.ShortAlert("Press again to exit");
                _canClose = true;
                Task.Factory.StartNew(async () =>
                {
                    await Task.Delay(5000);
                    _canClose = false;
                });
                return true;
            }
        }
        private void Username_Unfocused(object sender, FocusEventArgs e)
        {
            VmOnBoarding.EmailFrameBorderColor = false;
            UserIcon.Source = "grayUser.png";
            if (string.IsNullOrEmpty(VmOnBoarding.emailId))
            {
                emailerrorMsg.IsVisible = false;
                VmOnBoarding.LblEmailError = string.Empty;
                VmOnBoarding.IsLoggedIn = false;
            }
            else
            {
                if (VmOnBoarding.IsEmailValid)
                {
                    emailerrorMsg.IsVisible = false;
                    VmOnBoarding.IsAllEntriesFilled();
                }
                else
                {
                    emailerrorMsg.IsVisible = true;
                    VmOnBoarding.LblEmailError = "Email is required or has an invalid value. Please correct.";
                    VmOnBoarding.IsLoggedIn = false;
                }
            }

        }

        private void Username_Focused(object sender, FocusEventArgs e)
        {
            UserIcon.Source = "BlueUser.png";
            VmOnBoarding.EmailFrameBorderColor = true;
        }

        private void Password_Focused(object sender, FocusEventArgs e)
        {
            LockIcon.Source = "BlueLock.png";
            VmOnBoarding.PasswordFrameBorderColor = true;
            //VmOnBoarding.IsLoggedIn = false;
            Content.LayoutTo(new Rectangle(0, -10, Content.Bounds.Width, Content.Bounds.Height));
        }

        private void Password_Unfocused(object sender, FocusEventArgs e)
        {
            VmOnBoarding.PasswordFrameBorderColor = false;
            LockIcon.Source = "grayLock.png";
            if (string.IsNullOrEmpty(VmOnBoarding.password))
            {
                passWorderrorMsg.IsVisible = false;
                VmOnBoarding.LblPasswordError = string.Empty;
                VmOnBoarding.IsLoggedIn = false;
            }
            else
            {
                if (VmOnBoarding.IsPasswordValid)
                {
                    passWorderrorMsg.IsVisible = false;
                    VmOnBoarding.IsAllEntriesFilled();
                }
                else
                {
                    passWorderrorMsg.IsVisible = true;
                    VmOnBoarding.LblPasswordError = "Please enter your valid password.";
                    VmOnBoarding.IsLoggedIn = false;
                }
            }

        }

        void Password_TextChanged(System.Object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
            if (VmOnBoarding.IsEmailValid && VmOnBoarding.IsPasswordValid)
            {
                VmOnBoarding.IsLoggedIn = true;
            }
        }
    }
}