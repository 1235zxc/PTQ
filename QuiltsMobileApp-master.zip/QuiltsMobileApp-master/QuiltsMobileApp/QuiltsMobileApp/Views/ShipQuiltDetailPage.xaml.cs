﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using System.Collections.Generic;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class ShipQuiltDetailPage : ContentPage
    {
        private List<string> shipQPlist;
        private readonly ShipQuiltDetailPageViewModel pageViewModel;
        //company admin
        public ShipQuiltDetailPage(List<string> shipQPlist)
        {
            InitializeComponent();
            this.shipQPlist = shipQPlist;
            var quiltDetailPageViewModel = new ShipQuiltDetailPageViewModel(Navigation, shipQPlist);
            BindingContext = quiltDetailPageViewModel;
            pageViewModel = quiltDetailPageViewModel;

        }
        //master admin
        public ShipQuiltDetailPage(List<string> shipQPlist, string orderNumber)
        {
            InitializeComponent();
            this.shipQPlist = shipQPlist;
            var quiltDetailPageViewModel = new ShipQuiltDetailPageViewModel(Navigation, shipQPlist, orderNumber);
            BindingContext = quiltDetailPageViewModel;
            pageViewModel = quiltDetailPageViewModel;
        }



        public ShipQuiltsPageModel ShipQuilts { get; }



        private void otherCarrier_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (!string.IsNullOrEmpty(otherCarrier.Text))
            {
                if (pageViewModel.LocationName != "Location" &&
                    pageViewModel.ETAName != "ETA" &&
                    pageViewModel.Carrier != "Carrier" &&
                    pageViewModel.ShipmentName != "Shipment Type")
                {
                    pageViewModel.IsShip = true;
                }
                else
                {
                    pageViewModel.IsShip = false;
                }
            }
            else
            {
                pageViewModel.IsShip = false;
            }
        }

    }
}
