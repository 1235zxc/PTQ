﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssignQuiltsPage : ContentPage
    {
        private readonly AssignQuiltsPageViewModel viewModel;

        public AssignQuiltsPage()
        {
            InitializeComponent();
            var assignQuiltsPageViewModel = new AssignQuiltsPageViewModel(Navigation);
            BindingContext = assignQuiltsPageViewModel;
            viewModel = assignQuiltsPageViewModel;
        }

        public AssignQuiltsPage(ShipQuiltsPageModel type)
        {
            InitializeComponent();
            var assignQuiltsPageViewModel = new AssignQuiltsPageViewModel(Navigation, type);
            BindingContext = assignQuiltsPageViewModel;
            viewModel = assignQuiltsPageViewModel;
        }

        protected override void OnAppearing()
        {
            base.OnDisappearing();
        }
    }
}