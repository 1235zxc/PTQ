﻿using QuiltsMobileApp.ViewModels;
using System;
using System.Linq;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class ReceiveQuiltQRCodePage : ContentPage
    {
        private readonly ReceiveQuiltQRCodePageViewModel _viewModel;

        public ReceiveQuiltQRCodePage()
        {
            InitializeComponent();
            BindingContext = _viewModel = new ReceiveQuiltQRCodePageViewModel(Navigation);
        }
        void Search_TextChanged(System.Object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
            string srchitem = Search.Text;
            LblSerialError.Text = string.Empty;
            LblSerialError.IsVisible = false;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    _viewModel.IsQuiltAdd = true;
                }
            }
            else
            {
                _viewModel.IsQuiltAdd = false;
            }
        }



        void Checkbox_IsCheckedChanged(System.Object sender, Xamarin.Forms.TappedEventArgs e)
        {
            try
            {
                var _isChecked = _viewModel.QuiltPalletforReceive.Where(x => x.IsCheckboxChecked).Any();
                if (_isChecked)
                {
                    _viewModel.IsReceiveQuilt = true;
                }
                else
                {
                    _viewModel.IsReceiveQuilt = false;
                }

                int _selectedCount = _viewModel.QuiltPalletforReceive.Where(x => x.IsCheckboxChecked).Count();
                var _isAllSelected = _selectedCount == _viewModel.QuiltPalletforReceive.Count() ? true : false;
                if (_isAllSelected)
                {
                    _viewModel.SelectAndClear = "Clear All";
                }
                else
                {
                    _viewModel.SelectAndClear = "Select All";
                }
            }
            catch (Exception)
            {

            }

        }

        void Search_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            string srchitem = Search.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                }
                else
                {
                    _viewModel.IsQuiltAdd = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                _viewModel.IsQuiltAdd = false;
                LblSerialError.IsVisible = false;
            }
        }

        void Search_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            _viewModel.IsQuiltAdd = false;
            LblSerialError.IsVisible = false;

        }
    }
}
