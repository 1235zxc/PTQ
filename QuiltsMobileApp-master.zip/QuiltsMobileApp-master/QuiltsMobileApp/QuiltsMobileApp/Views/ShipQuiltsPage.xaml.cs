﻿using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ShipQuiltsPage : ContentPage
    {
        public ShipQuiltsPage()
        {
            InitializeComponent();
            BindingContext = new ShipQuiltsPageViewModel(Navigation);
        }
    }
}