﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class EditPalletPage : ContentPage
    {
        private readonly EditPalletPageViewModel pageViewModel;
        public EditPalletPage(int palletId)
        {
            InitializeComponent();
            var editPalletPageViewModel = new EditPalletPageViewModel(Navigation, palletId);
            BindingContext = editPalletPageViewModel;
            pageViewModel = editPalletPageViewModel;
        }
        public int count = 0;
        private void checkbox_IsCheckedChanged(object sender, TappedEventArgs e)
        {
            QuiltDetailListModel model = (QuiltDetailListModel)((IntelliAbb.Xamarin.Controls.Checkbox)sender).BindingContext;
            if (model != null)
            {
                if (model.IsCheckboxChecked)
                {
                    count++;
                    if (pageViewModel.QuiltCollection.Count == count)
                    {
                        pageViewModel.IsPalletSaved = false;
                    }
                }
                else
                {
                    count--;
                    pageViewModel.IsPalletSaved = true;
                    if (count == 0)
                    {
                        pageViewModel.IsPalletSaved = false;
                    }
                }

            }

        }


        private void TxtDescription_TextChanged(object sender, TextChangedEventArgs e)
        {
            try
            {
                if (!pageViewModel.quiltDeleted)
                {
                    string srchitem = TxtDescription.Text.ToLower();
                    if (srchitem != pageViewModel.PalletList.description)
                    {
                        if (srchitem != pageViewModel.PalletList.description.ToLower())
                        {
                            pageViewModel.IsPalletSaved = true;
                        }
                        else
                        {
                            pageViewModel.IsPalletSaved = false;
                        }
                    }
                }
            }
            catch (Exception)
            {

            }
        }
    }
}