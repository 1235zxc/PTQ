﻿using QuiltsMobileApp.Helpers;
using QuiltsMobileApp.ViewModels;
using System;
using System.Linq;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class CAorLUShipQuiltQRCodePage : ContentPage
    {
        private readonly CAorLUShipQuiltQRCodeViewModel _viewModel;
        public CAorLUShipQuiltQRCodePage()
        {
            InitializeComponent();
            BindingContext = _viewModel = new CAorLUShipQuiltQRCodeViewModel(Navigation);
        }

        protected async override void OnAppearing()
        {
            base.OnAppearing();
            if (AppStaticData.IsPallet || AppStaticData.IsMockPalletCreated)
            {
                _viewModel.IsQuiltAdd = true;
                await _viewModel.AddQuiltPallet(AppStaticData.PalletSerialnumber);
                AppStaticData.IsPallet = false;
                AppStaticData.IsMockPalletCreated = false;
            }
        }
        void Search_TextChanged(System.Object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
            string srchitem = Search.Text;
            LblSerialError.Text = string.Empty;
            LblSerialError.IsVisible = false;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    _viewModel.IsQuiltAdd = true;
                }
            }
            else
            {
                _viewModel.IsQuiltAdd = false;
            }
        }

        void Search_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            string srchitem = Search.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(Search.Text, @"^\s*(([a-zA-Z]{2}\d{6}[aA]\w{4})|([Pp][Ii][Dd][a-zA-Z]\d{5})|([a-zA-Z]{2}\d{6}[aA]\w{4})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+|([Pp][Ii][Dd][a-zA-Z]\d{5})(\s?,\s?([a-zA-Z]{2}\d{6}[aA]\w{4}|[Pp][Ii][Dd][a-zA-Z]\d{5}))+)\s*$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                }
                else
                {
                    _viewModel.IsQuiltAdd = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                _viewModel.IsQuiltAdd = false;
                LblSerialError.IsVisible = false;
            }
        }

        void Search_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            _viewModel.IsQuiltAdd = false;
            LblSerialError.IsVisible = false;

        }
        private int _selectedCount1 { get; set; } = 0;
        private int _selectedCount2 { get; set; } = 0;
        private bool _isAllSelected { get; set; } = false;
        private bool _isChecked { get; set; } = false;

        void Checkbox_IsCheckedChanged(System.Object sender, Xamarin.Forms.TappedEventArgs e)
        {
            try
            {
                _isChecked = _viewModel.QuiltPalletforUpdate.Where(x => x.IsCheckboxChecked).Any();
                if (_isChecked)
                {
                    _viewModel.IsShipQuilt = true;
                }
                else
                {
                    _viewModel.IsShipQuilt = false;
                }

                _selectedCount1 = _viewModel.QuiltPalletforUpdate.Where(x => x.IsCheckboxChecked).Count();
                _selectedCount2 = _viewModel.MockPalletforUpdate.Where(x => x.IsCheckboxChecked).Count();
                _isAllSelected = _selectedCount1 + _selectedCount2 == _viewModel.QuiltPalletforUpdate.Count()
                                    + _viewModel.MockPalletforUpdate.Count() ? true : false;
                if (_isAllSelected)
                {
                    _viewModel.SelectAndClear = "Clear All";
                }
                else
                {
                    _viewModel.SelectAndClear = "Select All";
                }

            }
            catch (Exception)
            {

            }
        }

        private void Checkbox_IsCheckedChanged_Mock(object sender, TappedEventArgs e)
        {
            try
            {
                _isChecked = _viewModel.MockPalletforUpdate.Where(x => x.IsCheckboxChecked).Any();
                if (_isChecked)
                {
                    _viewModel.IsShipQuilt = true;
                }
                else
                {
                    _viewModel.IsShipQuilt = false;
                }

                _selectedCount1 = _viewModel.QuiltPalletforUpdate.Where(x => x.IsCheckboxChecked).Count();
                _selectedCount2 = _viewModel.MockPalletforUpdate.Where(x => x.IsCheckboxChecked).Count();
                _isAllSelected = _selectedCount1 + _selectedCount2 == _viewModel.QuiltPalletforUpdate.Count()
                                    + _viewModel.MockPalletforUpdate.Count() ? true : false;
                if (_isAllSelected)
                {
                    _viewModel.SelectAndClear = "Clear All";
                }
                else
                {
                    _viewModel.SelectAndClear = "Select All";
                }

            }
            catch (Exception)
            {

            }

        }
    }
}
