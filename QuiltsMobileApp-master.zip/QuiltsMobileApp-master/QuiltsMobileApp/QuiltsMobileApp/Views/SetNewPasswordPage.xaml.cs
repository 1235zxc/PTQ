﻿using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SetNewPasswordPage : ContentPage
    {
        private readonly SetNewPasswordPageViewModel viewModel;
        public SetNewPasswordPage(string Token, string email)
        {
            InitializeComponent();
            var setNewPasswordPageViewModel = new SetNewPasswordPageViewModel(Navigation, Token, email);
            BindingContext = setNewPasswordPageViewModel;
            viewModel = setNewPasswordPageViewModel;
        }

        void SetNewPassword_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.NewPasswordFrameBorderColor = true;
            SetNewPasswordLockIcon.Source = "BlueLock.png";
        }

        void SetNewPassword_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.NewPasswordFrameBorderColor = false;

            SetNewPasswordLockIcon.Source = "grayLock.png";
            if (string.IsNullOrEmpty(SetNewPassword.Text))
            {
                viewModel.LblNewPasswordError = string.Empty;
                newPasserrormsg.IsVisible = false;
                viewModel.IsSetNewPassword = false;
            }
            else
            {
                if (viewModel.PasswordValid)
                {
                    newPasserrormsg.IsVisible = false;
                    if (!string.IsNullOrEmpty(SetConfirmPassword.Text))
                    {
                        if (SetConfirmPassword.Text == SetNewPassword.Text)
                        {
                            cnfrmNewPassErrormsg.IsVisible = false;
                            viewModel.LblCfmPasswordError = string.Empty;
                            viewModel.IsConfirmPassValid = true;
                            viewModel.IsAllEntriesFilled();
                        }
                        else
                        {
                            cnfrmNewPassErrormsg.IsVisible = true;
                            viewModel.LblCfmPasswordError = "Your password and confirmation password do not match.";
                            viewModel.IsSetNewPassword = false;
                        }
                    }
                }
                else
                {
                    newPasserrormsg.IsVisible = true;
                    viewModel.IsSetNewPassword = false;
                    viewModel.LblNewPasswordError = "Password must be between 8 to 25 characters including upper case and lower case, at least one number and one special character";
                }
            }
        }

        void SetConfirmPassword_Focused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.CfmPasswordFrameBorderColor = true;
            SetConfirmPasswordLockIcon.Source = "BlueLock.png";
        }

        void SetCondfirmPassword_Unfocused(System.Object sender, Xamarin.Forms.FocusEventArgs e)
        {
            viewModel.CfmPasswordFrameBorderColor = false;
            SetConfirmPasswordLockIcon.Source = "grayLock.png";
            if (string.IsNullOrEmpty(SetConfirmPassword.Text))
            {
                cnfrmNewPassErrormsg.IsVisible = false;
                viewModel.LblCfmPasswordError = string.Empty;
                viewModel.IsSetNewPassword = false;
            }
            else
            {
                if (SetConfirmPassword.Text != SetNewPassword.Text)
                {
                    cnfrmNewPassErrormsg.IsVisible = true;
                    viewModel.LblCfmPasswordError = "Your password and confirmation password do not match.";
                    viewModel.IsSetNewPassword = false;
                }
                else if (SetConfirmPassword.Text == SetNewPassword.Text && viewModel.PasswordValid)
                {
                    cnfrmNewPassErrormsg.IsVisible = false;
                    viewModel.IsAllEntriesFilled();
                }
                else
                {
                    cnfrmNewPassErrormsg.IsVisible = false;
                    viewModel.LblCfmPasswordError = string.Empty;
                    viewModel.IsSetNewPassword = false;
                }
            }
        }

    }
}