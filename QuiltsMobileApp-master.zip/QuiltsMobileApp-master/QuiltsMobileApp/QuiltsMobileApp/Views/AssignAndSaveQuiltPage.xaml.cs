﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AssignAndSaveQuiltPage : ContentPage
    {
        private readonly AssignAndSaveQuiltViewModel assignsaveVM;
        public AssignAndSaveQuiltPage(CustomerListModel customerListModel, OrderOpenResponseModel orderdetails, QuiltPalletforAssign quiltPalletforAssign)
        {
            InitializeComponent();
            var assignAndSaveQuiltViewModel = new AssignAndSaveQuiltViewModel(Navigation, customerListModel, orderdetails, quiltPalletforAssign);
            BindingContext = assignAndSaveQuiltViewModel;
            assignsaveVM = assignAndSaveQuiltViewModel;
        }
    }
}