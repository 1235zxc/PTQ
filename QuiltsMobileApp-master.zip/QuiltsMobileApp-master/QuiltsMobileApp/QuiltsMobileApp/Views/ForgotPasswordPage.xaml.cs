﻿using QuiltsMobileApp.ViewModels;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ForgotPasswordPage : ContentPage
    {
        private readonly ForgotPasswordPageViewModel forgotPassVM;
        public ForgotPasswordPage()
        {
            InitializeComponent();
            var forgotpasswordViewModel = new ForgotPasswordPageViewModel(Navigation);
            BindingContext = forgotpasswordViewModel;
            forgotPassVM = forgotpasswordViewModel;
        }

        void EmailAddress_TextChanged(System.Object sender, Xamarin.Forms.TextChangedEventArgs e)
        {
            if (e.NewTextValue != null)
            {
                var entry = sender as Entry;
                //var vm = BindingContext as ForgotPasswordPageViewModel;
                //forgotPassVM.IsAllEntriesFilled();
                //forgotPassVM.LblEmailErrorIsVisible = false;
            }
        }

        private void EmailAddress_Unfocused(object sender, FocusEventArgs e)
        {
            if (string.IsNullOrEmpty(EmailAddress.Text))
            {
                emailErrorMsg.IsVisible = false;
                forgotPassVM.LblEmailError = string.Empty;
                forgotPassVM.IsForgotPassword = false;
            }
            else
            {
                if (forgotPassVM.EmailValid)
                {
                    emailErrorMsg.IsVisible = false;
                    forgotPassVM.IsAllEntriesFilled();
                }
                else
                {
                    emailErrorMsg.IsVisible = true;
                    forgotPassVM.LblEmailError = "Email has an invalid value. Please correct.";
                    forgotPassVM.IsForgotPassword = false;
                }
            }
        }
    }
}