﻿using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using System;
using System.Linq;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views
{
    public partial class CAorLUCreatePalletPage : ContentPage
    {
        private readonly CAorLUCreatePalletPageViewModel _viewModel;

        public int _typeid { get; set; } = 0;
        public int _statusid { get; set; } = 0;
        public int _Count { get; set; } = 0;

        public CAorLUCreatePalletPage()
        {
            InitializeComponent();
            BindingContext = _viewModel = new CAorLUCreatePalletPageViewModel(Navigation);

        }

        void checkbox_IsCheckedChanged(System.Object sender, Xamarin.Forms.TappedEventArgs e)
        {
            PalletQuiltDataResponseModel model = (PalletQuiltDataResponseModel)((IntelliAbb.Xamarin.Controls.Checkbox)sender).BindingContext;

            if (model != null)
            {
                if (model.IsCheckboxChecked)
                {
                    if (_typeid == 0 && _statusid == 0)
                    {
                        _typeid = Convert.ToInt32(model.masterQuiltTypeId);
                        _statusid = model.statusId;
                        _Count++;
                    }
                    else
                    {
                        if (_typeid == Convert.ToInt32(model.masterQuiltTypeId) && _statusid == Convert.ToInt32(model.statusId))
                        {
                            _Count++;
                        }
                        else
                        {
                            _viewModel.toast.ShortAlert("Select Quilt with same type and status");
                            _Count++;
                            model.IsCheckboxChecked = false;
                        }
                    }
                }
                else
                {
                    _Count--;
                    if (_Count == 0)
                    {
                        _typeid = 0;
                        _statusid = 0;
                    }
                }

            }

            try
            {
                var _isChecked = _viewModel.QuiltListForCreate.Where(x => x.IsCheckboxChecked).Any();
                if (_isChecked)
                {
                    _viewModel.IsCreatePallet = true;
                }
                else
                {
                    _viewModel.IsCreatePallet = false;
                }
                int _selectedCount = _viewModel.QuiltListForCreate.Where(x => x.IsCheckboxChecked).Count();
                var _isAllSelected = _selectedCount == _viewModel.QuiltListForCreate.Count() ? true : false;
                if (_isAllSelected)
                {
                   // _viewModel.SelectAndClear = "Clear All";
                }
                else
                {
                   // _viewModel.SelectAndClear = "Select All";
                }

            }
            catch (Exception)
            {
                _viewModel.toast.ShortAlert("Something went wrong!");
            }
        }

        private void Search_Unfocused(object sender, FocusEventArgs e)
        {
            string srchitem = Search.Text;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (!System.Text.RegularExpressions.Regex.IsMatch(srchitem, @"^(\s*([a-zA-Z]{2}[0-9]{6}[aA]\w{4})\s*|\s*([a-zA-Z]{2}[0-9]{6}[aA]\w{4})(\s?,\s?[a-zA-Z]{2}[0-9]{6}[aA]\w{4})+\s*)$"))
                {
                    LblSerialError.Text = "Please Input Correct Serial Number";
                    LblSerialError.IsVisible = true;
                }
                else
                {
                    _viewModel.IsQuiltsAdd = true;
                    LblSerialError.Text = string.Empty;
                    LblSerialError.IsVisible = false;
                }
            }
            else
            {
                _viewModel.IsQuiltsAdd = false;
                LblSerialError.IsVisible = false;
            }
        }

        private void Search_Focused(object sender, FocusEventArgs e)
        {
            _viewModel.IsQuiltsAdd = false;
            LblSerialError.IsVisible = false;
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            string srchitem = Search.Text;
            LblSerialError.Text = string.Empty;
            LblSerialError.IsVisible = false;
            if (!string.IsNullOrEmpty(srchitem))
            {
                if (System.Text.RegularExpressions.Regex.IsMatch(srchitem, @"^(\s*([a-zA-Z]{2}[0-9]{6}[aA]\w{4})\s*|\s*([a-zA-Z]{2}[0-9]{6}[aA]\w{4})(\s?,\s?[a-zA-Z]{2}[0-9]{6}[aA]\w{4})+\s*)$"))
                {
                    _viewModel.IsQuiltsAdd = true;
                }
            }
            else
            {
                _viewModel.IsQuiltsAdd = false;
            }
        }


        private void SearchQuiltNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SearchQuiltNumber.Text != null)
            {
                _viewModel.IsCreatePallet = true;

            }
        }
    }
}
