﻿using System.Collections.ObjectModel;
using QuiltsMobileApp.Models;
using QuiltsMobileApp.ViewModels;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;

namespace QuiltsMobileApp.Views.CustomViews
{
    public partial class QMUpdateStatusPopupPage : PopupPage
    {
        private readonly QuiltsMaintenancePageViewModel QMviewModel;
        public ObservableCollection<QuiltsMaintenancePageModels> QuiltPalletStatusList { get; set; }
        public QMUpdateStatusPopupPage(QuiltPalletStatusUpdate quiltPalletStatusUpdate, ObservableCollection<QuiltsMaintenancePageModels> quiltPalletStatusList)
        {
            InitializeComponent();

            var quiltsMaintenancePageViewModel = new QuiltsMaintenancePageViewModel(Navigation, quiltPalletStatusUpdate);
            BindingContext = quiltsMaintenancePageViewModel;
            QMviewModel = quiltsMaintenancePageViewModel;
            QuiltPalletStatusList = quiltPalletStatusList;
            QMviewModel.QuiltPalletStatusList = QuiltPalletStatusList;
        }

        void RadioButton_CheckedChanged(System.Object sender, Xamarin.Forms.CheckedChangedEventArgs e)
        {
            QuiltsMaintenancePageModels model = (QuiltsMaintenancePageModels)((RadioButton)sender).BindingContext;
            if (model.IsChecked)
            {
                QMviewModel.SelectedStatusId = model.id;
                QMviewModel.IsUpdateColor = true;
                QMviewModel.IsUpdateStatusEnable = true;
            }
        }
        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            QMviewModel.IsUpdateColor = true;
        }
    }
}
