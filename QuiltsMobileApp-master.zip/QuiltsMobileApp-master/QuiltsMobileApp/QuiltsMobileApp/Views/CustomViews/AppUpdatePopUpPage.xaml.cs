﻿using Plugin.LatestVersion;
using Rg.Plugins.Popup.Pages;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views.CustomViews
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AppUpdatePopUpPage : PopupPage
    {
        public AppUpdatePopUpPage()
        {
            InitializeComponent();
            if (Device.RuntimePlatform == Device.Android)
            {
                _storeName.Text = "Google Play Store";
            }
            else
            {
                _storeName.Text = "App Store";
            }
        }

        private async void Update_Clicked(object sender, System.EventArgs e)
        {
            await CrossLatestVersion.Current.OpenAppInStore();
        }
    }
}