﻿using QuiltsMobileApp.ViewModels;
using Rg.Plugins.Popup.Pages;

namespace QuiltsMobileApp.Views.CustomViews
{
    public partial class ForgotPasswordPagePopup : PopupPage
    {
        public ForgotPasswordPagePopup()
        {
            InitializeComponent();
        }
    }
}
