﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Views.CustomViews
{
    public partial class CustomLoader : ContentView
    {
        public CustomLoader()
        {
            InitializeComponent();
        }
    }
}
