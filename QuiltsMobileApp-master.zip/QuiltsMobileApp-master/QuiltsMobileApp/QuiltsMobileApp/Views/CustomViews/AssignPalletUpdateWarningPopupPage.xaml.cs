﻿using QuiltsMobileApp.ViewModels;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;

namespace QuiltsMobileApp.Views.CustomViews
{
    public partial class AssignPalletUpdateWarningPopupPage : PopupPage
    {
        public AssignPalletUpdateWarningPopupPage()
        {
            InitializeComponent();
            BindingContext = new AssignQuiltQRCodePageViewModel();

        }
        public EventHandler<bool> ActionUpdate;

        private async void Button_Clicked(object sender, EventArgs e)
        {
            var scanresult = true;
            ActionUpdate?.Invoke(this, scanresult);
            await PopupNavigation.Instance.PopAsync();
        }
    }
}
