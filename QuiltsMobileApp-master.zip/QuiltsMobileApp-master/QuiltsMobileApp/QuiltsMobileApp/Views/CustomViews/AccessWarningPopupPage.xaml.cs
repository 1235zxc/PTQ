﻿using Plugin.Permissions;
using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;
using Xamarin.Forms.Xaml;

namespace QuiltsMobileApp.Views.CustomViews
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AccessWarningPopupPage : PopupPage
    {
        public AccessWarningPopupPage()
        {
            InitializeComponent();
        }

        private void EnableButton_Clicked(object sender, System.EventArgs e)
        {
            try
            {
                PopupNavigation.Instance.PopAsync();
                CrossPermissions.Current.OpenAppSettings();
            }
            catch (Exception)
            {

            }
        }

        private void LaterButton_Clicked(object sender, System.EventArgs e)
        {
            PopupNavigation.Instance.PopAsync();
        }
    }
}