﻿using Rg.Plugins.Popup.Pages;
using Rg.Plugins.Popup.Services;
using System;

namespace QuiltsMobileApp.Views.CustomViews
{
    public partial class LogoutPopupPage : PopupPage
    {
        public LogoutPopupPage()
        {
            InitializeComponent();
        }

        public EventHandler<bool> LogoutAction;
        public void NoButton_Clicked(System.Object sender, System.EventArgs e)
        {
            LogoutAction?.Invoke(this, false);
            PopupNavigation.Instance.PopAsync();
        }

        private void YesButton_Clicked(object sender, EventArgs e)
        {
            LogoutAction?.Invoke(this, true);
            PopupNavigation.Instance.PopAsync();
        }
    }
}
