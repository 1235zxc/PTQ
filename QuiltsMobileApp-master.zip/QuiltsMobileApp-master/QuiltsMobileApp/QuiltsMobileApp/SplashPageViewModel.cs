﻿using QuiltsMobileApp.Helpers;
using System.Windows.Input;
using Xamarin.Forms;

namespace QuiltsMobileApp
{
    public class SplashPageViewModel : ObservableObjects
    {
        public SplashPageViewModel()
        {
        }
        private bool _isVersionUpdatePopupIsVisible;
        public bool IsVersionUpdatePopupIsVisible
        {
            get
            {
                return _isVersionUpdatePopupIsVisible;
            }
            set
            {
                _isVersionUpdatePopupIsVisible = value;
                OnPropertyChanged();
            }
        }
        private bool _isVersionUpdate;
        public bool IsVersionUpdate
        {
            get
            {
                return _isVersionUpdate;
            }
            set
            {
                _isVersionUpdate = value;
                OnPropertyChanged();
            }
        }

        public ICommand VersionUpdateCommand => new Command(() =>
        {
            IsVersionUpdate = true;
        });

    }
}
