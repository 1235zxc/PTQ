﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class ShipQuiltDetailPageModel
    {
      

    }
    public class ShipQuiltLocationPageModel : BindableObject
    {
        public int id { get; set; }
        public string name { get; set; }
        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }

    }
    public class ShipQuiltCarrierPageModel: BindableObject
    {
        public int id { get; set; }
         public string name { get; set; }
        public object phoneNumber { get; set; }
        public object additionalNotes { get; set; }
        public bool isPreferred { get; set; }
        public int customerId { get; set; }
        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }

    }
    public class ShipmentETAResponsePageModel : BindableObject
    {
        public int id { get; set; }
        public string name { get; set; }
        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }

    }
    public class ShipmentTypeModel : BindableObject
    {
        public int id { get; set; }
        public string name { get; set; }
        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }
    }

}
