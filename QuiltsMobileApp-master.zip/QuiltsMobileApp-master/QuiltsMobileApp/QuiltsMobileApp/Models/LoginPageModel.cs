﻿namespace QuiltsMobileApp.Models
{
    public class LoginPageModel
    {

        public string emailId { get; set; }
        public string password { get; set; }
    }
}
