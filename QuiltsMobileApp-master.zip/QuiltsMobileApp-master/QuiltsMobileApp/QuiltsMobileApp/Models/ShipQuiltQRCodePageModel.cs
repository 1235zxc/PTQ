﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class ShipQuiltQRCodePageModel : BindableObject
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public int typeId { get; set; }
        public string type { get; set; }
        public int statusId { get; set; }
        public string status { get; set; }
        public int totalQuilts { get; set; }
        public int? masterQuiltTypeId { get; set; }
        public List<Quilt> quilts { get; set; }
        public int customerId { get; set; }
        public int orderId { get; set; }
        public string customerName { get; set; }
        public string orderNumber { get; set; }
        public string orderStatus { get; set; }
        private bool _isCheckboxChecked = false;

        public bool IsCheckboxChecked
        {
            get { return _isCheckboxChecked; }
            set
            {
                _isCheckboxChecked = value;
                OnPropertyChanged(nameof(IsCheckboxChecked));
            }
        }

        private bool _plusiconVisible = false;
        public bool PlusIconVisibleOrNot
        {
            get
            {
                return _plusiconVisible;
            }
            set
            {
                _plusiconVisible = value;
                OnPropertyChanged(nameof(PlusIconVisibleOrNot));
            }
        }

    }
    public class ShipQuiltListDetailPageModel
    {
        public int id { get; set; }
        public string orderNumber { get; set; }
        public int customerId { get; set; }
        public int shipmentTypeId { get; set; }
        public int locationId { get; set; }
        public int shipmentETAId { get; set; }
        public int carrierId { get; set; }
        public string carrierName { get; set; }
        public List<string> inventories { get; set; }
        public string additionalNotes { get; set; }
        public string proNumber { get; set; }
    }
}

