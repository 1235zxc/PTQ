﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class PalletQuiltDataResponseModel : BindableObject
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public int? typeId { get; set; }
        public string type { get; set; }
        public int statusId { get; set; }
        public string status { get; set; }
        public int totalQuilts { get; set; }
        public int? masterQuiltTypeId { get; set; }

        public List<Quilt> quilts { get; set; }
        public object customerId { get; set; }
        public object orderId { get; set; }
        public object customerName { get; set; }
        public object orderNumber { get; set; }
        public object orderStatus { get; set; }

        private bool _isCheckboxChecked = false;
        public bool IsCheckboxChecked
        {
            get { return _isCheckboxChecked; }
            set
            {
                _isCheckboxChecked = value;
                OnPropertyChanged(nameof(IsCheckboxChecked));
            }
        }

        private bool _plusiconVisible = false;
        public bool PlusIconVisibleOrNot
        {
            get
            {
                return _plusiconVisible;
            }
            set
            {
                _plusiconVisible = value;
                OnPropertyChanged(nameof(PlusIconVisibleOrNot));
            }
        }

       
    }
    public class Quilt : BindableObject
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public int? quiltTypeId { get; set; }
        public string quiltType { get; set; }
        public int? masterQuiltTypeId { get; set; }
        public string masterQuiltType { get; set; }
        public int? quiltStatusId { get; set; }
        public string quiltStatus { get; set; }
        public int? palletId { get; set; }

        public bool _isCheckboxCheckedNew = false;
        public bool IsCheckboxCheckedNew
        {
            get { return _isCheckboxCheckedNew; }
            set
            {
                _isCheckboxCheckedNew = value;
                OnPropertyChanged(nameof(IsCheckboxCheckedNew));
            }
        }
    }

    public class QuiltPalletRequestModel
    {
        public List<string> serialNumbers { get; set; }
        public bool individualQuiltsOnly { get; set; }
        public bool customerDetailsRequired { get; set; }
        public bool individualQuiltPallets { get; set; }
    }

    public class MockPalletDataResponseModel : BindableObject
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public object description { get; set; }
        public int palletStatusId { get; set; }
        public string palletStatus { get; set; }
        public int totalQuilts { get; set; }
        public List<object> quilts { get; set; }

        private bool _isCheckboxChecked = false;
        public bool IsCheckboxChecked
        {
            get { return _isCheckboxChecked; }
            set
            {
                _isCheckboxChecked = value;
                OnPropertyChanged(nameof(IsCheckboxChecked));
            }
        }

        private bool _plusiconVisible = true;
        public bool PlusIconVisibleOrNot
        {
            get
            {
                return _plusiconVisible;
            }
            set
            {
                _plusiconVisible = value;
                OnPropertyChanged(nameof(PlusIconVisibleOrNot));
            }
        }
    }
}
