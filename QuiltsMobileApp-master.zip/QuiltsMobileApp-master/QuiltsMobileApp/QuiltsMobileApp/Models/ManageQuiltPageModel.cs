﻿namespace QuiltsMobileApp.Models
{
    class ManageQuiltPageModel
    {
    }
}
