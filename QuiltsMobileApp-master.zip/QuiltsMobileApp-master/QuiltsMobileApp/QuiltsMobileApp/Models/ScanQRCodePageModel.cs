﻿namespace QuiltsMobileApp.Models
{
    public class ScanQRCodePageModel
    {
        public ScanQRCodePageModel()
        {
        }
    }
}
