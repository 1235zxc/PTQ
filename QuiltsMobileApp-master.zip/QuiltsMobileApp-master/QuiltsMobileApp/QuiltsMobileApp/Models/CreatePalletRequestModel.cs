﻿using System.Collections.Generic;

namespace QuiltsMobileApp.Models
{
    public class CreatePalletRequestModel
    {
        public int id { get; set; }
        public int palletStatusId { get; set; }
        public int masterQuiltTypeId { get; set; }
        public string description { get; set; }
        public List<string> quiltSerialNumbers { get; set; }
    }


    public class CreatepalletResponseModel
    {

        public int id { get; set; }
        public string serialNumber { get; set; }
        public string description { get; set; }
        public int palletStatusId { get; set; }
        public string palletStatus { get; set; }
        public int totalQuilts { get; set; }
        public List<QuiltList> quilts { get; set; }

    }
    public class QuiltList
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public int quiltTypeId { get; set; }
        public string quiltType { get; set; }
        public int masterQuiltTypeId { get; set; }
        public string masterQuiltType { get; set; }
        public int quiltStatusId { get; set; }
        public string quiltStatus { get; set; }
        public int palletId { get; set; }
    }
    public class MockPalletResponsePageModel
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public object description { get; set; }
        public int palletStatusId { get; set; }
        public string palletStatus { get; set; }
        public int totalQuilts { get; set; }
        public List<object> quilts { get; set; }
    }

}
