﻿using System.Collections.Generic;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class ReceiveQuiltsPageModel
    {
    }
    public class OrderTypePageModel : BindableObject
    {
        public int id { get; set; }
        public string name { get; set; }
        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }
    }
    public class ReceiveQuiltsRequestPageModel
    {
        public int orderId { get; set; }
        public int customerId { get; set; }
        public bool sendEmail { get; set; }
        public List<string> inventories { get; set; }
    }

}
