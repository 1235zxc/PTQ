﻿namespace QuiltsMobileApp.ViewModels
{
    public class EditProfileResponseModel
    {
        public int id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string phoneNumber { get; set; }
        public Location location { get; set; }
        public object locationId { get; set; }
    }
    public class EditProfileRequestModel
    {
        public int id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string phoneNumber { get; set; }
        public int locationId { get; set; }
    }
    public class Location
    {
        public int id { get; set; }
        public object name { get; set; }
    }
}
