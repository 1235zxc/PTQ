﻿using System.Collections.Generic;

namespace QuiltsMobileApp.Models
{
    public class AssignQuiltQRCodePageModel
    {

    }
    public class QuiltPalletforAssign
    {
        public QuiltPalletforAssign()
        {

        }
        public string orderNumber { get; set; }
        public List<int> quiltIds { get; set; }
        public List<int> palletIds { get; set; }
    }
}
