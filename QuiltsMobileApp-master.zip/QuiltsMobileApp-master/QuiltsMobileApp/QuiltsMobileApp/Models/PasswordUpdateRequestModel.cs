﻿namespace QuiltsMobileApp.Models
{
    public class PasswordUpdateRequestModel
    {
        public string currentPassword { get; set; }
        public string newPassword { get; set; }
    }
    public class PasswordUpdateResponseModel
    {

    }

}
