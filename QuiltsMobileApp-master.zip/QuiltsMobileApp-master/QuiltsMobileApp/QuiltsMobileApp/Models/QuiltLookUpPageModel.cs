﻿namespace QuiltsMobileApp.Models
{
    public class QuiltLookUpPageModel
    {
        public QuiltLookUpPageModel()
        {
        }
    }
}
