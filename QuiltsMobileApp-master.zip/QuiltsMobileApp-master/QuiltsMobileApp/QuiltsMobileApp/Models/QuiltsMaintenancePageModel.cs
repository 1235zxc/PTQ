﻿using System.Collections.Generic;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class QuiltsMaintenancePageModels : BindableObject
    {
        public int id { get; set; }
        public string name { get; set; }
        private bool ischecked { get; set; }
        public bool IsChecked
        {
            get { return ischecked; }
            set
            {
                ischecked = value;
                OnPropertyChanged(nameof(IsChecked));
            }
        }
    }

    public class QuiltStatusUpdate
    {
        public List<int> quiltIds { get; set; }
        public int quiltStatusId { get; set; }
    }

    public class PalletStatusUpdate
    {
        public List<int> palletIds { get; set; }
        public int palletStatusId { get; set; }
    }

    public class QuiltPalletStatusUpdate
    {
        public List<string> serialNumbers { get; set; }
        public int statusId { get; set; }
    }
    public class UpdatePalletResponse
    {

    }

}
