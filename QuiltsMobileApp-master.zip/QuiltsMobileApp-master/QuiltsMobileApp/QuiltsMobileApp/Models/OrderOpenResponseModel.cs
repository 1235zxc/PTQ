﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class OrderOpenResponseModel : BindableObject
    {
        public string orderNumber { get; set; }
        public int orderTypeId { get; set; }
        public OrderType orderType { get; set; }
        public DateTime orderDate { get; set; }
        public int quiltsOrdered { get; set; }
        public int totalQuilts { get; set; }
        public int orderStatusId { get; set; }
        public OrderStatus orderStatus { get; set; }
        public int customerId { get; set; }
        public List<OrderInfo> orderInfo { get; set; }
        public ThirdPartyBillingDetails thirdPartyBillingDetails { get; set; }
        public int id { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string updatedBy { get; set; }
        public DateTime updatedDate { get; set; }
        public bool isDeleted { get; set; }
        public bool active { get; set; }

        private bool _seperator = true;

        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }

    }

    public class ThirdPartyBillingDetails
    {
        public int id { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public City city { get; set; }
        public string zip { get; set; }
        public int orderId { get; set; }
    }
    public class City
    {
        public int id { get; set; }
        public string name { get; set; }
        public object stateId { get; set; }
        public object state { get; set; }
    }
    public class OrderStatus
    {
        public int id { get; set; }
        public string status { get; set; }
    }

    public class OrderType
    {
        public int id { get; set; }
        public string type { get; set; }
    }


    public class OrderInfo
    {
        public int id { get; set; }
        public int quiltsAdded { get; set; }
        public int quiltsRemaining { get; set; }
        public DateTime addedOn { get; set; }
        public int orderId { get; set; }
        public int quiltTypeId { get; set; }
        public int? partNumberId { get; set; }
        public QuiltType quiltType { get; set; }
        public PartNumber partNumber { get; set; }


    }

    public class QuiltType
    {
        public int id { get; set; }
        public string type { get; set; }
        public int masterQuiltTypeId { get; set; }
        public MasterQuiltType masterQuiltType { get; set; }
    }
    public class MasterQuiltType
    {
        public int id { get; set; }
        public string type { get; set; }
    }
    public class PartNumber
    {
        public int id { get; set; }
        public string partNumber { get; set; }
        public QuiltDefinition quiltDefinition { get; set; }
        public QuiltConstruction quiltConstruction { get; set; }
        public QuiltSize quiltSize { get; set; }
        public int weight { get; set; }
        public QuiltType quiltType { get; set; }
        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string updatedBy { get; set; }
        public DateTime updatedDate { get; set; }
        public bool isDeleted { get; set; }
        public bool active { get; set; }
    }
    public class QuiltConstruction
    {
        public string construction { get; set; }
        public string type { get; set; }
        public int id { get; set; }
        public object createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public object updatedBy { get; set; }
        public DateTime updatedDate { get; set; }
        public bool isDeleted { get; set; }
        public bool active { get; set; }
    }

    public class QuiltDefinition
    {
        public string description { get; set; }
        public string type { get; set; }
        public string partNumber { get; set; }
        public int maxPallet { get; set; }
        public int id { get; set; }
        public object createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public object updatedBy { get; set; }
        public DateTime updatedDate { get; set; }
        public bool isDeleted { get; set; }
        public bool active { get; set; }
    }

    public class QuiltSize
    {
        public string size { get; set; }
        public string type { get; set; }
        public int id { get; set; }
        public object createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public object updatedBy { get; set; }
        public DateTime updatedDate { get; set; }
        public bool isDeleted { get; set; }
        public bool active { get; set; }
    }
}
