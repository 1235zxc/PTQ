﻿namespace QuiltsMobileApp.Models
{
    class HomePageModel
    {
    }
}
