﻿namespace QuiltsMobileApp.Models
{
    class UpdateStatusPageModel
    {
    }
}
