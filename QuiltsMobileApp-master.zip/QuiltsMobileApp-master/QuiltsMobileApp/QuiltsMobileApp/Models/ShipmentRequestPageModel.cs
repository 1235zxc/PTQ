﻿using System;
using System.Collections.Generic;

namespace QuiltsMobileApp.ViewModels
{
    public class ShipmentRequestPageModel
    {
        public int id { get; set; }
        public string orderNumber { get; set; }
        public int customerId { get; set; }
        public int shipmentTypeId { get; set; }
        public int locationId { get; set; }
        public int shipmentETAId { get; set; }
        public int carrierId { get; set; }
        public string carrierName { get; set; }
        public List<string> inventories { get; set; }
        public string additionalNotes { get; set; }
        public string proNumber { get; set; }
        public string shipmentNumber { get; set; }
    }
}

