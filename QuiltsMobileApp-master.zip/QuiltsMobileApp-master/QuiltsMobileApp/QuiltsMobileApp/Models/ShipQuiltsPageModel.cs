﻿namespace QuiltsMobileApp.Models
{
    public class ShipQuiltsPageModel
    {
        public int customerId { get; set; }
        public string customerName { get; set; }
        public string customerNumber { get; set; }
        public int orderId { get; set; }
        public string orderNumber { get; set; }
        public int quiltsAdded { get; set; }
        public int quiltsAssigned { get; set; }
        public int quiltsShipped { get; set; }
        public int quiltsRemaining { get; set; }
        public int quiltsRemainingtoShip => quiltsAssigned - quiltsShipped;
    }
}
