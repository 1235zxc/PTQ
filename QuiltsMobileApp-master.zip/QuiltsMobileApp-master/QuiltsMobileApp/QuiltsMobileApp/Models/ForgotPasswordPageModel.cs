﻿namespace QuiltsMobileApp.Models
{
    public class ForgotPasswordPageModel
    {
        public string email { get; set; }
    }

}
