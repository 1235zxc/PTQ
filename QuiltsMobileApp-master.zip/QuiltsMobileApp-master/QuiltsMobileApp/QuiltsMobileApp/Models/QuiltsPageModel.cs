﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class QuiltsPageModel:BindableObject
    {
        public string quiltSerialNumber { get; set; }
        public string quiltType { get; set; }
        public string palletSerialNumber { get; set; }
        public string quiltStatus { get; set; }
        public string currentLocation { get; set; }
        public string origin { get; set; }
        public string destination { get; set; }
        public string lastKnownLocation { get; set; }

        private string _palletSrlNumb;
        public string PalletSrlNumb
        {
            get { return _palletSrlNumb; }
            set { _palletSrlNumb = value;
                OnPropertyChanged(); }
        }


        private string _currentLocation;
        public string CurrentLocation
        {
            get { return _currentLocation; }
            set
            {
                _currentLocation = value;
                OnPropertyChanged();
            }
        }

        private string _origin;
        public string Origin
        {
            get { return _origin; }
            set
            {
                _origin = value;
                OnPropertyChanged();
            }
        }

        private string _lastKnownLocation;
        public string LastKnownLocation
        {
            get { return _lastKnownLocation; }
            set
            {
                _lastKnownLocation = value;
                OnPropertyChanged();
            }
        }

        private string _Destination;
        public string Destination
        {
            get { return _Destination; }
            set
            {
                _Destination = value;
                OnPropertyChanged();
            }
        }
    }

}
