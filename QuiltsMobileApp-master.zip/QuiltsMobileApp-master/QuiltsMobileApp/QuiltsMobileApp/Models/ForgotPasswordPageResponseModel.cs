﻿namespace QuiltsMobileApp.Models
{
    public class ForgotPasswordPageResponseModel
    {
        public ForgotPasswordPageResponseModel()
        {
        }
    }
}
