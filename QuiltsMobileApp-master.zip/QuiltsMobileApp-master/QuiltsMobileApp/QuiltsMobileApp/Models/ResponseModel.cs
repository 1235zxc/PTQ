﻿using Newtonsoft.Json;
using System.Collections.ObjectModel;

namespace QuiltsMobileApp.Models
{
    public class ResponseModel<T>
    {
        [JsonProperty("id")]
        public int id { get; set; }
        [JsonProperty("message")]
        public string message { get; set; }

        [JsonProperty("statusCode")]
        public int statusCode { get; set; }

        [JsonProperty("data")]
        public T data { get; set; }
        [JsonProperty("exception")]
        public string exception { get; set; }
    }

    public class ResponseModelNew<T>
    {
        [JsonProperty("id")]
        public int id { get; set; }
        [JsonProperty("message")]
        public string message { get; set; }

        [JsonProperty("statusCode")]
        public int statusCode { get; set; }

        [JsonProperty("data")]
        public ObservableCollection<T> data { get; set; }
        [JsonProperty("exception")]
        public string exception { get; set; }
    }
}
