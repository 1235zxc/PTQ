﻿namespace QuiltsMobileApp.Models
{
    class PalletDetailsPageModel
    {
    }
}
