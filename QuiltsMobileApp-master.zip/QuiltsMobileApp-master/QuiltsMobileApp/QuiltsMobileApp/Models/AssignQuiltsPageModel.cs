﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class AssignQuiltsPageModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

    }
    public class CustomerListModel : BindableObject
    {
        public string customerNumber { get; set; }
        public int id { get; set; }
        public string name { get; set; }

        private bool _seperator = true;

        public bool Seperator
        {
            get { return _seperator; }
            set { _seperator = value; OnPropertyChanged(); }
        }

    }
}
