﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class CAorLuPalletPageModel
    {

        public int totalCount { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public int totalPages { get; set; }
        public bool hasPrevious { get; set; }
        public bool hasNext { get; set; }
        public PalletList palletList { get; set; }
    }

        public class CAorLuPallet
    {
            public int id { get; set; }
            public string serialNumber { get; set; }
            public string description { get; set; }
            public int palletStatusId { get; set; }
            public string palletStatus { get; set; }
            public int locationId { get; set; }
            public string location { get; set; }
            public int totalQuilts { get; set; }
            public ObservableCollection<CAorLuQuilt> quilts { get; set; }
        }

        public class PalletList
        {
            public int inventoryScanned { get; set; }
            public int onhand { get; set; }
            public ObservableCollection<CAorLuPallet> pallets { get; set; }
        }

    public class CAorLuQuilt:BindableObject
    {
        public int id { get; set; }
        public string serialNumber { get; set; }
        public int quiltTypeId { get; set; }
        public string quiltType { get; set; }
        public int masterQuiltTypeId { get; set; }
        public string masterQuiltType { get; set; }
        public int quiltStatusId { get; set; }
        public string quiltStatus { get; set; }
        public int palletId { get; set; }
        private bool _isCheckboxChecked = true;
        public bool IsCheckboxChecked
        {
            get { return _isCheckboxChecked; }
            set
            {
                _isCheckboxChecked = value;
                OnPropertyChanged(nameof(IsCheckboxChecked));
            }
        }
    }

    
}

