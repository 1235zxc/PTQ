﻿using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class LocationListModel:BindableObject
    {
        public int id { get; set; }
        public string name { get; set; }
        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set
            {
                _seperator = value;
                OnPropertyChanged();
            }
        }
    }
}
