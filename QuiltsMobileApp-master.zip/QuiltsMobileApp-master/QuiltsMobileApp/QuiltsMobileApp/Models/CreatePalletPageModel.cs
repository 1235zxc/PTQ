﻿namespace QuiltsMobileApp.Models
{
    public class CreatePalletPageModel
    {
        public string Image { get; set; }

        public string Name { get; set; }

        public bool IsVisible { get; set; }
    }
}
