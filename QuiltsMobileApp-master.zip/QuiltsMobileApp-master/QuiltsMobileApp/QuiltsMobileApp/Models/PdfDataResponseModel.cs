﻿namespace QuiltsMobileApp.Models
{
    public class PdfDataResponseModel
    {
        public int id { get; set; }
        public string message { get; set; }
        public int statusCode { get; set; }
        public string data { get; set; }
        public object exception { get; set; }
    }
}
