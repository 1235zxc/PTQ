﻿using System.Collections.Generic;

namespace QuiltsMobileApp.Models
{
    public class UserResponseModel
    {
        public int userId { get; set; }
        public string token { get; set; }
        public string expirationDate { get; set; }
        public bool isAuthenticated { get; set; }
        public string email { get; set; }
        public List<string> roles { get; set; }
        public string refreshToken { get; set; }
        public string refreshTokenExpiration { get; set; }
        public int? companyId { get; set; }
        public int? locationId { get; set; }
        public string userFullName { get; set; }
    }

    public class UserRole
    {
        public int UserId { get; set; }
        public string RoleName { get; set; }
    }
}
