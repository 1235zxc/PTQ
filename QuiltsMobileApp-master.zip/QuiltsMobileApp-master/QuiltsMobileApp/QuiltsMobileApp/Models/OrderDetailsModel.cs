﻿using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class OrderDetailsModel
    {
        public int totalCount { get; set; }
        public int pageNumber { get; set; }
        public int pageSize { get; set; }
        public int totalPages { get; set; }
        public bool hasPrevious { get; set; }
        public bool hasNext { get; set; }
        public int customerId { get; set; }
        public string customerName { get; set; }
        public string customerNumber { get; set; }
        public List<Order> orders { get; set; }
    }
    public class Order
    {
        public int id { get; set; }
        public string orderNumber { get; set; }
        public int orderTypeId { get; set; }
        public OrderType orderType { get; set; }
        public DateTime orderDate { get; set; }
        public int orderStatusId { get; set; }
        public OrderStatus orderStatus { get; set; }
        public string quiltTypes { get; set; }
        public int totalQuilts { get; set; }
    }




    public class QultTypsebyOrderResponse : BindableObject
    {
        public int quiltTypeId { get; set; }
        public string quiltType { get; set; }
        public int totalQuiltsOrdered { get; set; }
        public int quiltsRemaining { get; set; }

        private bool _seperator = true;
        public bool Seperator
        {
            get { return _seperator; }
            set
            {
                _seperator = value;
                OnPropertyChanged();
            }
        }
    }

}
