﻿using System.Collections.Generic;
using Xamarin.Forms;

namespace QuiltsMobileApp.Models
{
    public class EditPalletPageModel : BindableObject
    {
        public int Id { get; set; }
        public string serialNumber { get; set; }
        public string description { get; set; }
        public int palletStatusId { get; set; }
        public string palletStatus { get; set; }
        public int totalQuilts { get; set; }
        public List<Quilt> quilts { get; set; }
        private bool _isCheckboxChecked = false;
        public bool IsCheckboxChecked
        {
            get { return _isCheckboxChecked; }
            set
            {
                _isCheckboxChecked = value;
                OnPropertyChanged(nameof(IsCheckboxChecked));
            }
        }
    }
}
