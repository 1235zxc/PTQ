﻿using Android.Content;
using Android.Print;
using QuiltsMobileApp.Interfaces;
using System;
using System.IO;
using Xamarin.Forms;

[assembly: Dependency(typeof(QuiltsMobileApp.Droid.Services.CustomPrintService))]
namespace QuiltsMobileApp.Droid.Services
{
    public class CustomPrintService : IPrintService
    {
        public CustomPrintService()
        {
        }


        public bool PrintPdfFile(Stream file)
        {
            try
            {
                if (file.CanSeek)
                    //Reset the position of PDF document stream to be printed
                    file.Position = 0;
                string createdFilePath = System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "PrintSampleFile");
                using (var dest = System.IO.File.OpenWrite(createdFilePath))
                    file.CopyTo(dest);
                string filePath = createdFilePath;
                var activity = Xamarin.Essentials.Platform.CurrentActivity;
                PrintManager printManager = (PrintManager)activity.GetSystemService(Context.PrintService);
                PrintDocumentAdapter pda = new CustomPrintDocumentAdapter(filePath);
                //Print with null PrintAttributes
                printManager.Print("PrintSampleFile Job", pda, null);
            }
            catch (Exception ex)
            {

            }

            return true;
        }
    }
}