﻿using QuiltsMobileApp.Droid;
using QuiltsMobileApp.Interfaces;
using Xamarin.Essentials;
using Xamarin.Forms;

[assembly: Dependency(typeof(DeviceOrientation))]
namespace QuiltsMobileApp.Droid
{
    public class DeviceOrientation : IDeviceOrientation
    {
        public DeviceOrientation()
        {
        }

        public void DisableRotation()
        {
            Platform.CurrentActivity.RequestedOrientation = Android.Content.PM.ScreenOrientation.Locked;
        }

        public void EnableRotation()
        {
            Platform.CurrentActivity.RequestedOrientation = Android.Content.PM.ScreenOrientation.Portrait;
        }
    }
}
