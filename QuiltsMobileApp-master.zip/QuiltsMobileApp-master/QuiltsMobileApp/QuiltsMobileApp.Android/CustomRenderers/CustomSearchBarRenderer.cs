﻿using Android.Content;
using Android.Graphics.Drawables;
using Android.Widget;
using QuiltsMobileApp.Controls;
using QuiltsMobileApp.Droid.CustomRenderers;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
[assembly: ExportRenderer(typeof(CustomSearchBar), typeof(CustomSearchBarRenderer))]
namespace QuiltsMobileApp.Droid.CustomRenderers
{
    public class CustomSearchBarRenderer : SearchBarRenderer
    {
        public CustomSearchBarRenderer(Context context) : base(context)
        {
        }
        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);
            var searchView = base.Control as SearchView;
            //int searchIconId = Context.Resources.GetIdentifier("android:id/search_mag_icon", null, null);
            // ImageView searchViewIcon = (ImageView)searchView.FindViewById<ImageView>(searchIconId);
            // searchViewIcon.SetImageDrawable(null);
        }
        protected override void OnElementChanged(ElementChangedEventArgs<SearchBar> e)
        {
            base.OnElementChanged(e);
            if (Control != null)
            {
                Control.Background = new ColorDrawable(Android.Graphics.Color.Transparent);
            }
        }
    }
}
