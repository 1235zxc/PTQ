﻿using Android.Content;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
//[assembly: ExportRenderer(typeof(CheckBox), typeof(CustomCheckBoxRenderer))]
namespace QuiltsMobileApp.Droid.CustomRenderers
{
    public class CustomCheckBoxRenderer : ViewRenderer<Xamarin.Forms.CheckBox, Android.Widget.CheckBox>
    {
        public CustomCheckBoxRenderer(Context context) : base(context)
        {
        }
        private Android.Widget.CheckBox checkBox;


        protected override void OnElementChanged(ElementChangedEventArgs<CheckBox> e)
        {
            base.OnElementChanged(e);
            checkBox = new Android.Widget.CheckBox(Context);
            checkBox.SetButtonDrawable(Resource.Drawable.custom_checkbox);
            checkBox.Tag = this;

            SetNativeControl(checkBox);
        }

        /* protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
         {
             base.OnElementPropertyChanged(sender, e);
             if (e.PropertyName.Equals("Renderer", StringComparison.OrdinalIgnoreCase))
             {
                 checkBox.CheckedChange -= OnCheckedChanged;
                 checkBox.CheckedChange += OnCheckedChanged;
             }
         }

         private void OnCheckedChanged(object sender, Android.Widget.CompoundButton.CheckedChangeEventArgs e)
         {
            }*/
    }
}
