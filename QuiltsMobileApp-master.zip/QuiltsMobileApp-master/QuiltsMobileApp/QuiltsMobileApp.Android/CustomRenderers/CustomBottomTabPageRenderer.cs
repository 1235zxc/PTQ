﻿using Android.Content;
using Android.Graphics;
using Android.Graphics.Drawables;
using Android.Views;
using Android.Widget;
using Google.Android.Material.BottomNavigation;
using QuiltsMobileApp;
using QuiltsMobileApp.Droid.CustomRenderers;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;
using Xamarin.Forms.Platform.Android.AppCompat;
using static Java.Util.ResourceBundle;

[assembly: ExportRenderer(typeof(TabbedPage1), typeof(CustomBottomTabPageRenderer))]
namespace QuiltsMobileApp.Droid.CustomRenderers
{
    public sealed class CustomBottomTabPageRenderer : TabbedPageRenderer
    {
        private BottomNavigationView bottomNavigationView;
        public CustomBottomTabPageRenderer(Context context) : base(context)
        {

        }

        private int tIndex = 0;
        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);
            tIndex = (sender as TabbedPage).Children.IndexOf((sender as TabbedPage).CurrentPage);
            GetBottomNavigationView(this.ViewGroup);
        }
        protected override void OnLayout(bool changed, int l, int t, int r, int b)
        {
            base.OnLayout(changed, l, t, r, b);
            GradientDrawable topBorderLine = new GradientDrawable();
            topBorderLine.SetStroke(1, Android.Graphics.Color.ParseColor("#3D7CCA"));
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { topBorderLine });
            layerDrawable.SetLayerInset(0, 0, 0, 0, bottomNavigationView.Height - 2);
            bottomNavigationView.SetBackground(layerDrawable);

        }
        protected override void OnElementChanged(ElementChangedEventArgs<TabbedPage> e)
        {
            base.OnElementChanged(e);
            if (e.NewElement == null) return;
            if (e.OldElement == null && e.NewElement != null)
            {
                bottomNavigationView = (GetChildAt(0) as Android.Widget.RelativeLayout).GetChildAt(1) as BottomNavigationView;
                //for (int i = 0; i <= this.ViewGroup.ChildCount - 1; i++)
                //{
                //    var childView = this.ViewGroup.GetChildAt(i);
                //    if (childView is ViewGroup viewGroup)
                //    {
                //        for (int j = 0; j <= viewGroup.ChildCount - 1; j++)
                //        {
                //            var childRelativeLayoutView = viewGroup.GetChildAt(j);
                //            if (childRelativeLayoutView is BottomNavigationView)
                //            {
                //                ((BottomNavigationView)childRelativeLayoutView).ItemTextAppearanceActive = Resource.Style.MyBottomNavigationView;
                //                ((BottomNavigationView)childRelativeLayoutView).ItemTextAppearanceInactive = Resource.Style.MyBottomNavigationView;
                //            }
                //        }
                //    }
                //}
            }
        }


        private void GetBottomNavigationView(ViewGroup viewGroup)
        {

            for (int i = 0; i < viewGroup.ChildCount; i++)
            {
                Android.Views.View childView = viewGroup.GetChildAt(i);
                if (childView is ViewGroup)
                {
                    ViewGroup childViewGroup = (ViewGroup)childView;
                    for (int j = 0; j < childViewGroup.ChildCount; j++)
                    {
                        var bottomNavigationView = childViewGroup.GetChildAt(j);
                        if (bottomNavigationView is TextView textView)
                        {
                            textView.SetTypeface(Typeface.SansSerif, TypefaceStyle.Normal);
                            //Typeface typeface = Typeface.CreateFromAsset(QuiltsMobileApp.CustomFonts, "OpenSans-Regular.ttf");
                        }
                        if (bottomNavigationView is BottomNavigationView)
                        {
                            BottomNavigationMenuView bnMenuViev = ((BottomNavigationView)bottomNavigationView).MenuView as BottomNavigationMenuView;
                            for (int n = 0; n < bnMenuViev.ChildCount; n++)
                            {
                                var tab = bnMenuViev.GetChildAt(n);
                                var item = tab as Google.Android.Material.Navigation.NavigationBarItemView;
                                if (item.ItemPosition == tIndex)
                                {
                                    GradientDrawable topBorderLine = new GradientDrawable();
                                    //topBorderLine.SetStroke(1, Android.Graphics.Color.ParseColor("#3D7CCA"));
                                    LayerDrawable layerDrawable = new LayerDrawable(new Drawable[] { topBorderLine });
                                    layerDrawable.SetLayerInset(0, 0, 0, 0, bottomNavigationView.Height - 2);
                                    tab.SetBackground(layerDrawable);
                                }
                                else
                                {
                                    tab.SetBackgroundColor(Android.Graphics.Color.White);
                                }
                            }
                        }
                    }
                }
            }
        }

    }
}
