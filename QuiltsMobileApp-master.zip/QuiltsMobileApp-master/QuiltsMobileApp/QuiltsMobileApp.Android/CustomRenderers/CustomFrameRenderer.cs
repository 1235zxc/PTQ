﻿using Android.Content;
using Android.Graphics.Drawables;
using QuiltsMobileApp.Controls;
using QuiltsMobileApp.Droid.CustomRenderers;
using System.ComponentModel;
using Xamarin.Forms;
using Xamarin.Forms.Platform.Android;

[assembly: ExportRenderer(typeof(CustomFrame), typeof(CustomFrameRenderer))]

namespace QuiltsMobileApp.Droid.CustomRenderers
{
    public class CustomFrameRenderer : Xamarin.Forms.Platform.Android.AppCompat.FrameRenderer
    {
        public CustomFrameRenderer(Context context) : base(context)
        {

        }
        protected override void OnElementChanged(ElementChangedEventArgs<Frame> e)
        {
            base.OnElementChanged(e);
            if (e.NewElement != null && Control != null)
            {
                UpdateCornerRadius();

            }
            var element = e.NewElement as CustomFrame;


            if (element == null) return;

            if (element.HasShadow)
            {
                SetOutlineSpotShadowColor(Android.Graphics.Color.ParseColor("#8FABC9"));

                Elevation = 30.0f;
                TranslationZ = 0.0f;
                SetZ(30f);


            }
        }
        protected override void OnElementPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            base.OnElementPropertyChanged(sender, e);
            if (e.PropertyName == nameof(CustomFrame.CornerRadius) || e.PropertyName == nameof(CustomFrame))
            {
                UpdateCornerRadius();
            }
        }
        private void UpdateCornerRadius()
        {
            if (Control.Background is GradientDrawable backgroundGradient)
            {
                var cornerRadius = (Element as CustomFrame)?.CornerRadius;
                if (!cornerRadius.HasValue)
                {
                    return;
                }
                var topLefCorner = Context.ToPixels(cornerRadius.Value.TopLeft);
                var topRightCorner = Context.ToPixels(cornerRadius.Value.TopRight);
                var bottomLeftCorner = Context.ToPixels(cornerRadius.Value.BottomLeft);
                var bottomRightCorner = Context.ToPixels(cornerRadius.Value.BottomRight);
                var cornerRadii = new[]
                {
                   topLefCorner,topLefCorner,
                   topRightCorner,topRightCorner,
                   bottomRightCorner,bottomRightCorner,
                   bottomLeftCorner,bottomLeftCorner
                };
                backgroundGradient.SetCornerRadii(cornerRadii);
            }
        }
    }
}