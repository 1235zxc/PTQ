﻿using Android.Content;
using Android.Views;
using Android.Widget;
using QuiltsMobileApp.Interfaces;

namespace QuiltsMobileApp.Droid.CustomRenderers
{
    public class MessageAndroid : IMessage
    {

        public string GetPath()
        {
            return Android.App.Application.Context.GetExternalFilesDir(Android.OS.Environment.DirectoryDownloads).AbsolutePath;
        }

        public void LongAlert(string message)
        {
            Toast.MakeText(Android.App.Application.Context, message, ToastLength.Long).Show();
            /*Toast toast = Toast.MakeText(Application.Context, message, ToastLength.Long);
            toast.View.Background.SetColorFilter(Android.Graphics.Color.ParseColor("#8FABC9"), PorterDuff.Mode.SrcIn);
            toast.SetGravity(GravityFlags.Center, 0, 0);
            toast.Show();*/
        }

        public void ShortAlert(string message)
        {
            Toast.MakeText(Android.App.Application.Context, message, ToastLength.Short).Show();
            /*  Toast toast = Toast.MakeText(Application.Context, message, ToastLength.Short);
              toast.View.Background.SetColorFilter(Android.Graphics.Color.ParseColor("#8FABC9"), PorterDuff.Mode.SrcIn);

              toast.SetGravity(GravityFlags.Center, 0, 0);
              toast.Show();*/
        }
        public void CustomShowAlert(string message)
        {
            var context = Android.App.Application.Context;
            var inflater = context.GetSystemService(Context.LayoutInflaterService) as LayoutInflater;
            var view = inflater.Inflate(Resource.Layout.custom_toast, null);

            var textView = view.FindViewById<TextView>(Resource.Id.text);
            textView.Text = message;

            var toast = new Android.Widget.Toast(context);
            toast.SetGravity(GravityFlags.Bottom, 0, 40);
            toast.Duration = ToastLength.Short;
            toast.View = view;
            toast.Show();
        }
        public void CustomLongAlert(string message)
        {
            var context = Android.App.Application.Context;
            var inflater = context.GetSystemService(Context.LayoutInflaterService) as LayoutInflater;
            var view = inflater.Inflate(Resource.Layout.custom_toast, null);

            var textView = view.FindViewById<TextView>(Resource.Id.text);
            textView.Text = message;

            var toast = new Android.Widget.Toast(context);
            toast.SetGravity(GravityFlags.Bottom, 0, 40);
            toast.Duration = ToastLength.Long;
            toast.View = view;
            toast.Show();
        }
    }
}
