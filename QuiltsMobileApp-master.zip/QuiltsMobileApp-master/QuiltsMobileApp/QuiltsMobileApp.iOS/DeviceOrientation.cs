﻿using QuiltsMobileApp.Interfaces;
using QuiltsMobileApp.iOS;
using Xamarin.Forms;

[assembly: Dependency(typeof(DeviceOrientation))]
namespace QuiltsMobileApp.iOS
{
    public class DeviceOrientation : IDeviceOrientation
    {
        public DeviceOrientation()
        {
        }

        public void DisableRotation()
        {
            AppDelegate.AllowRotation = false;
        }

        public void EnableRotation()
        {
            AppDelegate.AllowRotation = true;
        }
    }
}
