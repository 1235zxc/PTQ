﻿using QuiltsMobileApp.Controls;
using QuiltsMobileApp.iOS.CustomRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(CustomPicker), typeof(CustomPickerRenderer))]
namespace QuiltsMobileApp.iOS.CustomRenderer
{
    public class CustomPickerRenderer : PickerRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Picker> e)
        {
            base.OnElementChanged(e);
            var element = (CustomPicker)this.Element;

            if (this.Control != null && this.Element != null && !string.IsNullOrEmpty(element.Image))
            {
                var downarrow = UIImage.FromBundle(element.Image);
                Control.RightViewMode = UITextFieldViewMode.Always;
                Control.RightView = new UIImageView(downarrow);

                Control.Layer.BorderWidth = 0;
                Control.BorderStyle = UITextBorderStyle.None;

            }
            if (Control == null)
            {
                SetNativeControl(new UITextField
                {
                    RightViewMode = UITextFieldViewMode.Always,
                    ClearButtonMode = UITextFieldViewMode.WhileEditing,



                });
                // SetUIbutton(element.DonebuttonText);
            }
            else
            {// SetUIbutton(element.DonebuttonText); }

            }

            /*private void SetUIbutton(string donebuttonText)
             {
                 UIToolbar toolbar = new UIToolbar();
                 toolbar.BarStyle = UIBarStyle.Default;

                 toolbar.Translucent = true;
                 toolbar.SizeToFit();
                 toolbar.BackgroundColor = UIColor.White;
                 UIBarButtonItem doneButton = new UIBarButtonItem(string.IsNullOrEmpty(donebuttonText) ? "OK" : donebuttonText,
                     UIBarButtonItemStyle.Done, (s, ev) => { Control.ResignFirstResponder(); });
                 UIBarButtonItem flexible = new UIBarButtonItem(UIBarButtonSystemItem.FlexibleSpace);

                 toolbar.SetItems(new UIBarButtonItem[] { doneButton, flexible }, true);

                 Control.InputAccessoryView = toolbar;

             }*/
        }
    }
}
