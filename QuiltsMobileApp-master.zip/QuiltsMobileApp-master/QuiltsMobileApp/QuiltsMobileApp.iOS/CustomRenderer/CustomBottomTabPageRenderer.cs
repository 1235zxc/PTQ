﻿using CoreGraphics;
using QuiltsMobileApp;
using QuiltsMobileApp.iOS.CustomRenderer;
using System;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(TabbedPage1), typeof(CustomBottomTabPageRenderer))]

namespace QuiltsMobileApp.iOS.CustomRenderer
{
    public class CustomBottomTabPageRenderer : TabbedRenderer
    {
        UITabBarController tabbedController;

        public CustomBottomTabPageRenderer()
        {
        }


        public UIImage imageWithColor(CGSize size)
        {

            // CGRect rect = new CGRect(0, 0, size.Width / 1.07, size.Height / 1.16);
            CGRect rect = new CGRect(0, 0, size.Width, 3);

            UIGraphics.BeginImageContext(size);
            using (CGContext context = UIGraphics.GetCurrentContext())
            {
                float red = 0.239f;
                float green = 0.486f;
                float blue = 0.792f;
                float alpha = 1f;
                context.SetFillColor(UIColor.FromRGBA(red, green, blue, alpha).CGColor);
                context.FillRect(rect);
                //  context.AddEllipseInRect(rect);
                // context.FillEllipseInRect(rect);
                context.FillPath();
            }


            UIImage image = UIGraphics.GetImageFromCurrentImageContext();

            UIGraphics.EndImageContext();
            return image;
        }


        protected override void OnElementChanged(VisualElementChangedEventArgs e)
        {
            base.OnElementChanged(e);

            if (e.NewElement != null)
            {
                TabBar.Layer.BorderWidth = (nfloat)1.5;
                TabBar.Layer.BorderColor = Color.FromHex("#F4F7FC").ToCGColor();
                TabBar.ClipsToBounds = true;
            }
        }
        public override void ViewWillAppear(bool animated)
        {
            base.ViewWillAppear(animated);
            if (TabBar?.Items == null)
                return;
            var tabs = Element as TabbedPage;
            if (tabs != null)
            {
                for (int i = 0; i < TabBar.Items.Length; i++)
                {
                    UpdateTabBarItem(TabBar.Items[i]);
                }
            }

        }

        private void UpdateTabBarItem(UITabBarItem item)
        {
            if (item == null) return;

            if (UIDevice.CurrentDevice.CheckSystemVersion(13, 0))
            {
                UITabBarAppearance app = new UITabBarAppearance();
                app.ConfigureWithOpaqueBackground();
                app.BackgroundColor = UIColor.Clear;
                app.StackedLayoutAppearance.Normal.IconColor = Color.FromHex("#8FABC9").ToUIColor();
                app.StackedLayoutAppearance.Selected.IconColor = Color.FromHex("#3D7CCA").ToUIColor();
                app.StackedLayoutAppearance.Normal.TitleTextAttributes = new UIStringAttributes() { Font = UIFont.FromName("OpenSans-Regular", 14), ForegroundColor = Color.FromHex("#8FABC9").ToUIColor() };
                app.StackedLayoutAppearance.Selected.TitleTextAttributes = new UIStringAttributes() { Font = UIFont.FromName("OpenSans-SemiBold", 14), ForegroundColor = Color.FromHex("#3D7CCA").ToUIColor() };
                item.StandardAppearance = app;
                if (UIDevice.CurrentDevice.CheckSystemVersion(15, 0))
                {
                    item.ScrollEdgeAppearance = item.StandardAppearance;
                }
            }
        }


        public override void ViewWillLayoutSubviews()
        {
            base.ViewWillLayoutSubviews();
            TabBar.InvalidateIntrinsicContentSize();
            double height = TabBar.Frame.Height + 1.0f;
            //  CGSize size = new CGSize(TabBar.Frame.Width / (TabBar.Items.Length + 1.53f), height);
            CGSize size = new CGSize(TabBar.Frame.Width / TabBar.Items.Length, height);

            // Now get our all-green image...
            UIImage image = imageWithColor(size);
            TabBar.SelectedImageTintColor = Color.FromHex("#8FABC9").ToUIColor();
            // TabBar.ShadowImage = image;

            //  TabBar.BackgroundImage = image;
            //  TabBar.BackgroundColor = Color.FromHex("#F4F7FC").ToUIColor();
            // And set it as the selection indicator
            TabBar.SelectionIndicatorImage = image;

        }

    }
}

