﻿using QuiltsMobileApp.iOS.CustomRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;
[assembly: ExportRenderer(typeof(ContentPage), typeof(CustomDarkModeContentPageRenderer))]
namespace QuiltsMobileApp.iOS.CustomRenderer
{
    public class CustomDarkModeContentPageRenderer : PageRenderer
    {

        protected override void OnElementChanged(VisualElementChangedEventArgs e)
        {
            base.OnElementChanged(e);
            OverrideUserInterfaceStyle = UIUserInterfaceStyle.Light;

        }
    }
}
