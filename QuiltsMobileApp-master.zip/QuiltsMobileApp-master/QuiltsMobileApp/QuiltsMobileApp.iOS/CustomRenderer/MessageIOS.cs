﻿using Foundation;
using GlobalToast;
using QuiltsMobileApp.Interfaces;
using System;
using System.IO;
using UIKit;

namespace QuiltsMobileApp.iOS.CustomRenderer
{
    public class MessageIOS : IMessage
    {
        public MessageIOS()
        {
        }

        const double LONG_DELAY = 2.5;
        const double SHORT_DELAY = 1.0;
        NSTimer alertDelay;
        UIAlertController alert = new UIAlertController();

        public string GetPath()
        {
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments));
        }


        public void LongAlert(string message)
        {
            Toast.MakeToast(message).Show();

            // ShowAlert(message, LONG_DELAY);

        }

        public void ShortAlert(string message)
        {
            // ShowAlert(message, SHORT_DELAY);
            Toast.MakeToast(message).Show();


        }
        public void CustomShowAlert(string message)
        {
            Toast.MakeToast(message).Show();

            // ShowAlert(message, LONG_DELAY);

        }

        public void CustomLongAlert(string message)
        {
            // ShowAlert(message, SHORT_DELAY);
            Toast.MakeToast(message).Show();


        }


        void ShowAlert(string message, double seconds)
        {
            alertDelay = NSTimer.CreateScheduledTimer(seconds, (obj) =>
            {
                dismissMessage();
            });
            // UIApplication.SharedApplication.KeyWindow.RootViewController.PresentViewController(alert, true, null);
            alert = UIAlertController.Create(null, message, UIAlertControllerStyle.Alert);

            UIApplication.SharedApplication.KeyWindow.RootViewController.PresentViewController(alert, true, null);

        }

        /* public void ShowToast(String message, UIView view)
         {
             UIView residualView = view.ViewWithTag(1989);
             if (residualView != null)
                 residualView.RemoveFromSuperview();

             var viewBack = new UIView(new CoreGraphics.CGRect(83, 0, 300, 100));
             viewBack.BackgroundColor = UIColor.Red;
             viewBack.Tag = 1989;
             UILabel lblMsg = new UILabel(new CoreGraphics.CGRect(0, 20, 300, 60));
             lblMsg.Lines = 2;
             lblMsg.Text = message;
             lblMsg.TextColor = UIColor.White;
             lblMsg.TextAlignment = UITextAlignment.Center;
             viewBack.Center = view.Center;
             viewBack.AddSubview(lblMsg);
             view.AddSubview(viewBack);
            // roundtheCorner(viewBack);
             UIView.BeginAnimations("Toast");
             UIView.SetAnimationDuration(3.0f);
             viewBack.Alpha = 0.0f;
             UIView.CommitAnimations();
         }*/

        private void dismissMessage()
        {
            if (alert != null)
            {
                alert.DismissViewController(true, null);
            }
            if (alertDelay != null)
            {
                alertDelay.Dispose();
            }
        }

    }
}
