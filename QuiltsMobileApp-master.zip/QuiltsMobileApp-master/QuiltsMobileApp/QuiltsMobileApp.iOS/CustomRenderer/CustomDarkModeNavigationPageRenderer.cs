﻿using QuiltsMobileApp.iOS.CustomRenderer;
using UIKit;
using Xamarin.Forms;
using Xamarin.Forms.Platform.iOS;

[assembly: ExportRenderer(typeof(NavigationPage), typeof(CustomDarkModeNavigationPageRenderer))]
namespace QuiltsMobileApp.iOS.CustomRenderer
{
    public class CustomDarkModeNavigationPageRenderer : NavigationRenderer
    {

        protected override void OnElementChanged(VisualElementChangedEventArgs e)
        {
            base.OnElementChanged(e);
            OverrideUserInterfaceStyle = UIUserInterfaceStyle.Light;
        }
    }
}
